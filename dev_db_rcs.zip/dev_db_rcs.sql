-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Aug 30, 2025 at 09:04 AM
-- Server version: 9.1.0
-- PHP Version: 8.3.14

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dev_db_rcs`
--

-- --------------------------------------------------------

--
-- Table structure for table `amendment_aam_sabha_meetings`
--

DROP TABLE IF EXISTS `amendment_aam_sabha_meetings`;
CREATE TABLE IF NOT EXISTS `amendment_aam_sabha_meetings` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` bigint UNSIGNED NOT NULL,
  `noticeOfAamSabha` tinyint(1) NOT NULL DEFAULT '0',
  `communication_method` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `other_communication` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ag_meeting_date` date DEFAULT NULL,
  `meeting_notice` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amendment_aam_sabha_meetings`
--

INSERT INTO `amendment_aam_sabha_meetings` (`id`, `society_id`, `noticeOfAamSabha`, `communication_method`, `other_communication`, `ag_meeting_date`, `meeting_notice`, `created_at`, `updated_at`) VALUES
(1, 1, 0, NULL, NULL, NULL, NULL, '2025-06-17 11:51:26', '2025-06-17 11:51:26'),
(2, 2, 0, NULL, NULL, NULL, NULL, '2025-06-17 12:28:43', '2025-06-17 12:28:43'),
(3, 3, 0, NULL, NULL, NULL, NULL, '2025-06-18 07:51:31', '2025-06-18 07:51:31'),
(4, 4, 0, NULL, NULL, NULL, NULL, '2025-06-19 05:08:21', '2025-06-19 05:08:21'),
(5, 5, 0, NULL, NULL, NULL, NULL, '2025-06-19 05:09:40', '2025-06-19 05:09:40'),
(6, 6, 0, NULL, NULL, NULL, NULL, '2025-06-19 05:10:52', '2025-06-19 05:10:52');

-- --------------------------------------------------------

--
-- Table structure for table `amendment_application_flows`
--

DROP TABLE IF EXISTS `amendment_application_flows`;
CREATE TABLE IF NOT EXISTS `amendment_application_flows` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `amendment_id` bigint UNSIGNED NOT NULL,
  `from_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user_id` bigint UNSIGNED DEFAULT NULL,
  `to_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_user_id` bigint UNSIGNED DEFAULT NULL,
  `direction` enum('forward','reverse') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'forward',
  `action` enum('send','approve','reject','revert','verification','recheck') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `is_action_taken` tinyint(1) NOT NULL DEFAULT '1',
  `acted_by` bigint UNSIGNED NOT NULL COMMENT 'action can only be taken by',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `amendment_application_flows_acted_by_foreign` (`acted_by`),
  KEY `amendment_application_flows_to_user_id_foreign` (`to_user_id`),
  KEY `amendment_application_flows_from_user_id_foreign` (`from_user_id`),
  KEY `amendment_application_flows_amendment_id_foreign` (`amendment_id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amendment_application_flows`
--

INSERT INTO `amendment_application_flows` (`id`, `amendment_id`, `from_role`, `from_user_id`, `to_role`, `to_user_id`, `direction`, `action`, `remarks`, `attachments`, `is_action_taken`, `acted_by`, `created_at`, `updated_at`) VALUES
(1, 1, 'ARCS', 1, 'drcs', 3, 'forward', 'verification', 'hbhjbjhgj', '\"[\\\"amendment_attachments\\\\/MVJx8IRYSneV8Hf2YpKqRmifP8mDOcS48AEyCCgD.pdf\\\"]\"', 1, 1, '2025-06-17 12:16:32', '2025-06-17 12:16:32'),
(2, 1, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'ghvhgvh', '\"[\\\"amendment_attachments\\\\/nwdiZlKUOtnQ3Resojye0GOIIfXBau8iVj0loxbO.pdf\\\"]\"', 1, 3, '2025-06-17 12:17:32', '2025-06-17 12:17:32'),
(3, 1, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'ghvhgvh', '\"[\\\"amendment_attachments\\\\/AvNE3ywT8LkgWLZRsWhAkFvU3pWh2Lhwlah7v5Uu.pdf\\\"]\"', 1, 3, '2025-06-17 12:17:47', '2025-06-17 12:17:47'),
(4, 1, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'ghvhgvh', '\"[\\\"amendment_attachments\\\\/XiLxbluht4yeVWO2tF1TvCUc3Ma7QasxUb03UAMf.pdf\\\"]\"', 1, 3, '2025-06-17 12:18:27', '2025-06-17 12:18:27'),
(5, 1, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'weeds', '\"[\\\"amendment_attachments\\\\/C9ZJGO3qJNTniZUUzTJ5HLsCjO3C54ydpHGHNIdi.pdf\\\"]\"', 1, 3, '2025-06-17 12:22:51', '2025-06-17 12:22:51'),
(6, 1, 'DRCS', 3, 'society', 8, 'reverse', 'reject', 'weeds', '\"[\\\"amendment_attachments\\\\/hOdvCnRAT9DqO2s2a4hLtt8DhbqsRcKFACmBfIfr.pdf\\\"]\"', 1, 3, '2025-06-17 12:24:14', '2025-06-17 12:24:14'),
(7, 2, 'ARCS', 1, 'ado', 2, 'forward', 'verification', 'weding', '\"[\\\"amendment_attachments\\\\/5k283JRZeks0dknKAk4wJAFUPuDbs4sOK1goyaRQ.pdf\\\"]\"', 1, 1, '2025-06-17 12:30:03', '2025-06-17 12:30:03'),
(8, 2, 'ADO', 2, 'drcs', 3, 'forward', 'verification', 'jhbjjhj', '\"[\\\"amendment_attachments\\\\/pWyqXnOH42wh248JXtwsC206sfj59sQx5izhwbuH.pdf\\\"]\"', 1, 2, '2025-06-17 12:31:01', '2025-06-17 12:31:01'),
(9, 2, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'jhbjjhb', '\"[\\\"amendment_attachments\\\\/AphIbpvY941m8SWUZoKXfdCqb2FQnwdr82CkoPTX.pdf\\\"]\"', 1, 3, '2025-06-17 12:32:39', '2025-06-17 12:32:39'),
(10, 2, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'm nmmnkjnkj', '\"[\\\"amendment_attachments\\\\/ECTiHN3OZNNL1Z6TpCM2hokGuGy6p5uINrLRKstj.pdf\\\"]\"', 1, 3, '2025-06-17 12:39:45', '2025-06-17 12:39:45'),
(11, 2, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'm nmmnkjnkj', '\"[\\\"amendment_attachments\\\\/EtXzvxCzQAJGQFJpVtzOegvJ4gdrrGW45d5WoAhi.pdf\\\"]\"', 1, 3, '2025-06-17 12:42:39', '2025-06-17 12:42:39'),
(12, 1, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'gfdgdrtetretrtr', '\"[\\\"amendment_attachments\\\\/GbwGyuGbx8RI8dS8NeaqCo5hKfIYamICgS30MC6L.pdf\\\"]\"', 1, 3, '2025-06-17 12:54:05', '2025-06-17 12:54:05'),
(13, 3, 'ARCS', 1, 'drcs', 3, 'forward', 'verification', 'bhunhhjghghgh', '\"[\\\"amendment_attachments\\\\/HHxfYjgOnxpV8w5kAJTRiGzrwHsixeqBQ1YwLJq4.pdf\\\"]\"', 1, 1, '2025-06-18 07:55:15', '2025-06-18 07:55:15'),
(14, 3, 'DRCS', 3, NULL, NULL, 'forward', 'approve', 'final approval', '\"[\\\"amendment_attachments\\\\/s3m1RK6DXnXiLxze0SQdxjkxltUfNDgQNIjj88zf.pdf\\\"]\"', 1, 3, '2025-06-18 07:57:52', '2025-06-18 07:57:52'),
(15, 4, 'ARCS', 1, 'drcs', 3, 'forward', 'verification', 'asada', '\"[\\\"amendment_attachments\\\\/tTaA41TY2bwlYGK8NmLLVsuLHRzUeRE6xkxjkx3X.pdf\\\"]\"', 1, 1, '2025-06-20 07:39:05', '2025-06-20 07:39:05'),
(16, 4, 'DRCS', 3, 'society', 8, 'reverse', 'reject', 'asdas', '\"[\\\"amendment_attachments\\\\/5yDaDR4ZzCAyXURYpbXvytHLuTYsNQO2yDdtustL.pdf\\\"]\"', 1, 3, '2025-06-20 07:39:58', '2025-06-20 07:39:58');

-- --------------------------------------------------------

--
-- Table structure for table `amendment_application_status_logs`
--

DROP TABLE IF EXISTS `amendment_application_status_logs`;
CREATE TABLE IF NOT EXISTS `amendment_application_status_logs` (
  `amendment_id` bigint UNSIGNED NOT NULL,
  `action_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `old_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_user` bigint UNSIGNED DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  KEY `amendment_application_status_logs_amendment_id_foreign` (`amendment_id`),
  KEY `amendment_application_status_logs_performed_by_user_foreign` (`performed_by_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amendment_application_status_logs`
--

INSERT INTO `amendment_application_status_logs` (`amendment_id`, `action_type`, `old_value`, `new_value`, `performed_by_role`, `performed_by_user`, `remarks`, `created_at`, `updated_at`) VALUES
(1, 'approve', '1', '1', 'drcs', 1, 'hbhjbjhgj', '2025-06-17 12:16:32', '2025-06-17 12:16:32'),
(2, 'approve', '1', '1', 'ado', 1, 'weding', '2025-06-17 12:30:03', '2025-06-17 12:30:03'),
(2, 'approve', '1', '1', 'drcs', 2, 'jhbjjhj', '2025-06-17 12:31:01', '2025-06-17 12:31:01'),
(2, 'approve', '1', '2', NULL, 3, 'm nmmnkjnkj', '2025-06-17 12:42:39', '2025-06-17 12:42:39'),
(1, 'approve', '1', '2', NULL, 3, 'gfdgdrtetretrtr', '2025-06-17 12:54:05', '2025-06-17 12:54:05'),
(3, 'approve', '1', '1', 'drcs', 1, 'bhunhhjghghgh', '2025-06-18 07:55:15', '2025-06-18 07:55:15'),
(3, 'approve', '1', '2', NULL, 3, 'final approval', '2025-06-18 07:57:52', '2025-06-18 07:57:52'),
(4, 'approve', '1', '1', 'drcs', 1, 'asada', '2025-06-20 07:39:05', '2025-06-20 07:39:05'),
(4, 'reject', '1', '5', NULL, 3, 'asdas', '2025-06-20 07:39:58', '2025-06-20 07:39:58');

-- --------------------------------------------------------

--
-- Table structure for table `amendment_managing_committes`
--

DROP TABLE IF EXISTS `amendment_managing_committes`;
CREATE TABLE IF NOT EXISTS `amendment_managing_committes` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` bigint UNSIGNED DEFAULT NULL,
  `existing_bylaw` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bylaw_section` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proposed_amendment` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `purpose_of_amendment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `registration_certificate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `approval` enum('yes','no') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'no',
  `committee_approval_doc` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amendment_managing_committes`
--

INSERT INTO `amendment_managing_committes` (`id`, `society_id`, `existing_bylaw`, `bylaw_section`, `proposed_amendment`, `purpose_of_amendment`, `registration_certificate`, `approval`, `committee_approval_doc`, `created_at`, `updated_at`) VALUES
(1, 1, 'existing_bylaws/t1kG8mky4Yx13cZ8ETd3oZE72WzEmld8Bun7Jx0g.pdf', 'bylaw_sections/0u9sUnsYgzSF7JBOdzYcAIB6kV6TY57IKQagjJ4D.pdf', 'Aliquam voluptatem', 'Aliquip dolor conseq', 'registration_certificate/zOvMIXdTlC7nZ1qiKikf8KJWG0Vbqif5nNO8cpec.pdf', 'no', NULL, '2025-06-17 11:51:21', '2025-06-17 11:51:21'),
(2, 2, 'existing_bylaws/jDhDGUjAWOPvTp5kC2A3GwcA2Cyg1hsYrMhzOObq.pdf', 'bylaw_sections/kAhWwtpFtcBGoX5mAPkkYIG5BCjTkFm5EmIO3ive.pdf', 'Eos debitis in eos d', 'Illo laborum Nemo o', 'registration_certificate/SINyafPmldOuIhUntt8shfq5xXDzxDRCXUIptXqn.pdf', 'no', NULL, '2025-06-17 12:28:40', '2025-06-17 12:28:40'),
(3, 3, 'existing_bylaws/9OSbUXvOiC47nBpG15Ockm3K4zSLQeyNeYQ1Ehey.pdf', 'bylaw_sections/VuISuyee4cnCdT3vJnnTol3xakKW9JtDj4dSHek0.pdf', 'Omnis pariatur Dese', 'Dicta corporis natus', 'registration_certificate/JmpA7YlDHvQv5bQO3jZDa2e5hO5iygSEeBQP0QHx.pdf', 'yes', 'committee_approvals/QPuOH8T7DjZt1dOLQ8HBhzNAWHAsG2vXtNiIRkhX.pdf', '2025-06-18 07:51:26', '2025-06-18 07:51:26'),
(4, 4, 'existing_bylaws/DIQm40I01coAy0cdmGhMkWwAn0bBXzSpYNk3vEdH.pdf', 'bylaw_sections/ovufm6rJLWYpltHqFgsquHR4td8JfpByR2x5ZUCC.pdf', 'Libero non ea ea por', 'Praesentium magna au', 'registration_certificate/sEbSW2Rh9Ccktsvw9S2RJWIlxqqWQ6XcTC09q7sM.pdf', 'no', NULL, '2025-06-19 05:08:17', '2025-06-19 05:08:17'),
(5, 5, 'existing_bylaws/RQa6gVQIvv9jEgMxTSCf6VeY3paMYbhNmpwScLy7.pdf', 'bylaw_sections/2MGvofZoVyVyXXXg5XYPH5PuLASaSjPEXXeW3SNC.pdf', 'Enim nihil minus qui', 'Aut dolor nulla adip', 'registration_certificate/ZTmg4Eox0IVqyA72jtRmD90949PAwID09kKfCwvS.pdf', 'yes', 'committee_approvals/HoV40RVk5pMStVEYtZJb9sPdXlVAEq259tqMB6U0.pdf', '2025-06-19 05:09:36', '2025-06-19 05:09:36'),
(6, 6, 'existing_bylaws/TzU5zvy9fYSfn52BFl3syglwqcZ3a285Mi3t9eJ5.pdf', 'bylaw_sections/87pL0DFkdUf3Y4f04TrcvHKmhz61Kf5BiVIRGQVW.pdf', 'Dolor veritatis dolo', 'Est est consequatur', 'registration_certificate/sRAq15cxkn8lTDHScmgano0Ve0HH9JgER5gLaIL6.pdf', 'no', NULL, '2025-06-19 05:10:48', '2025-06-19 05:10:48');

-- --------------------------------------------------------

--
-- Table structure for table `amendment_societies`
--

DROP TABLE IF EXISTS `amendment_societies`;
CREATE TABLE IF NOT EXISTS `amendment_societies` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `amendment_ref_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `act` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_members` int DEFAULT NULL,
  `district` int NOT NULL,
  `block` int NOT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `area_of_operation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `e18_certificate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_board_members` int DEFAULT NULL,
  `quorum_members` int DEFAULT NULL,
  `society_category` int DEFAULT NULL COMMENT '1-primary,2-central,3-apex',
  `submitted_to_role` enum('ARCS','ADO','DRCS','Registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_to_user_id` bigint UNSIGNED DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '1-pending,2-Reverted,3-Approved by admin,4-Approved by JRCS',
  `current_role` enum('ARCS','ADO','DRCS','Registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `amendment_societies_submitted_to_user_id_foreign` (`submitted_to_user_id`),
  KEY `amendment_societies_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amendment_societies`
--

INSERT INTO `amendment_societies` (`id`, `amendment_ref_no`, `user_id`, `name`, `act`, `total_members`, `district`, `block`, `address`, `area_of_operation`, `e18_certificate`, `total_board_members`, `quorum_members`, `society_category`, `submitted_to_role`, `submitted_to_user_id`, `status`, `current_role`, `created_at`, `updated_at`) VALUES
(1, 'ABLM#2', 8, '6', NULL, 1, 13, 92, 'Voluptate veritatis', NULL, 'e18_certificates/Xu1SXebA13wYoO4t95LcyQ1sXuLNrIxz8dhu3uRL.pdf', 45, 78, 1, NULL, NULL, 2, NULL, '2025-06-17 11:51:01', '2025-06-17 12:54:05'),
(2, 'ABLM#3', 8, '4', NULL, 66, 13, 92, 'Quis quia voluptates', NULL, 'e18_certificates/pVRT6XKjx9BPej5YUABDsUnc8y3TcKrsVVNahyfo.pdf', 27, 46, 1, NULL, NULL, 2, NULL, '2025-06-17 12:28:20', '2025-06-17 12:42:39'),
(3, 'ABLM#4', 8, '5', NULL, 71, 13, 92, 'At iste corporis cum', NULL, 'e18_certificates/wLCL2o3xzL27gDWd0NQLTTPDWUJeTZRIyhBnAkI3.pdf', 23, 4, 1, NULL, NULL, 2, NULL, '2025-06-18 07:51:00', '2025-06-18 07:57:52'),
(4, 'ABLM#5', 8, '6', NULL, 33, 13, 92, 'Voluptatum nostrum q', NULL, 'e18_certificates/BOq9FmqklgaOCuhyJSPydZguqB9mHQl0onBsJXZ8.pdf', 58, 60, 1, 'DRCS', NULL, 5, NULL, '2025-06-19 05:07:49', '2025-06-20 07:39:58'),
(5, 'ABLM#6', 8, '3', NULL, 13, 13, 92, 'Velit similique dol', NULL, 'e18_certificates/WeHjAsGgJIMpd99Ot4if1yE4hiQ68h3hB2gxTXOI.pdf', 53, 42, 1, 'ARCS', NULL, 1, 'ARCS', '2025-06-19 05:09:08', '2025-06-19 05:09:56'),
(6, 'ABLM#7', 8, '2', NULL, 10, 13, 92, 'Impedit repellendus', NULL, 'e18_certificates/zpD6KDerYessSwUV2et2qFswFjTvfo5b9yp6qW76.pdf', 72, 80, 1, 'ARCS', NULL, 1, 'ARCS', '2025-06-19 05:10:25', '2025-06-19 05:11:05'),
(7, 'ABLM#8', 8, '4', NULL, 25, 10, 75, 'Quia ullam dolor nat', NULL, 'e18_certificates/iiyDuOZ2H51PXmhRnFm0TM8SVgBmMOLLwUkzcx4t.docx', 2, 96, 3, 'ARCS', NULL, 0, 'ARCS', '2025-06-19 06:56:39', '2025-06-19 07:47:24');

-- --------------------------------------------------------

--
-- Table structure for table `amendment_voting_on_amendments`
--

DROP TABLE IF EXISTS `amendment_voting_on_amendments`;
CREATE TABLE IF NOT EXISTS `amendment_voting_on_amendments` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` bigint UNSIGNED NOT NULL,
  `quorum_completed` tinyint(1) NOT NULL DEFAULT '0',
  `total_members` int DEFAULT NULL,
  `members_present` int DEFAULT NULL,
  `votes_favor` int DEFAULT NULL,
  `votes_against` int DEFAULT NULL,
  `total_voted` int DEFAULT NULL,
  `abstain_members` int DEFAULT NULL,
  `resolution_amendment` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `resolution_file` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `amendment_voting_on_amendments`
--

INSERT INTO `amendment_voting_on_amendments` (`id`, `society_id`, `quorum_completed`, `total_members`, `members_present`, `votes_favor`, `votes_against`, `total_voted`, `abstain_members`, `resolution_amendment`, `resolution_file`, `created_at`, `updated_at`) VALUES
(1, 1, 0, 27, 4, NULL, NULL, 0, 4, NULL, NULL, '2025-06-17 11:51:41', '2025-06-17 11:51:41'),
(2, 2, 0, 450, 44, NULL, NULL, NULL, NULL, NULL, NULL, '2025-06-17 12:28:53', '2025-06-17 12:28:53'),
(3, 3, 0, 452, 40, NULL, NULL, NULL, NULL, NULL, NULL, '2025-06-18 07:51:40', '2025-06-18 07:51:40'),
(4, 4, 0, 62, 19, NULL, NULL, NULL, NULL, NULL, NULL, '2025-06-19 05:08:30', '2025-06-19 05:08:30'),
(5, 5, 0, 85, 45, NULL, NULL, NULL, NULL, NULL, NULL, '2025-06-19 05:09:56', '2025-06-19 05:09:56'),
(6, 6, 0, 800, 500, NULL, NULL, NULL, NULL, NULL, NULL, '2025-06-19 05:11:05', '2025-06-19 05:11:05');

-- --------------------------------------------------------

--
-- Table structure for table `area_of_operations`
--

DROP TABLE IF EXISTS `area_of_operations`;
CREATE TABLE IF NOT EXISTS `area_of_operations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `assign_committees`
--

DROP TABLE IF EXISTS `assign_committees`;
CREATE TABLE IF NOT EXISTS `assign_committees` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `complaint_id` bigint UNSIGNED NOT NULL,
  `designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_id` int DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  `block_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `current_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1=>Active,0=>Inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `assign_committees_complaint_id_foreign` (`complaint_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `audit_alotments`
--

DROP TABLE IF EXISTS `audit_alotments`;
CREATE TABLE IF NOT EXISTS `audit_alotments` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `fy_id` bigint UNSIGNED NOT NULL,
  `dept_auditor_id` bigint UNSIGNED NOT NULL,
  `society_type_id` bigint UNSIGNED NOT NULL,
  `district_id` bigint UNSIGNED NOT NULL,
  `block_id` bigint UNSIGNED NOT NULL,
  `society_id` bigint UNSIGNED NOT NULL,
  `audit_start_date_auditor` date DEFAULT NULL,
  `audit_end_date_auditor` date DEFAULT NULL,
  `audit_start_date_society` date DEFAULT NULL,
  `audit_end_date_society` date DEFAULT NULL,
  `status` int NOT NULL DEFAULT '0',
  `current_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ca_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `audit_alotments_dept_auditor_id_foreign` (`dept_auditor_id`),
  KEY `audit_alotments_society_type_id_foreign` (`society_type_id`),
  KEY `audit_alotments_district_id_foreign` (`district_id`),
  KEY `audit_alotments_block_id_foreign` (`block_id`),
  KEY `audit_alotments_society_id_foreign` (`society_id`),
  KEY `audit_alotments_user_id_foreign` (`user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blocks`
--

DROP TABLE IF EXISTS `blocks`;
CREATE TABLE IF NOT EXISTS `blocks` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `district_id` bigint NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=96 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `blocks`
--

INSERT INTO `blocks` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Raipur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(2, 1, 'Doiwala', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(3, 1, 'Sahaspur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(4, 1, 'Vikasnagar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(5, 1, 'Chakrata', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(6, 1, 'Kalsi', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(7, 2, 'Bahadrabad', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(8, 2, 'Bhagwanpur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(9, 2, 'Roorkee', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(10, 2, 'Narsan', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(11, 2, 'Laksar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(12, 2, 'Khanpur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(13, 3, 'Dasholi (Chamoli)', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(14, 3, 'Joshimath', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(15, 3, 'Ghat', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(16, 3, 'Pokhari', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(17, 3, 'Karanprayag', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(18, 3, 'Gairsain', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(19, 3, 'Narayanbagar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(20, 3, 'Thrali', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(21, 3, 'Dewal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(22, 4, 'Fakot (Narendranagar)', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(23, 4, 'Chamba', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(24, 4, 'Jaunpur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(25, 4, 'Thauldhar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(26, 4, 'Pratapnagar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(27, 4, 'Jakhanidhar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(28, 4, 'Hindolakhal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(29, 4, 'Kirtinagar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(30, 4, 'Bhilangna', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(31, 5, 'Ukhimath', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(32, 5, 'AugastMuni', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(33, 5, 'Jakholi', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(34, 6, 'Bhatwadi', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(35, 6, 'Dunda', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(36, 6, 'Chinyalisaud', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(37, 6, 'Naugaon', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(38, 6, 'Purola', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(39, 6, 'Mori', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(40, 7, 'Pauri', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(41, 7, 'Kot', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(42, 7, 'Kaljikhal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(43, 7, 'Khirsu', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(44, 7, 'Pabo', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(45, 7, 'Thalisain', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(46, 7, 'Bironkhal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(47, 7, 'Nanidanda', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(48, 7, 'Ekeshwar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(49, 7, 'Pokhra', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(50, 7, 'Rikhnikhal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(51, 7, 'Jaiharikhal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(52, 7, 'Dwarikhal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(53, 7, 'Dugadda', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(54, 7, 'Yamkeshwar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(55, 8, 'Bhaisiachana', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(56, 8, 'Bhikiyasain', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(57, 8, 'Chaukhutiya', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(58, 8, 'Dhauladevi', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(59, 8, 'Dwarahat', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(60, 8, 'Hawalbag', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(61, 8, 'Lamgara', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(62, 8, 'Sult', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(63, 8, 'Syalde', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(64, 8, 'Takula', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(65, 8, 'Tarikhet', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(66, 9, 'Haldwani', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(67, 9, 'Bhimtal', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(68, 9, 'Ramnagar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(69, 9, 'Kotabag', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(70, 9, 'Dhari', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(71, 9, 'Betalghat', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(72, 9, 'Ramgarh', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(73, 9, 'Okhalkanda', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(74, 10, 'Bin', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(75, 10, 'Munakot', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(76, 10, 'Didihat', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(77, 10, 'Kanalichina', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(78, 10, 'Dharchula', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(79, 10, 'Munsyari', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(80, 10, 'Gangolihat', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(81, 10, 'Berinag', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(82, 11, 'Khatima', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(83, 11, 'Sitarganj', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(84, 11, 'Rudrapur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(85, 11, 'Gadarpur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(86, 11, 'Bazpur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(87, 11, 'Jaspur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(88, 11, 'Kashipur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(89, 12, 'Bageshwar', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(90, 12, 'Garur', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(91, 12, 'Kapkot', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(92, 13, 'Champawt', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(93, 13, 'Barakot', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(94, 13, 'Pati', '2025-04-16 09:31:41', '2025-04-16 09:31:41'),
(95, 13, 'Lohaghat', '2025-04-16 09:31:41', '2025-04-16 09:31:41');

-- --------------------------------------------------------

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
CREATE TABLE IF NOT EXISTS `cache` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
CREATE TABLE IF NOT EXISTS `cache_locks` (
  `key` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `owner` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiration` int NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complaints`
--

DROP TABLE IF EXISTS `complaints`;
CREATE TABLE IF NOT EXISTS `complaints` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `com_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `complaint_by` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complaint_by_society_id` bigint UNSIGNED DEFAULT NULL,
  `complaint_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complaint_title` varchar(60) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` varchar(13) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aadhar_upload` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `complaint_type` tinyint DEFAULT NULL COMMENT '1=>Aggressive,2=>Expressive,3=>Passive,4=>Constructive',
  `priority` tinyint DEFAULT NULL COMMENT '1=>High,2=>Medium,3=>Low',
  `attachment` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `division` int DEFAULT NULL,
  `district` int DEFAULT NULL,
  `sub_division` int DEFAULT NULL,
  `block` int DEFAULT NULL,
  `society` int DEFAULT NULL,
  `submitted_to_role` enum('arcs','ado','drcs','registrar','jrcs','additionalrcs') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_to_user_id` bigint UNSIGNED DEFAULT NULL,
  `current_role` enum('arcs','ado','drcs','registrar','jrcs','additionalrcs') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forward_complaint_to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `status` tinyint NOT NULL DEFAULT '1' COMMENT '1=>Active,0=>Inactive',
  `is_member_add` tinyint NOT NULL DEFAULT '0' COMMENT '1=>yes,0=>no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaints_user_id_foreign` (`user_id`),
  KEY `complaints_submitted_to_user_id_foreign` (`submitted_to_user_id`),
  KEY `complaints_complaint_by_society_id_foreign` (`complaint_by_society_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complaint_application_flows`
--

DROP TABLE IF EXISTS `complaint_application_flows`;
CREATE TABLE IF NOT EXISTS `complaint_application_flows` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `complaint_id` bigint UNSIGNED NOT NULL,
  `from_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user_id` bigint UNSIGNED DEFAULT NULL,
  `to_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_user_id` bigint UNSIGNED DEFAULT NULL,
  `direction` enum('forward','reverse') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'forward',
  `action` enum('send','approve','reject','revert','verification','recheck') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `by_authorized_Person_id` int DEFAULT NULL,
  `forward_by_designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forward_to_designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forward_to_authorized_Person_id` int DEFAULT NULL,
  `is_action_taken` tinyint(1) NOT NULL DEFAULT '1',
  `acted_by` bigint UNSIGNED DEFAULT NULL COMMENT 'action can only taken by',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaint_application_flows_acted_by_foreign` (`acted_by`),
  KEY `complaint_application_flows_to_user_id_foreign` (`to_user_id`),
  KEY `complaint_application_flows_from_user_id_foreign` (`from_user_id`),
  KEY `complaint_application_flows_complaint_id_foreign` (`complaint_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complaint_application_flow_logs`
--

DROP TABLE IF EXISTS `complaint_application_flow_logs`;
CREATE TABLE IF NOT EXISTS `complaint_application_flow_logs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `complaint_id` bigint UNSIGNED DEFAULT NULL,
  `action_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_user` bigint UNSIGNED DEFAULT NULL,
  `by_authorized_Person_id` int DEFAULT NULL,
  `forward_by_designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forward_to_designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `forward_to_authorized_Person_id` int DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `complaint_application_flow_logs_complaint_id_foreign` (`complaint_id`),
  KEY `complaint_application_flow_logs_performed_by_user_foreign` (`performed_by_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `complaint_types`
--

DROP TABLE IF EXISTS `complaint_types`;
CREATE TABLE IF NOT EXISTS `complaint_types` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `complaint_types`
--

INSERT INTO `complaint_types` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Aggressive', '2025-06-13 06:50:19', '2025-06-13 06:50:19'),
(2, 'Expressive', '2025-06-13 06:50:19', '2025-06-13 06:50:19'),
(3, 'Passive', '2025-06-13 06:50:19', '2025-06-13 06:50:19'),
(4, 'Constructive', '2025-06-13 06:50:19', '2025-06-13 06:50:19');

-- --------------------------------------------------------

--
-- Table structure for table `districts`
--

DROP TABLE IF EXISTS `districts`;
CREATE TABLE IF NOT EXISTS `districts` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `state_id` bigint NOT NULL,
  `division_id` int NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `districts`
--

INSERT INTO `districts` (`id`, `state_id`, `division_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 1, 'Dehradun', NULL, NULL),
(2, 1, 1, 'Haridwar', NULL, NULL),
(3, 1, 1, 'Chamoli', NULL, NULL),
(4, 1, 1, 'Tehri', NULL, NULL),
(5, 1, 1, 'Rudraprayg', NULL, NULL),
(6, 1, 1, 'Uttarkashi', NULL, NULL),
(7, 1, 1, 'Pauri Garhwal', NULL, NULL),
(8, 1, 2, 'Almora', NULL, NULL),
(9, 1, 2, 'Nainital', NULL, NULL),
(10, 1, 2, 'Pithoragarh', NULL, NULL),
(11, 1, 2, 'UdhamSinghNagar', NULL, NULL),
(12, 1, 2, 'Bageshwar', NULL, NULL),
(13, 1, 2, 'Champawt', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `divisions`
--

DROP TABLE IF EXISTS `divisions`;
CREATE TABLE IF NOT EXISTS `divisions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `state_id` bigint NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `divisions`
--

INSERT INTO `divisions` (`id`, `state_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 1, 'Garhwal', '2025-06-13 12:19:42', '2025-06-13 12:19:42'),
(2, 1, 'Kumaon', '2025-06-13 12:19:42', '2025-06-13 12:19:42');

-- --------------------------------------------------------

--
-- Table structure for table `document_verification_flows`
--

DROP TABLE IF EXISTS `document_verification_flows`;
CREATE TABLE IF NOT EXISTS `document_verification_flows` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_app_detail_id` bigint UNSIGNED DEFAULT NULL,
  `document_id` bigint UNSIGNED DEFAULT NULL,
  `document_field` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verified_by` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `feasibility_reports`
--

DROP TABLE IF EXISTS `feasibility_reports`;
CREATE TABLE IF NOT EXISTS `feasibility_reports` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` int NOT NULL,
  `society_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_formation_reason` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `society_type` int DEFAULT NULL COMMENT '1-Village society,0-not a village society',
  `society_based_on` int DEFAULT NULL COMMENT '1-Mutual Interest,2-Co-operative Model',
  `bank_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `society_bank_distance` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `membership_limit` int NOT NULL,
  `total_members_ready_to_join` int NOT NULL,
  `is_member_active` int NOT NULL COMMENT '1-yes,0-no',
  `chairman_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secretary_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_member_understood_rights` int DEFAULT NULL COMMENT '1-yes,0-no',
  `is_member_awared_objectives` int DEFAULT NULL COMMENT '1-yes,0-no',
  `is_existing_society` int DEFAULT NULL COMMENT '1-yes,0-no',
  `existing_society_details` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `area_operation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authority_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authority_designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authority_signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_registration_date` date DEFAULT NULL,
  `society_completion_time` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `additional_info` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `feasibility_reports`
--

INSERT INTO `feasibility_reports` (`id`, `society_id`, `society_name`, `society_formation_reason`, `society_type`, `society_based_on`, `bank_name`, `society_bank_distance`, `membership_limit`, `total_members_ready_to_join`, `is_member_active`, `chairman_name`, `secretary_name`, `is_member_understood_rights`, `is_member_awared_objectives`, `is_existing_society`, `existing_society_details`, `area_operation`, `authority_name`, `authority_designation`, `authority_signature`, `society_registration_date`, `society_completion_time`, `additional_info`, `created_at`, `updated_at`) VALUES
(1, 1, 'Angelica Lynch', 'Quia laborum Quae n', 1, NULL, 'Michelle Osborn', 'Similique quisquam r', 60, 27, 1, 'Cally Wolf', 'Belle Cox', 1, 1, 0, NULL, NULL, 'Madonna Ewing', 'Alias ea dignissimos', 'uploads/EC1BsZip8bskrpTBpHUq3aLFyfRSqKPvSRI3Xvgx.pdf', '1995-10-23', '13', 'Ipsa nihil libero d', '2025-06-13 07:11:34', '2025-06-13 07:11:34'),
(2, 7, 'Charissa Nelson', 'In veniam enim comm', 1, NULL, 'Seth Bridges', 'Voluptatem Laborum', 88, 93, 1, 'Deborah Briggs', 'Sheila Stephenson', 0, 0, 1, 'Laborum expedita qui', 'Veniam pariatur Co', 'Lynn Deleon', 'A voluptas amet adi', 'uploads/3FZnoDR4O4gpbrDI9t7wIstTeOEOtqt19TIZ2ozR.pdf', '2010-12-08', '46', 'Fugiat qui aliquid e', '2025-06-17 05:06:06', '2025-06-17 05:07:03'),
(3, 6, 'Jennifer Bauer', 'Aperiam beatae ratio', 1, NULL, 'Jaden Watson', 'Necessitatibus conse', 84, 55, 1, 'Raja Bowman', 'Joy Valencia', 0, 0, 1, NULL, 'Commodo ut nostrud d', 'Blair Downs', 'Doloribus distinctio', 'uploads/vHYkmFP39vNQH1GCZPjRdq8jydYgjBy8p5enwHYa.pdf', '1971-11-24', '56', 'Ut ex dolores volupt', '2025-06-17 05:45:42', '2025-06-17 05:45:42'),
(4, 8, 'Selma Buckley', 'Eum ipsum pariatur', 1, NULL, 'August Henson', 'Porro deserunt aut r', 4, 0, 1, 'Cullen Williamson', 'Larissa Hines', 0, 1, 1, NULL, 'Reiciendis tempora q', 'Addison Wyatt', 'Nisi et a cupidatat', 'uploads/QJh8hidkvGa7bJtM6UNEy0EqcCvDT7m5vvrQikhi.pdf', '2007-02-27', '1', 'Alias ut praesentium', '2025-06-26 08:58:23', '2025-06-26 08:58:23'),
(5, 9, 'Jemima Mendoza', 'Labore elit nostrum', 0, NULL, 'Burton Thornton', 'Nisi mollit sed aper', 65, 6, 1, 'April Cleveland', 'Fulton Porter', 0, 1, 1, 'dsfsdfsd', 'Voluptas Nam aut nul', 'Harlan Hahn', 'Exercitation in inci', 'uploads/yiTvl75cBrER9M6pRHbOLFZXT8yR2c40je0We0Rr.pdf', '1973-11-27', '74', 'Corporis obcaecati q', '2025-06-26 10:37:47', '2025-06-30 08:36:05'),
(6, 10, 'Jenette Hart', 'Voluptate quos tempo', 1, NULL, 'Grady Sellers', 'Voluptatem totam si', 4, 21, 2, 'Dara Guerra', 'Rahim Wilcox', 0, 1, 1, NULL, 'Sed quis dolore rem', 'Galena Knight', 'Non non dolores cons', 'uploads/fGbF6EJ58KzyJLoXMjfF3HqUsIyHoEClExidiK5n.pdf', '2001-10-11', '67', 'Unde minus ipsam cul', '2025-06-30 05:12:07', '2025-06-30 05:12:07'),
(7, 11, 'Mira Forbes', 'Placeat minus conse', 0, NULL, 'Kiona Ryan', 'Velit occaecat ratio', 97, 96, 1, 'Myra Cabrera', 'Bradley Davis', 0, 0, 0, NULL, 'Ea anim harum accusa', 'Candice Wynn', 'Illo tempora maxime', 'uploads/8OmBuKRLVL8Uh1W8vo9bRDI5gIxvOAQD9JDfONSI.docx', '2022-10-10', '27', 'Aperiam cupidatat di', '2025-06-30 07:02:08', '2025-06-30 07:02:08'),
(8, 4, 'Teagan Reilly', 'Id iste culpa dignis', 1, NULL, 'Phoebe Mcleod', 'Consequatur Dolorib', 73, 17, 2, 'Giacomo Morris', 'Kameko Riley', 0, 1, 0, NULL, NULL, 'Ursa Booth', 'Repellendus Id temp', 'uploads/ESMQgovQvomwmO8oWJ69eKo6PmrmmkmmhFDwPzQR.pdf', '1986-09-12', '97', 'Quae temporibus volu', '2025-06-30 08:44:42', '2025-06-30 08:45:23'),
(9, 12, 'Kiara Potts', 'Laudantium pariatur', 1, NULL, 'Regan Jarvis', 'Nam ullamco incidunt', 64, 36, 1, 'Ori Mcneil', 'Bell Bray', 1, 0, 1, NULL, 'Deserunt enim neque', 'Yael Phelps', 'Minim perspiciatis', 'uploads/zOfkMGQZzDtFysmrSS9170ii8L6J1ONssxe3MHNY.pdf', '2012-06-24', '73', 'Ut voluptatum amet', '2025-06-30 10:59:35', '2025-06-30 10:59:35'),
(10, 13, 'Summer Stokes', 'In ex do maiores id', 0, NULL, 'Bethany Massey', 'Tempore autem nulla', 48, 89, 1, 'Lois Whitney', 'Jaime Ayala', 1, 1, 0, NULL, NULL, 'Cullen Rivera', 'Dolor quas itaque te', 'uploads/zZI7H6Q2vq1A3iBCLu92Th6bAl2pMKfI1lJtZodl.pdf', '1990-07-29', '19', 'Qui neque sed quis s', '2025-06-30 12:20:24', '2025-06-30 12:40:52'),
(11, 14, 'Jillian Graham', 'Velit est dolore fac', 0, NULL, 'Amanda Schwartz', 'Esse qui qui quia i', 56, 48, 2, 'Aiko Leon', 'Marcia Irwin', 0, 0, 1, 'ewwwwwwwwww', 'Quia repellendus La', 'Cooper Schmidt', 'Doloremque nihil est', 'uploads/7LbxnNsbSAFKjiTk8VEVy2H71n07ZlkPNEgWIeiY.pdf', '1980-11-25', '35', 'Ab dolorem odit temp', '2025-06-30 12:27:35', '2025-07-01 05:21:08'),
(12, 15, 'Jenna Dyer', 'Duis corrupti quod', 1, NULL, 'Tamara Perry', 'Dolorum in doloribus', 75, 37, 2, 'Emmanuel Sharpe', 'Quamar Brock', 0, 0, 1, NULL, 'Maxime soluta invent', 'Craig Summers', 'Voluptatem sint sin', 'uploads/PmKCzF0EtZ4GLxu57XCaRhH2kePTvsI9XY2KYlSk.pdf', '2005-03-29', '86', 'Blanditiis et dolore', '2025-07-01 06:21:23', '2025-07-01 06:21:23'),
(13, 16, 'Eaton Schmidt', 'Facere tempor quis q', 1, NULL, 'Armand Underwood', 'Sapiente sunt aliqua', 92, 7, 2, 'Cassandra Everett', 'Bradley Bates', 0, 0, 1, NULL, 'Et totam quia nisi d', 'Frances Quinn', 'Do molestiae in inci', 'uploads/zXHFu7OOJjwAASFw3MbY3xCsEZ9Yr12jqp2asq7T.docx', '2001-01-05', '81', 'Ea reprehenderit sin', '2025-07-01 08:51:54', '2025-07-01 08:51:54'),
(14, 17, 'Christine Bradley', 'Assumenda maiores mo', 1, NULL, 'Tobias Nieves', 'Aut ut nemo laborum', 26, 51, 1, 'Juliet Raymond', 'Ursula Alvarez', 0, 0, 1, NULL, 'Quibusdam eligendi b', 'Otto Barron', 'Quidem iste soluta c', 'uploads/vf7Ka9aFrzueex1W7meMYZnLEFFtCAGOsrI9pjm8.docx', '1989-10-29', '62', 'Amet id doloremque', '2025-07-01 10:02:18', '2025-07-01 10:02:18'),
(15, 18, 'Tashya Ortega', 'Quidem anim consequa', 0, NULL, 'Anastasia Sellers', 'Veniam maiores aliq', 27, 7, 1, 'Aubrey Mercado', 'Dorothy Benton', 0, 1, 1, NULL, 'Eum quia eiusmod mol', 'Felicia Mcmahon', 'Aut fuga Reprehende', 'uploads/oM4XUB4fZO1OVYcU5vdh5gWpwVk5fZqIITtCDyEe.docx', '2019-11-12', '99', 'Velit eaque et modi', '2025-07-01 10:32:40', '2025-07-01 10:32:40'),
(16, 19, 'Yetta Patton', 'Eos fugit nulla fug', 0, NULL, 'Chase Lewis', 'Voluptas voluptas no', 70, 67, 1, 'Griffith Holden', 'Ira Velazquez', 1, 0, 0, NULL, NULL, 'Isabella Randall', 'Fugiat beatae est qu', 'uploads/r4oLaLG0xR0ETqUXH8lfryzdDIdzgeWzZsjvMbFd.pdf', '2018-05-14', '78', 'Et illo anim qui vol', '2025-07-01 13:07:50', '2025-07-01 13:07:50'),
(17, 21, 'Nash Riggs', 'Alias quia ut rerum', 0, NULL, 'Farrah Foley', 'Odit non aliqua Est', 46, 99, 1, 'Dante Cervantes', 'Dalton Meadows', 0, 0, 1, NULL, 'Qui rerum est qui s', 'Julian Robles', 'Nam rerum irure ut m', 'uploads/ebHLRmVe3NL1K3uhRouCzU1TL73vp52gAVo6fB5j.pdf', '2019-12-24', '54', 'Mollitia ipsam quibu', '2025-07-02 05:59:55', '2025-07-02 05:59:55'),
(18, 23, 'Caryn Wiggins', 'Voluptas facilis ab', 1, NULL, 'Howard Colon', 'Omnis minus sit quo', 73, 38, 2, 'Kylee Cotton', 'Kylynn Tran', 0, 0, 0, NULL, NULL, 'Brianna Adkins', 'Eos qui dignissimos', 'uploads/Xrj2iw5PEJTBPDsy5SlA6yZKQ5I9tatoaTsEI3de.pdf', '2018-09-04', '49', 'Blanditiis sint nequ', '2025-07-02 10:48:56', '2025-07-02 10:48:56'),
(19, 28, 'Amanda Rivera', 'Animi ad eligendi e', 0, NULL, 'Camilla Shaffer', 'Rem ut fugiat nisi r', 10, 40, 2, 'Dexter Simpson', 'Pascale Mitchell', 0, 1, 1, NULL, 'Quo repellendus Ea', 'Portia Carpenter', 'Amet aut dolorem mi', 'uploads/qwppm9CBrJyMkSNkt7qJgChQcbx3sXoLl7Wm3WPW.pdf', '1970-01-22', '49', 'Dolore suscipit sunt', '2025-07-04 07:05:42', '2025-07-04 07:05:42');

-- --------------------------------------------------------

--
-- Table structure for table `financial_years`
--

DROP TABLE IF EXISTS `financial_years`;
CREATE TABLE IF NOT EXISTS `financial_years` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `financial_year` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '0 => inactive, 1 => active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inquiries`
--

DROP TABLE IF EXISTS `inquiries`;
CREATE TABLE IF NOT EXISTS `inquiries` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `financial_year` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  `block_id` int DEFAULT NULL,
  `society_type` int DEFAULT NULL,
  `society_id` int DEFAULT NULL,
  `inspector_id` int DEFAULT NULL,
  `inquiry_file` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remarks` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int DEFAULT NULL,
  `submitted_to_role` enum('ARCS','ADO','DRCS','Registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `current_role` enum('ARCS','ADO','DRCS','Registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_by` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspections`
--

DROP TABLE IF EXISTS `inspections`;
CREATE TABLE IF NOT EXISTS `inspections` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `financial_year` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_month` int DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  `block_id` int DEFAULT NULL,
  `society_type` int DEFAULT NULL,
  `society_id` int DEFAULT NULL,
  `upload_inspection` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `assign_officer_id` bigint UNSIGNED DEFAULT NULL,
  `submitted_to_role` enum('arcs','ado','drcs','registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `submitted_to_user_id` int NOT NULL,
  `current_role` enum('arcs','ado','drcs','registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` int DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspections_assign_officer_id_foreign` (`assign_officer_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspection_application_flows`
--

DROP TABLE IF EXISTS `inspection_application_flows`;
CREATE TABLE IF NOT EXISTS `inspection_application_flows` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `inspection_id` bigint UNSIGNED NOT NULL,
  `from_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user_id` bigint UNSIGNED DEFAULT NULL,
  `to_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_user_id` bigint UNSIGNED DEFAULT NULL,
  `direction` enum('forward','reverse') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'forward',
  `action` enum('send','resolved','unresolved','revert','verification','recheck') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `is_action_taken` tinyint(1) NOT NULL DEFAULT '1',
  `acted_by` bigint UNSIGNED DEFAULT NULL COMMENT 'action can only taken by',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspection_application_flows_acted_by_foreign` (`acted_by`),
  KEY `inspection_application_flows_to_user_id_foreign` (`to_user_id`),
  KEY `inspection_application_flows_from_user_id_foreign` (`from_user_id`),
  KEY `inspection_application_flows_inspection_id_foreign` (`inspection_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspection_application_flow_logs`
--

DROP TABLE IF EXISTS `inspection_application_flow_logs`;
CREATE TABLE IF NOT EXISTS `inspection_application_flow_logs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `inspection_id` bigint UNSIGNED DEFAULT NULL,
  `action_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_user` bigint UNSIGNED DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspection_application_flow_logs_inspection_id_foreign` (`inspection_id`),
  KEY `inspection_application_flow_logs_performed_by_user_foreign` (`performed_by_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspection_targets`
--

DROP TABLE IF EXISTS `inspection_targets`;
CREATE TABLE IF NOT EXISTS `inspection_targets` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `dist_id` bigint UNSIGNED DEFAULT NULL,
  `designation_id` bigint UNSIGNED DEFAULT NULL,
  `assigned_officer_id` bigint UNSIGNED DEFAULT NULL,
  `society_count` int UNSIGNED DEFAULT NULL,
  `created_by` bigint UNSIGNED DEFAULT NULL,
  `status` smallint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inspection_targets`
--

INSERT INTO `inspection_targets` (`id`, `dist_id`, `designation_id`, `assigned_officer_id`, `society_count`, `created_by`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 13, 5, 3, 5, 4, 2, '2025-07-07 05:37:34', '2025-07-08 10:38:30', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `inspection_target_flows`
--

DROP TABLE IF EXISTS `inspection_target_flows`;
CREATE TABLE IF NOT EXISTS `inspection_target_flows` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `inspection_target_id` bigint UNSIGNED NOT NULL,
  `from_role` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user_id` bigint UNSIGNED DEFAULT NULL,
  `to_role` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_user_id` bigint UNSIGNED DEFAULT NULL,
  `direction` enum('forward','reverse') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'forward',
  `action` enum('send','resolved','unresolved','revert','verification','recheck') COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `is_action_taken` tinyint(1) NOT NULL DEFAULT '1',
  `acted_by` bigint UNSIGNED DEFAULT NULL COMMENT 'action can only taken by',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspection_target_flows_acted_by_foreign` (`acted_by`),
  KEY `inspection_target_flows_to_user_id_foreign` (`to_user_id`),
  KEY `inspection_target_flows_from_user_id_foreign` (`from_user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inspection_target_flows`
--

INSERT INTO `inspection_target_flows` (`id`, `inspection_target_id`, `from_role`, `from_user_id`, `to_role`, `to_user_id`, `direction`, `action`, `remarks`, `attachments`, `is_action_taken`, `acted_by`, `created_at`, `updated_at`) VALUES
(1, 1, '6', 4, 'drcs', 3, 'forward', 'send', 'Target Assigned', NULL, 1, 4, '2025-07-07 05:37:34', '2025-07-07 05:37:34'),
(3, 1, '5', 3, 'arcs', 1, 'forward', 'send', 'Society Assigned', NULL, 1, 3, '2025-07-08 10:38:30', '2025-07-08 10:38:30'),
(4, 2, '5', 3, 'arcs', 1, 'forward', 'send', 'Society Assigned', NULL, 1, 3, '2025-07-08 10:38:31', '2025-07-08 10:38:31'),
(5, 3, '5', 3, 'arcs', 1, 'forward', 'send', 'Society Assigned', NULL, 1, 3, '2025-07-08 10:38:31', '2025-07-08 10:38:31'),
(6, 4, '5', 3, 'arcs', 1, 'forward', 'send', 'Society Assigned', NULL, 1, 3, '2025-07-08 10:38:31', '2025-07-08 10:38:31'),
(7, 5, '5', 3, 'arcs', 1, 'forward', 'send', 'Society Assigned', NULL, 1, 3, '2025-07-08 10:38:31', '2025-07-08 10:38:31'),
(8, 6, '5', 3, 'arcs', 1, 'forward', 'send', 'Society Assigned', NULL, 1, 3, '2025-07-08 10:38:31', '2025-07-08 10:38:31');

-- --------------------------------------------------------

--
-- Table structure for table `inspection_target_societies`
--

DROP TABLE IF EXISTS `inspection_target_societies`;
CREATE TABLE IF NOT EXISTS `inspection_target_societies` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `inspection_id` bigint UNSIGNED DEFAULT NULL,
  `block_id` bigint UNSIGNED DEFAULT NULL,
  `society_id` bigint UNSIGNED DEFAULT NULL,
  `inspection_status` smallint DEFAULT NULL,
  `inspection_remark` text COLLATE utf8mb4_unicode_ci,
  `inspection_document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `inspection_designation_id` bigint UNSIGNED DEFAULT NULL,
  `inspection_officer_id` bigint UNSIGNED DEFAULT NULL,
  `inspection_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_remark` text COLLATE utf8mb4_unicode_ci,
  `final_inspection_document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_designation_id` bigint UNSIGNED DEFAULT NULL,
  `final_officer_id` bigint UNSIGNED DEFAULT NULL,
  `final_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `inspection_target_societies_inspection_id_foreign` (`inspection_id`),
  KEY `inspection_target_societies_block_id_foreign` (`block_id`),
  KEY `inspection_target_societies_society_id_foreign` (`society_id`),
  KEY `inspection_target_societies_inspection_designation_id_foreign` (`inspection_designation_id`),
  KEY `inspection_target_societies_inspection_officer_id_foreign` (`inspection_officer_id`),
  KEY `inspection_target_societies_final_designation_id_foreign` (`final_designation_id`),
  KEY `inspection_target_societies_final_officer_id_foreign` (`final_officer_id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inspection_target_societies`
--

INSERT INTO `inspection_target_societies` (`id`, `inspection_id`, `block_id`, `society_id`, `inspection_status`, `inspection_remark`, `inspection_document`, `inspection_designation_id`, `inspection_officer_id`, `inspection_signature`, `final_remark`, `final_inspection_document`, `final_designation_id`, `final_officer_id`, `final_signature`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 1, 92, 7, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-08 10:38:30', '2025-07-08 10:38:30', NULL),
(2, 1, 92, 8, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-08 10:38:30', '2025-07-08 10:38:30', NULL),
(3, 1, 92, 9, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-08 10:38:31', '2025-07-08 10:38:31', NULL),
(4, 1, 92, 11, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-08 10:38:31', '2025-07-08 10:38:31', NULL),
(5, 1, 92, 12, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-08 10:38:31', '2025-07-08 10:38:31', NULL),
(6, 1, 92, 16, 1, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '2025-07-08 10:38:31', '2025-07-08 10:38:31', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `inspectors`
--

DROP TABLE IF EXISTS `inspectors`;
CREATE TABLE IF NOT EXISTS `inspectors` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint DEFAULT NULL COMMENT '1 = Active, 0 = Inactive',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `inspector_reports`
--

DROP TABLE IF EXISTS `inspector_reports`;
CREATE TABLE IF NOT EXISTS `inspector_reports` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` int DEFAULT NULL,
  `permanent_inspection_date` datetime DEFAULT NULL,
  `member_knowledge` tinyint DEFAULT NULL,
  `panchayat_suitability` tinyint DEFAULT NULL COMMENT '1-yes,0-No',
  `family_wilingness` tinyint DEFAULT NULL COMMENT '1-yes,0-No',
  `family_wilingness_reason` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_bank_capital_available` tinyint DEFAULT NULL COMMENT '1-yes,0-No',
  `authority_designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authority_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authority_signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `inspector_reports`
--

INSERT INTO `inspector_reports` (`id`, `society_id`, `permanent_inspection_date`, `member_knowledge`, `panchayat_suitability`, `family_wilingness`, `family_wilingness_reason`, `is_bank_capital_available`, `authority_designation`, `authority_name`, `authority_signature`, `created_at`, `updated_at`) VALUES
(1, 7, '2025-06-25 00:00:00', 1, 1, 1, NULL, 1, 'ccccc', 'sssss', 'inspector_signatures/MsMwsZnj0TYOyBUXW8HWIIGK6y8RszOkMT4RCdaI.pdf', '2025-06-23 10:53:10', '2025-06-23 10:53:10'),
(2, 9, '1970-04-22 00:00:00', 0, 1, 1, NULL, 0, 'Provident sint ut', 'James Walls', 'inspector_signatures/U1lv16wLhiqS5qzXtkz7ZETva4LmLbjsgjLQyDkm.pdf', '2025-06-26 13:09:42', '2025-06-26 13:09:42'),
(3, 10, '2025-07-04 00:00:00', 1, 1, 0, 'aszxdszd', 1, 'sffff', 'sdsds', 'inspector_signatures/67AgdY9Efza4qX4csC8g1pA8ZyqY1Tp6MakXVkXj.pdf', '2025-06-30 05:39:43', '2025-06-30 05:39:43'),
(4, 10, '2025-07-04 00:00:00', 1, 1, 0, 'aszxdszd', 1, 'sffff', 'sdsds', 'inspector_signatures/Eg6nZZv6ccs4RQpGkYQd0twZsED4is0gWmml1QNW.pdf', '2025-06-30 05:45:14', '2025-06-30 05:45:14'),
(5, 10, '2025-06-20 00:00:00', 1, 1, 1, NULL, 1, 'SADSA', 'AADA', 'inspector_signatures/TXHlpVoe86McGWhctyRsTlZba5eDlxxSLRLNCUC5.pdf', '2025-06-30 05:45:55', '2025-06-30 05:45:55'),
(6, 10, '2025-06-20 00:00:00', 1, 1, 1, NULL, 1, 'SADSA', 'AADA', 'inspector_signatures/VBfcZiDWzUTct25ih35BAdG3h93GtnNmWiVHQu7w.pdf', '2025-06-30 05:53:54', '2025-06-30 05:53:54'),
(7, 11, '2025-06-12 00:00:00', 1, 1, 1, NULL, 1, 'sdfsd', 'sdsfdsfs', 'inspector_signatures/baOpstepbLsCQNXnnQgJwH0hW2EABVBQ837XJJMW.pdf', '2025-06-30 07:07:01', '2025-06-30 07:07:01'),
(8, 12, '2020-02-03 00:00:00', 0, 0, 1, NULL, 1, 'Voluptatem Dicta of', 'Hermione Gibbs', 'inspector_signatures/Js9gcuphBIh62dT0y13lAzmOTCRbynlU7vneLViw.pdf', '2025-06-30 11:04:10', '2025-06-30 11:04:10'),
(9, 13, '1982-07-27 00:00:00', 1, 1, 0, 'Id excepteur aut ar', 1, 'Qui cillum provident', 'Damon Castillo', 'inspector_signatures/GoGYxLuWr01ocQ4gaTPsDzhuCXCqHjrXYVeg3DHW.pdf', '2025-06-30 12:37:54', '2025-06-30 12:37:54'),
(10, 13, '2012-06-19 00:00:00', 0, 1, 1, NULL, 1, 'Deserunt in delectus', 'Shellie Carlson', 'inspector_signatures/uNJmSuMFV7RIZvCN3BjlWUCirkAmZpScH5Ox7Bk7.pdf', '2025-06-30 12:44:33', '2025-06-30 12:44:33'),
(11, 14, '2025-07-10 00:00:00', 1, 1, 1, NULL, 1, 'bbbbbbbbbbbbbbbbb', 'dffffffffffffff', 'inspector_signatures/5Ut058Wvh43ep7oA4vgfcNeHPK1Md6tKyjFvKi8L.pdf', '2025-07-01 04:51:43', '2025-07-01 04:51:43'),
(12, 15, '2025-07-17 00:00:00', 1, 1, 1, NULL, 1, 'nbbbbbbbbb', 'bnnnnnnnn', 'inspector_signatures/1oF2PDHdDMbNrMPIQqgrvDcxn9ODAJIbJjII2D70.pdf', '2025-07-01 07:39:30', '2025-07-01 07:39:30'),
(13, 17, '1978-05-11 00:00:00', 1, 1, 1, NULL, 0, 'Vero quaerat asperio', 'Graiden Massey', 'inspector_signatures/eTjpYjUJx3ICutoJci0we3G2KuzYRCZ79NEOQ86J.docx', '2025-07-01 10:13:07', '2025-07-01 10:13:07'),
(14, 16, '1988-05-06 00:00:00', 0, 0, 0, 'Quis quis adipisicin', 0, 'Voluptatem Ut esse', 'Stone Mitchell', 'inspector_signatures/JepOmzfVmxYoU7wuaHrfFAnWAKA3LLPRCKdT44B9.docx', '2025-07-01 10:13:25', '2025-07-01 10:13:25'),
(15, 23, '1984-05-26 00:00:00', 1, 0, 1, NULL, 1, 'Tempore velit obca', 'Zelda Wilkinson', 'inspector_signatures/IZ8pt0U87KoCnruAnub7uG6QDoxXNpQI9fWdxX6X.pdf', '2025-07-02 10:54:30', '2025-07-02 10:54:30'),
(16, 18, '1981-12-15 00:00:00', 0, 1, 1, NULL, 1, 'Debitis provident d', 'Melanie Camacho', 'inspector_signatures/baApQNcDEVY7Y14KmZx1EI40cd4Ds0H07MOAOzcD.pdf', '2025-07-04 08:44:51', '2025-07-04 08:44:51');

-- --------------------------------------------------------

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
CREATE TABLE IF NOT EXISTS `jobs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `queue` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `attempts` tinyint UNSIGNED NOT NULL,
  `reserved_at` int UNSIGNED DEFAULT NULL,
  `available_at` int UNSIGNED NOT NULL,
  `created_at` int UNSIGNED NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
CREATE TABLE IF NOT EXISTS `job_batches` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_jobs` int NOT NULL,
  `pending_jobs` int NOT NULL,
  `failed_jobs` int NOT NULL,
  `failed_job_ids` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `options` mediumtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `cancelled_at` int DEFAULT NULL,
  `created_at` int NOT NULL,
  `finished_at` int DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `members`
--

DROP TABLE IF EXISTS `members`;
CREATE TABLE IF NOT EXISTS `members` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `contact_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aadhar_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_id` int DEFAULT NULL,
  `member_declaration_id` int NOT NULL,
  `gender` int DEFAULT NULL COMMENT '1-Male,2-Female,3-Transgender',
  `category` int DEFAULT NULL,
  `is_married` tinyint(1) NOT NULL DEFAULT '0',
  `father_spouse_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_buisness` tinyint(1) NOT NULL DEFAULT '0',
  `buisness_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business` int DEFAULT NULL COMMENT '1-private,2-public,3-Enterprise',
  `designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `membership_form` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `declaration1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `declaration2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `members_contact_no_unique` (`contact_no`)
) ENGINE=MyISAM AUTO_INCREMENT=142 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `members`
--

INSERT INTO `members` (`id`, `name`, `contact_no`, `aadhar_no`, `society_id`, `member_declaration_id`, `gender`, `category`, `is_married`, `father_spouse_name`, `is_buisness`, `buisness_name`, `address`, `business`, `designation`, `signature`, `start_date`, `end_date`, `membership_form`, `declaration1`, `declaration2`, `created_at`, `updated_at`) VALUES
(1, 'Alfreda Bass', NULL, 'uploads/aadhaar/Z3jWlBuMfIEc51e3b5b954IPw9haZ54Z8a8GALFc.pdf', 1, 3, 2, NULL, 1, 'Keegan Price', 0, 'Rhoda Collier', 'Distinctio Nemo sol', NULL, 'Tempora nulla totam', 'uploads/7ZbazwKyLy3Yibg5MJNrdk70Xvh4hOFozlYoYpIX.pdf', NULL, NULL, 'uploads/membership_forms/MYk1V1cZpwR2UJk18eUqdK7NLYmbQBSHoyclwKPe.pdf', 'uploads/declarations/9Vyem3ORuuTT3Q5fqK251PmnNDfW8v6KCCAG4jZ3.pdf', 'uploads/declarations/TuBXAUUuiaJes2ljfj7zwGSdq9e62XK5CPiAFI3l.pdf', '2025-06-13 07:04:07', '2025-06-13 07:04:07'),
(2, 'Sylvia Espinoza', NULL, 'uploads/aadhaar/KZ4Lu9zvUrRatevwB9cDxHOhiPLn8FnKU0bSLjX7.pdf', 1, 4, 3, NULL, 2, 'Denise Finch', 0, 'Martena Bruce', '65 South New Lane', NULL, 'Eos mollitia duis e', 'uploads/25iojpgMaki4XOsxX4piyoeiAwYeC1iO8UYjx2xp.pdf', NULL, NULL, 'uploads/membership_forms/srXJ8qmsXAKdjyMGg5GjthAKP4rYNaDcBKwCYy45.pdf', 'uploads/declarations/AYr4fPBAHFFJ67zWLBCAZGLxXA89dgaRnXUSL2Rh.pdf', 'uploads/declarations/KZ0gQdbQB6zBNgTB9EgILOmoOd0QdZb0BGe9PD0o.pdf', '2025-06-13 07:04:54', '2025-06-13 07:04:54'),
(3, 'William Patel', NULL, 'uploads/aadhaar/ASI4upyZGoKfQShUFn1MHUwWJeh0BivsfZRmEewL.pdf', 1, 5, 2, NULL, 2, 'Hyacinth Daniels', 0, 'Idona Ochoa', 'Nostrud enim qui sae', NULL, 'Quam sint consequun', 'uploads/WLSrvmhW8zy4faTNeHnJzjpBRZNo15iKONfnLjRK.pdf', NULL, NULL, 'uploads/membership_forms/phQAA4kpbHZS6XAtlCAqcDxSNW9CndCMYzsbzddm.pdf', 'uploads/declarations/VDJ0s0VbQllmeAu3FniPhjvJVBKCc0i4aeE5FDxf.pdf', 'uploads/declarations/QTM7snH3ICgNV1GjAgs0FllnBqxRg7p3RmbyuZ7m.pdf', '2025-06-13 07:06:42', '2025-06-13 07:06:42'),
(4, 'Kamal Calderon', NULL, 'uploads/aadhaar/MWQyz2ms0X1nvoOCumVq0JBqUaMp1vkMEkqAZIJi.pdf', 1, 6, 2, NULL, 2, 'Quentin Mcgee', 0, 'Vielka Carlson', 'Ut labore minim amet', NULL, 'Rem voluptate neque', 'uploads/leKbHaSCp4RsyH95emFDirzTNHQVqKtVptwYf4bm.pdf', NULL, NULL, 'uploads/membership_forms/gd3IWOGJNeJrkiEcd5N4gWlcwL5F2ucKRO1NFpsv.pdf', 'uploads/declarations/fVNSxyFJ8W2RK52I7byGNKLVNOo1C0Xz15L74UBz.pdf', 'uploads/declarations/1c68NfdzpfC62o7Yxu5e9HxZY6fTy7tXIh2TV3go.pdf', '2025-06-13 07:08:26', '2025-06-13 07:08:26'),
(5, 'Addison Ashley', NULL, 'uploads/aadhaar/GGBC9AbHumEdrRYaAyr7CWcS31ksE6TBHOSW3ov6.pdf', 1, 7, 3, NULL, 2, 'Piper Hart', 0, 'Carson Keller', 'Numquam sunt earum q', NULL, 'Soluta incidunt sed', 'uploads/wcAlqvMOXiSEf1RsW8OewdHngj5gMuBqBpctKdp1.pdf', NULL, NULL, 'uploads/membership_forms/4oLcE53AJD2bjfPJYeDC7PQJeE9Bi4DhH9nsSEtA.pdf', 'uploads/declarations/0tLUmSl1w2bApEUiLAbIUXoGfH55oahrlFBwDGcZ.pdf', 'uploads/declarations/Ud5lQIcRrsIP0DGZRWPqKtwuM8rq9qhvJwnM1uDd.pdf', '2025-06-13 07:09:12', '2025-06-13 07:09:12'),
(6, 'Calvin Rojas', NULL, 'uploads/aadhaar/ylgMl7HfCHE1u8PnZU2VoeWS4gv5Agg2uvN07CiK.pdf', 1, 8, 2, NULL, 1, 'Elton Whitfield', 0, 'Hadley Carlson', 'Molestiae recusandae', NULL, 'Officiis eveniet re', 'uploads/QQQpuYPNq5WQcada3dofNnxMqgRt9LdrsVj9e5v4.pdf', NULL, NULL, 'uploads/membership_forms/NTyxpHJgrmATNu9PQ9imQ3Lo3zW7gn3otLU6i40B.pdf', 'uploads/declarations/lE38JNFwMogvQDa0kNZdUPgxhFLYpk5BlGafysh4.pdf', 'uploads/declarations/RO3C073vS8T0X9FHMTXd8BF0DzVVAwau4K4kXP62.pdf', '2025-06-13 07:09:48', '2025-06-13 07:09:48'),
(7, 'Callie Green', NULL, 'uploads/aadhaar/RVhxTTvnpGaAhoe4EwlUONcSJYjmeU5ZVYGv8EZM.pdf', 1, 9, 2, NULL, 1, 'Freya Reese', 0, 'Abra Cantu', 'Consequat Incididun', NULL, 'Ab voluptatem commod', 'uploads/ooOK18uC9glSpsicehhJZoj9OR1We03YBeeZcWX1.pdf', NULL, NULL, 'uploads/membership_forms/YSS0R5OvJo1u6lTD5HfVQbsGKcLx6pLDhAIQkQHx.pdf', 'uploads/declarations/TMYHLrKW7OSYKFIOkSbr836zgrdKEhdRRRuElT7K.pdf', 'uploads/declarations/kG19L6BMJvovQnFDSorhuolHAC50mZCixb1ilma4.pdf', '2025-06-13 07:10:23', '2025-06-13 07:10:23'),
(8, 'Yvette Rice', NULL, 'uploads/aadhaar/hZ530s8Qz4XS4UG4PPLmqYjwQW9EchzcFgEvD9Op.pdf', 1, 10, 3, NULL, 2, 'Zachary Joseph', 0, 'Skyler Strickland', 'Non fugiat dolorum c', NULL, 'Et consequatur conse', 'uploads/dOE0BGKkSTatu8qNFFz2VgdsbHIBwA1x0cT0uZE0.pdf', NULL, NULL, 'uploads/membership_forms/P0bBoiJ0hfUURSp68w85lUT7ZQJ6yrtSku4KKZPg.pdf', 'uploads/declarations/WVDlm0OwWAH6WkkjRoO8vqQbYyAeWpqzG3XjbaYF.pdf', 'uploads/declarations/0cf2HtY0tA7O9rXx12HwwUB49jxUQlq6j04sH0Ha.pdf', '2025-06-13 07:10:56', '2025-06-13 07:10:56'),
(9, 'Willow Lucas', '9552417896', 'uploads/aadhaar/m9kBLVew3CuZFCKGbusuxVqR21SPdQ1XpmnB06sO.pdf', 7, 11, 1, NULL, 2, 'Nora Shaffer', 0, 'Blossom Compton', 'Nisi quibusdam ullam', NULL, 'In et quisquam perfe', 'uploads/l2HTjvjnFbIQEUo6hdMca5yxnhJpiE1jjLezZPwo.pdf', NULL, NULL, 'uploads/membership_forms/ZEq2xEBiG6HiAy8AeN3VHnLK0lrZWngr2IyJSLBv.pdf', 'uploads/declarations/F5RwcOJD0IqIPJ1pwvjYpX7oXZ1GLqM068PqBmqJ.pdf', 'uploads/declarations/sJE1GetzRJ2OkQ7dJ0ESawlSUbGpIQagQ8UfEmR1.pdf', '2025-06-17 04:59:29', '2025-06-17 04:59:29'),
(10, 'Amelia Rodriguez', '6789452147', 'uploads/aadhaar/8YaqApYHWaPQdEjV4ftJUaQFjGOrcoFUFCOgNLaR.pdf', 7, 11, 3, NULL, 1, 'Dora Petersen', 0, 'Lynn Greene', '32 Oak Drive', NULL, 'Et rerum placeat ad', 'uploads/RrGdbGZ1aQXTOawOSnsTd8n2B5lAsWDmCZm36mp8.pdf', NULL, NULL, 'uploads/membership_forms/u4SF8E5786XY3ObGOHoJULFye4N09NHfnZZZ7twJ.pdf', 'uploads/declarations/GOJ4lcnJpudjki9JuizjgLOPz56OGEjJmkvtyPQ0.pdf', 'uploads/declarations/XyWaoQLfKDM1ekfqHNzV7UlIlZlHVFiBxwgLD00J.pdf', '2025-06-17 05:00:38', '2025-06-17 05:00:38'),
(11, 'Howard Harrell', '2044444444', 'uploads/aadhaar/mdfBNViOsGR43Cdzn971EfcNhVID9eKQCHNeYiB8.pdf', 7, 11, 3, NULL, 2, 'Vance Blake', 0, 'Yardley Hughes', 'Aut consequatur dolo', NULL, 'Est atque quos paria', 'uploads/LlfKIhNHTzet5HV828CcctuqhZ058ylwJM2ABIxJ.pdf', NULL, NULL, 'uploads/membership_forms/k5trniyqnsVMBNBpAVOzGXbXTb8j2VFECwqWGAZX.pdf', 'uploads/declarations/H5eDRt6VahblzmvhXhvCI7BTwjUHtotfxwQro16d.pdf', 'uploads/declarations/0aEGv8vrMx3nbHoUsV0oEN6Zq2g2G8p54t5ayhdC.pdf', '2025-06-17 05:01:39', '2025-06-17 05:01:39'),
(12, 'Hector Estrada', '3655555555', 'uploads/aadhaar/QGf611lgunH5pEZRmyY3xUvfuyTYt9nrferPo8QJ.pdf', 7, 11, 2, NULL, 2, 'Blaze Bonner', 0, 'Ian Massey', 'Consectetur pariatur', NULL, 'Ut explicabo Quis e', 'uploads/hOhlf3Ngov8hSVhHVsoJQQa0qWCcVsJjPTxLcgPc.pdf', NULL, NULL, 'uploads/membership_forms/VAWH4WzjcM7sjOOIee5gKQPFDdzpRYfm0YCq5TQB.pdf', 'uploads/declarations/kAcEVrdxWlP6GCTt4rmAoc5Y9dLpRPoyrPl1DQoR.pdf', 'uploads/declarations/eQTuxaZRnA5Z1J1gYwMRZb2qFhpIkS4Rsg82Na4M.pdf', '2025-06-17 05:02:31', '2025-06-17 05:02:31'),
(13, 'Geraldine Miller', '6422222222', 'uploads/aadhaar/J5c5MBZPekxFBLl9UOEYnhBOJyYbdyfeYsACH77P.pdf', 7, 11, 1, NULL, 2, 'Joan Bradford', 0, 'Blythe Dyer', 'Unde cum in reprehen', NULL, 'Mollitia dolores ver', 'uploads/mIQXj4dXVndIyZ97ADrzrMj32VSFU7jlPDttervd.pdf', NULL, NULL, 'uploads/membership_forms/fHmuTI0S87t3qo5UWXTTe78YkiBmmSpDMNeDNkLs.pdf', 'uploads/declarations/2ejWOX3FyF5oAhWPcsobGD0p9JCRKxbes0EcuaZZ.pdf', 'uploads/declarations/na7VvZHgVDd4UEuZvqfQgC6PPWKQykaHG9Pz6PrI.pdf', '2025-06-17 05:03:15', '2025-06-17 05:03:15'),
(14, 'Blythe Stanley', '3111111111', 'uploads/aadhaar/pO5OKZJ1m1S1Awi0enJojfypovahYh6fPhnDKhMw.pdf', 7, 11, 3, NULL, 1, 'Macaulay Carver', 0, 'Dean Ray', 'Fuga Sequi laborum', NULL, 'Aut deleniti rerum a', 'uploads/VGr12k1BMpJvsKpuQaf362u78KTUFvsfYSatdfMh.pdf', NULL, NULL, 'uploads/membership_forms/UVfo3WIvcrlqUGlVMm2snP1efCeK4qkSnbaDqxs5.pdf', 'uploads/declarations/DZyDw2JuN5N6K0JNpxSn2zSw8dS5diICJi92y1cX.pdf', 'uploads/declarations/q9loeh87QPq5EEwjeuKGTM46x9ee0MOVWwRkMyVo.pdf', '2025-06-17 05:04:00', '2025-06-17 05:04:00'),
(15, 'Lynn Fitzpatrick', '2122223333', 'uploads/aadhaar/ORmMajJIvRk42ZedDJzdiduCO0zGqCL6wYm7Nrrv.pdf', 7, 11, 2, NULL, 1, 'Thor Deleon', 0, 'India Chapman', 'Perferendis necessit', NULL, 'Sit totam nobis at', 'uploads/kQv0gP8E3O101TplIc5CdOKXIh5wwMkABxGHg6Mu.pdf', NULL, NULL, 'uploads/membership_forms/RkVCat7CkVgNItzHwLxXkRGoQevJAUYACHnHAymA.pdf', 'uploads/declarations/l9iuYxlNXwYOSWLcsP4EdUa86sVbJG6x184ydbxg.pdf', 'uploads/declarations/JSqEc9kaFCLOmuV0uxhFIw4u3mqmsPymRQ33cDIT.pdf', '2025-06-17 05:05:42', '2025-06-17 05:05:42'),
(16, 'Cyrus Gray', '5488888888', 'uploads/aadhaar/W4qCvsOm1AYuX0nfuGXaQquaY44U9k6sdafXcAsP.pdf', 6, 12, 1, NULL, 1, 'Jolene Waller', 0, 'Victoria Barron', 'Ea quos ut amet qua', NULL, 'Omnis est laboriosam', 'uploads/1zzyC1GEAhqYwxqidMbjpjTrou5JetCQmdWMHZpd.pdf', NULL, NULL, 'uploads/membership_forms/OwG6Az4WcfCCRwhOfMy3CZcLRLHiKuKuOw4sNpsz.pdf', 'uploads/declarations/LayTLzuCI14s6Q7AJ6t8j08iWw1lvxmQXtIVsCiW.pdf', 'uploads/declarations/kCx9lHmcLq3MUGFHGw9u9sdQiLQnSGSI0KGMWyKi.pdf', '2025-06-17 05:41:33', '2025-06-17 05:41:33'),
(17, 'Quamar Cash', '8100008547', 'uploads/aadhaar/Jyk3ccc0sufj9n5vZxuBruWlDeAKs1uLDKJ8z4Dm.pdf', 6, 12, 1, NULL, 2, 'Teegan Riggs', 0, 'Alyssa Wright', '591 Cowley Parkway', NULL, 'Reprehenderit ad ver', 'uploads/XqRWUUyM5tnrI43KocYNAM0Mf6ZB5w8pUVy6kJBY.pdf', NULL, NULL, 'uploads/membership_forms/zeyQvxSISuvjsStl4LkBamCUmwqwJymuaqYnfkuV.pdf', 'uploads/declarations/QCAkVBRsOfVelXVv7danUk1Wx0M5wgzTXqzoHQsE.pdf', 'uploads/declarations/laWWqGvWFvFZu2YnZifRWPZ7jF2C6Ev3FQivmFyD.pdf', '2025-06-17 05:42:09', '2025-06-17 05:42:09'),
(18, 'Zephania Bryant', '7555555555', 'uploads/aadhaar/Zw5kzYXd1j5eLBKoQFZ7tjBhCdae7nOsnjuJWwRO.pdf', 6, 12, 3, NULL, 1, 'Lynn Weeks', 0, 'Tamekah Blanchard', 'Ut rerum molestiae d', NULL, 'Autem eum possimus', 'uploads/CcH4ukzNqAaMTXb15p0nw4QFUhPyhDNTdNYNRI70.pdf', NULL, NULL, 'uploads/membership_forms/AAS0G0lvxhvAsvo1mRbTRHk6lEndvCBKnwN3S9vq.pdf', 'uploads/declarations/9rwnj1vhA4pnI1oQXYZvixjETJ9GQoffNhHGxqNl.pdf', 'uploads/declarations/sUlYqRzSVXw6XNFxcDr6UGHewe5GHgbfb45xIQOm.pdf', '2025-06-17 05:42:45', '2025-06-17 05:42:45'),
(19, 'Kyla Roth', '2212123232', 'uploads/aadhaar/tW96TkafIIlEMxHcIMoTD2wuSUM2TKluvVm1gAAZ.pdf', 6, 12, 2, NULL, 2, 'Freya Holt', 0, 'Cecilia Munoz', 'Eiusmod ut asperiore', NULL, 'Amet voluptatem od', 'uploads/PtaKp9ldfHsXiK6GPqHsOaC0d08bcjummPKbN7OF.pdf', NULL, NULL, 'uploads/membership_forms/FWVM6Wz3sqPPnCnGuWqX7mpxsgfT4VsuMXDsbqwy.pdf', 'uploads/declarations/njbhogs3n5ZcWEgFpVwcjGFJupf2SpmQ4J2GT0J4.pdf', 'uploads/declarations/WSAOejS8n5yZiWpWSFzyjQQH3Td60Rng4yJsDzti.pdf', '2025-06-17 05:43:25', '2025-06-17 05:43:25'),
(20, 'Colin Peck', '2787878782', 'uploads/aadhaar/Zy6OOdfzhDeQA7jzpKzP13rKg37lKiMsotivP5o9.pdf', 6, 12, 3, NULL, 1, 'Brent Kline', 0, 'Maryam Best', 'Exercitation laborum', NULL, 'In saepe vel alias t', 'uploads/wwWU0PyMao16f35PCw9s4Zu0gcszUzxxAflZXtSx.pdf', NULL, NULL, 'uploads/membership_forms/Jth2GaU2KfmwjFCHGFBnyTKgBSvyMYIKme5sbIAN.pdf', 'uploads/declarations/o7LgqbitB7kIqFXPneiVMR1YR2ivYyctKw3el1oC.pdf', 'uploads/declarations/L8owHsAl892bugLTgS9nAe9hootKGXSfQVxDGjVE.pdf', '2025-06-17 05:44:11', '2025-06-17 05:44:11'),
(21, 'Jelani Hood', '6878787896', 'uploads/aadhaar/JIKJAw5A4P6N6EYodioMOwnFX8RK58GuSjaEdWpY.pdf', 6, 12, 3, NULL, 2, 'Anne Fisher', 0, 'Orla Perry', 'Nisi corporis accusa', NULL, 'Ullam illum ad enim', 'uploads/UtYDDCkORXUmPCZ2Ohthbs82NJI5Y76hlJiVD6nk.pdf', NULL, NULL, 'uploads/membership_forms/70jaIi9ZQVjcN2zMilAnCQOSmVEFsqHh1QcELmEE.pdf', 'uploads/declarations/w6bOwPr5xZ1dL0mCHugfXSjNDOzGkYYuGE1nXODl.pdf', 'uploads/declarations/Q3f5AHUDxuyzHZMN4qsJsmHZ12OvQjq1r8Bl0Z1I.pdf', '2025-06-17 05:44:51', '2025-06-17 05:44:51'),
(22, 'Hoyt Baxter', '2378787878', 'uploads/aadhaar/eKMN0pVRg0J5m70Gs82WhyXH8XXVxiTdjIOSpFKw.pdf', 6, 12, 1, NULL, 2, 'Christine Mann', 0, 'Vance Vazquez', 'Dolore adipisicing f', NULL, 'Vero illo et sit vol', 'uploads/IzxDGigWniuFoTC9m4pVPp7brFBFBK4lbFs1oFX9.pdf', NULL, NULL, 'uploads/membership_forms/nVo8JNfPjhrdoKZkWmKMGE4Bg6mkWVPm0kuKhpON.pdf', 'uploads/declarations/FcO0IjmagtYB9P2iawQw647f3qkyKrlOZ0xZsDfV.pdf', 'uploads/declarations/hlJV2niwEt1E6mpBrgd5XWRuuOXwIg2FhLtnF2zY.pdf', '2025-06-17 05:45:26', '2025-06-17 05:45:26'),
(23, 'Francesca Noel', '7852369875', 'uploads/aadhaar/EbEuxshRC7VEwHrlW4KgSpQZ0KvdCJgqB7XGieEh.pdf', 8, 13, 2, NULL, 1, 'Cassandra Cox', 0, 'Sopoline Ratliff', 'Et provident in rer', NULL, 'Voluptatem et volup', 'uploads/tAZnfXEonj0KEPwaZywRqjuQv31pbgMxOquKjcYd.pdf', NULL, NULL, 'uploads/membership_forms/5Z8IGnv4In41SWZHn93Gv0cmxBhDyH4Yx9oPw6vw.pdf', 'uploads/declarations/SrBj2Rv0tM5azAUM1auQh9JBkPYDqSce81dpOhpn.pdf', 'uploads/declarations/x6EUEOafUJZjgeTLjCqoxzTE8L7b2ow1Iy9Zzx7S.pdf', '2025-06-26 08:51:23', '2025-06-26 08:51:23'),
(24, 'Petra Jackson', '3985236985', 'uploads/aadhaar/MKJle4X5DXkuhp0206apVahLMw7cVOM2TvGRJQub.pdf', 8, 13, 2, NULL, 2, 'Cain Dunn', 0, 'Zane Golden', '20 East New Parkway', NULL, 'Cumque quas cupidita', 'uploads/0ZYPOKfVUtNuxzssRFWSM3l59kmPaf5p8sIQC9Co.pdf', NULL, NULL, 'uploads/membership_forms/5wancGYm7xb2Kwg1Ag1PqVXnre2on8SnOkEBq1sc.pdf', 'uploads/declarations/4udI3YyO1ShOP2YIhswSrWYMjjuRQsBHnAYhhzK7.pdf', 'uploads/declarations/5bsh0wYKqGYPA5asquLgcd4bQEMu8VVxH75UgGcT.pdf', '2025-06-26 08:52:13', '2025-06-26 08:52:13'),
(25, 'Anika Gentry', '8244441254', 'uploads/aadhaar/PxzMdv0lUKpy1WruRdFOqkWnYYMoZF3nv4ZnGcMR.pdf', 8, 13, 3, NULL, 2, 'Ferris Rowland', 0, 'Renee Jenkins', 'Omnis officia molest', NULL, 'Sint proident volu', 'uploads/rPxydegalYlJso5B4FXpCwuUKejm4RMjkHcS1zAk.pdf', NULL, NULL, 'uploads/membership_forms/9SiHg2sheJIoHk4ojTCrgMUgXKm6dxl49iDftlyi.pdf', 'uploads/declarations/1jWgnOS6vYkew6zT3psQPqvmjq8ReRL8c8wxdCZD.pdf', 'uploads/declarations/MlHwHp7NyMyxGfQ22rUCnYN6t6mks0Adl9HOCJqj.pdf', '2025-06-26 08:53:10', '2025-06-26 08:53:10'),
(26, 'Pearl Rasmussen', '5888745236', 'uploads/aadhaar/0HGnGrXggehrlgNqse6PfmNg5Qbmz5NIBoUIPVjV.pdf', 8, 13, 1, NULL, 2, 'Evan Cunningham', 0, 'Isadora Doyle', 'Placeat voluptate a', NULL, 'Veritatis cillum nih', 'uploads/JIjhfUGqSDEPDfArtGB8BAR0l6nX8A439jzQOSJR.pdf', NULL, NULL, 'uploads/membership_forms/Ue0qp7DPSGjMMHPRVc2CyKUxB2lOZTfShvr7VqPw.pdf', 'uploads/declarations/eAX0zk32INPP12RyqKxGWdAacneG8bJDoWv38L9u.pdf', 'uploads/declarations/AYkXJo2KagTdSBhNMYTGB5QBpfMb1Z9scPu3uzAx.pdf', '2025-06-26 08:54:00', '2025-06-26 08:54:00'),
(27, 'Dillon Davidson', '6978963258', 'uploads/aadhaar/5Jz6UeFtn8SZPv3iOPpAoQGVvMeB66fBISzmcH3o.pdf', 8, 13, 1, NULL, 1, 'Lev Jarvis', 0, 'Nathaniel Vang', 'Alias minim deserunt', NULL, 'Elit cumque dolor s', 'uploads/ChaK8NHhiwcumd4RlTCgpIcX1E2Iz0KowNrtSE8r.pdf', NULL, NULL, 'uploads/membership_forms/engWOjhOk4o0Bc53Kh9b2NBW1gqs9Hcuc90P0uUV.pdf', 'uploads/declarations/utOkWN3zlb8Df2WqV7wNCnGJbRFXUjte7Qk8CmgR.pdf', 'uploads/declarations/2uuBLn42OCHIHF7deXyoACVgpgQkTUD8lSkVL5oF.pdf', '2025-06-26 08:55:12', '2025-06-26 08:55:12'),
(28, 'Sigourney Holland', '9555253698', 'uploads/aadhaar/AULDUrlVLaYzWX9TEt1Rgh7tYnh8GNPqOduM3HK6.pdf', 8, 13, 2, NULL, 2, 'Mary Little', 0, 'Kylee Farrell', 'Sapiente et dolorem', NULL, 'Fuga Esse ut et mag', 'uploads/gqJVn29yVYr5gQ6HCFUImddIbCcsk0CRESPql9W2.pdf', NULL, NULL, 'uploads/membership_forms/jz4yxnsZgyeOJ02LJ06p3UCnQffmhAIFtkpyUfXe.pdf', 'uploads/declarations/Rp40dTpMrgMroVoQOYC037sJ2Id7T6jyEk6vQwBT.pdf', 'uploads/declarations/VA9UxgXM2YfCZufZJWHfeDSbe3nQU7fiGfu9hj3O.pdf', '2025-06-26 08:56:13', '2025-06-26 08:56:13'),
(29, 'Orli Sheppard', '2445123258', 'uploads/aadhaar/OUYF7qFSlmtKUglZVAGNHoByQ0qrA61JOGRHeFwA.pdf', 8, 13, 2, NULL, 1, 'Kendall Reeves', 0, 'Clementine Gillespie', 'Quos dolores in cons', NULL, 'Inventore sit animi', 'uploads/BGo9AaZA5BB1OiBtdg0ztdrJExp00GiLtmwMaToS.pdf', NULL, NULL, 'uploads/membership_forms/nQfPy0SCadcXxMks4uYFJYtoVqA1DsJw7AieVqEw.pdf', 'uploads/declarations/2s746U4vPohMkgRmyRnGBtu9m64zVzq65RQ1VUqF.pdf', 'uploads/declarations/jfXWpkSrejL35Z0oyT54Mkzzl0HOKWPFU33SzbsR.pdf', '2025-06-26 08:57:02', '2025-06-26 08:57:02'),
(30, 'Delilah Dodson', '4485858585', 'uploads/aadhaar/8DlZZHg69n0LFoWd52QVtC7yjyeK5b18dmbNw1SZ.pdf', 9, 14, 3, NULL, 1, 'Clementine Hendrix', 0, 'Hayfa Gibbs', 'Ut quis commodo pers', NULL, 'Impedit reprehender', 'uploads/beY5NYZscO4U1io1ErJ6zzoW9pdB1aM0gN7iEwvK.pdf', NULL, NULL, 'uploads/membership_forms/BHOi8Y56JA7PtnCcin9brK5YZmTBgmtR7Hr8TnT6.pdf', 'uploads/declarations/Sx6CUL9bi1TqfmiHqNDEAsNrHJQO55JqQJgRAof3.pdf', 'uploads/declarations/hzE9KcOO6oIuEnUlxVUqhWMhCXHSJ2s4jm0i7Pn4.pdf', '2025-06-26 10:33:02', '2025-06-26 10:33:02'),
(31, 'Simone Bright', '3277777777', 'uploads/aadhaar/n1amrQTCmjwrf24kXyAzzDcB5i1ji6BdCee9fJVf.pdf', 9, 14, 1, NULL, 2, 'Sophia Russell', 0, 'Preston Duke', '484 Cowley Road', NULL, 'Delectus deserunt q', 'uploads/4ZoIanYL48HxSkN5I3fm8n9dSKPoKX8ld9oSeFcg.pdf', NULL, NULL, 'uploads/membership_forms/FHqIPseTJiFjHpxlWvcAvK5dIR16QaHdx4I93YpC.pdf', 'uploads/declarations/r7TZmVBFdHSeAzoQvUMHcktxbgUDaGnXU7YMfOSH.pdf', 'uploads/declarations/TVHBGnWmVIrC5Cppw9vYO589SyK1Dcb2cxgFlpYy.pdf', '2025-06-26 10:33:45', '2025-06-26 10:33:45'),
(32, 'Madison Horne', '5525252535', 'uploads/aadhaar/R2lJgHsTXv1G3F5iVNs8Cy6fuaE8o9ptMAsTaoxM.pdf', 9, 14, 2, NULL, 2, 'Noel Kirk', 0, 'Kimberley Eaton', 'Impedit elit quis', NULL, 'Sed fugit atque iur', 'uploads/3EQNhTBybD2HnFNklYmuYyJyAAjRqhlAaxGhfTdn.pdf', NULL, NULL, 'uploads/membership_forms/AL9h2dHLqIlJvdOU0xUGPv1nEaEfLgXE8F524DEd.pdf', 'uploads/declarations/1oBXIbH6BpYb8DlKPijheFEnmcARNkX5q37TP6B4.pdf', 'uploads/declarations/No2GqHWrQ2Vly0dkYF2LztMBHEE4uibCz845GPbw.pdf', '2025-06-26 10:34:58', '2025-06-26 10:34:58'),
(33, 'Briar Hayes', '4000852147', 'uploads/aadhaar/udZLFBxvLYntja9HIyonRm5DSUzIDM31DTaARinR.pdf', 9, 14, 2, NULL, 2, 'Athena Morton', 0, 'Nina Whitfield', 'Quas maiores consequ', NULL, 'Exercitation volupta', 'uploads/hd1gdVgSouH5k1T4zlYo26zCWID5SKkZVXlZBi3H.pdf', NULL, NULL, 'uploads/membership_forms/DyPd0K2gPcguwBtPZhqf2CYn6urTRgY1UcQQBHPF.pdf', 'uploads/declarations/nvzsDZo1926IVcIaHqhFQhPDWJjeqTxQXXOhZmN3.pdf', 'uploads/declarations/iKrSCL2DMfgx4O9b9K5Dt2qgZ5uAhCWrr29LrJqn.pdf', '2025-06-26 10:35:36', '2025-06-26 10:35:36'),
(34, 'Erin Harris', '7874741452', 'uploads/aadhaar/qcslnBSTDwm9R439ELNPD83xdMhMv6ubqCUzPZA9.pdf', 9, 14, 3, NULL, 1, 'Robin Avila', 0, 'Shelly Giles', 'Nobis voluptas ullam', NULL, 'Aut voluptate nisi v', 'uploads/VPL1SQpXSlEQvtDakPtBAXOOvsC78N4mFH8JYikC.pdf', NULL, NULL, 'uploads/membership_forms/TS1J9iLtfASSA47JU5v0YLuxZVtmSAgAfmkQ87eR.pdf', 'uploads/declarations/3DtJXqhTow8fb2HK3u3KtUpAzY5hEScVPqUYXsR0.pdf', 'uploads/declarations/DSYeaBzss8DdLtYNyf9n9oWEyyfZ6OY7zko4c9P3.pdf', '2025-06-26 10:36:17', '2025-06-26 10:36:17'),
(35, 'Wynne Collier', '7585854269', 'uploads/aadhaar/4W72q3ojblIBPyEhjX7KlEAo7BFBYS3KlgPMNWI0.pdf', 9, 14, 3, NULL, 2, 'Yuri Payne', 0, 'Michael Charles', 'Magnam asperiores do', NULL, 'Quia porro provident', 'uploads/whlYa2K7prJqTmYFRgzHPGZXjbB2SukXWbzQ4jiZ.pdf', NULL, NULL, 'uploads/membership_forms/LGto99lghvl21qtQwJfdUYdRphoU7ds6OjCv3Lxg.pdf', 'uploads/declarations/zVSKJUOPcjYFvzyCD6Wge6CiUNY85dZRWFYUXwBn.pdf', 'uploads/declarations/z0krpaswANDnbgqawIUkJuh8oWgoUK4NEhcxqFqE.pdf', '2025-06-26 10:36:59', '2025-06-26 10:36:59'),
(36, 'Marvin Dennis', '5778451236', 'uploads/aadhaar/JWAtDSnWAMaftxk38pH9KunpUnJu1tRdisdVbiSd.pdf', 9, 14, 2, NULL, 2, 'Alexis Harvey', 0, 'Henry Jackson', 'Odit et enim dolore', NULL, 'Fugiat ut voluptatem', 'uploads/9PPiS5qu556CVyKHdoDy4zxB8Htl3JMpk28MqBxE.pdf', NULL, NULL, 'uploads/membership_forms/OIR3Wk4Q2jYV5fwFr5G9r7NWQ016ZKdANRaVFUFh.pdf', 'uploads/declarations/Fnl3i3ZRiJjLnW47MfYl4RrRSV1htsplnVAleohT.pdf', 'uploads/declarations/3ns7EPxCDc8qinkYSTAESYNWd6k8K6R1UGXDKYX7.pdf', '2025-06-26 10:37:33', '2025-06-26 10:37:33'),
(37, 'Lionel Guthrie', '1667908978', 'uploads/aadhaar/mW8nisIKdbS6RzOEvRyuHqCm5ZK7zHB5eVr7R8iL.pdf', 10, 15, 2, NULL, 2, 'Raymond Sharp', 0, 'Larissa Myers', 'Enim molestiae nostr', NULL, 'Cumque eveniet earu', 'uploads/eHBH3rDtxf9Udh1GlGxwY690QSRozKJfRwFpLD5h.pdf', NULL, NULL, 'uploads/membership_forms/IzEPyfEjwhATtnC2wKQL4QKIbTgPdcPpCwkdzUSH.pdf', 'uploads/declarations/kmeQUVYlbDjymNmJYD1EVj26SWNfiI5jIQ0bfcbW.pdf', 'uploads/declarations/VI2lhrUdjJGNO6piDuRQw5nd8HSseKkMfczcwwgS.pdf', '2025-06-30 05:07:25', '2025-06-30 05:07:25'),
(38, 'Hanae Cardenas', '7609897867', 'uploads/aadhaar/O7YyhWDTuqHKIuog6PBSbWrpDbKdTpX0NZaxRp4Q.pdf', 10, 15, 2, NULL, 1, 'Abigail Mclean', 0, 'Kiara Lowery', '738 White Oak Court', NULL, 'Consequuntur laborum', 'uploads/CvZborGDFFcaV0C24sTwvGIucXnLhrW2NFJ74N7Z.pdf', NULL, NULL, 'uploads/membership_forms/UoevEpn6oG4o8UG0QZe9ndOu7nSyBlsxpck0zP3O.pdf', 'uploads/declarations/dtep3qbmCgoKNG8RQaQNxwcu7XfO9Mw2tjfV7OhT.pdf', 'uploads/declarations/2eStVZ4uqfRUS65dtfHEKdZfVjNpXO5m5TLL9EhI.pdf', '2025-06-30 05:08:05', '2025-06-30 05:08:05'),
(39, 'Maisie Gilmore', '7577778574', 'uploads/aadhaar/j2QNvqqetMekwteXj4KAqiskFdhH0M8z5gXyMJZJ.pdf', 10, 15, 2, NULL, 1, 'Yvette Flores', 0, 'Neil Jensen', 'Consequatur et illu', NULL, 'Proident velit qui', 'uploads/qBzWqHtmNQEEZQaNBmvh8Hoz7ZN1EOIPIzAy0KCS.pdf', NULL, NULL, 'uploads/membership_forms/WPrS7GVUTyJ5l5Ts7GZl7rsKXlHL1KvORsz7s4dR.pdf', 'uploads/declarations/e4kTDaTDINlYctFM6f2n1ix0Ua0LG8XWkN3iFxgf.pdf', 'uploads/declarations/RQFWIVsSkvBHdTmY4BrvvcuDd5J4K8n3hhSRXopk.pdf', '2025-06-30 05:08:52', '2025-06-30 05:08:52'),
(40, 'Silas Pacheco', '6200897867', 'uploads/aadhaar/skV1OLJtbjIyLPpwod0bDP7c2qFbStDhZdLMkH2E.pdf', 10, 15, 3, NULL, 2, 'Kylie Powers', 0, 'Roanna Wilson', 'Eos cillum earum ut', NULL, 'Sequi elit aut qui', 'uploads/lAHeDQN5y27IpUg26vzJlnYXlz4vNX9ev1Lwt62o.pdf', NULL, NULL, 'uploads/membership_forms/JIwXgcKGbGE7DkHtMv8MBHsdrz9dlCL44GTy8O9f.pdf', 'uploads/declarations/v050GbXVMGjD1HnZq4htX2B6WTYujw6eno3TcAl5.pdf', 'uploads/declarations/qbR11fbLQIcgfxCQsiiRIUARPF4w9GWAycKRvY9P.pdf', '2025-06-30 05:09:46', '2025-06-30 05:09:46'),
(41, 'Axel Rios', '2567907867', 'uploads/aadhaar/boGUFHMm2XTCJBEcbvSmAv6OBKFHuupAAqYDPufM.pdf', 10, 15, 3, NULL, 1, 'Gannon Silva', 0, 'Xandra Schneider', 'Do distinctio Minus', NULL, 'Et enim exercitation', 'uploads/MT3F2nPzgBJfC86bTBdFH76fHVnSdpDhMKCPEtQx.pdf', NULL, NULL, 'uploads/membership_forms/99IPd7nj2gblFmc8vDDcxWeqRDxe2nPp5VB3TRYL.pdf', 'uploads/declarations/fY2lyZLBd7TQmS3IAoSEabfvYGBqVgutPqVyaxme.pdf', 'uploads/declarations/hVgSQXWWCRDouzKJneddBvXRVaYGvCXs4XCbVnYL.pdf', '2025-06-30 05:10:24', '2025-06-30 05:10:24'),
(42, 'Dahlia Mills', '4422222536', 'uploads/aadhaar/mCMo3b0yp3cH8l89uJC1ma3ocqLKdj82frsrNqmZ.pdf', 10, 15, 2, NULL, 1, 'Daquan Yates', 0, 'Murphy Dixon', 'Doloribus enim volup', NULL, 'Necessitatibus dolor', 'uploads/XpdWQ4mkvgIv69exCoNlBJaM5xcV6ytKfTikODnI.pdf', NULL, NULL, 'uploads/membership_forms/5YJe58OKVsxJnmv31wR1FuaAKIiWt9g2U1BZr4NM.pdf', 'uploads/declarations/FrX59IZECatXQijNko7XbO5cadUzrczqaFw1c971.pdf', 'uploads/declarations/gFuUTIdXbyLt4ncMJLfJ6jGWqlUF0UqDDpVtBjBa.pdf', '2025-06-30 05:10:59', '2025-06-30 05:10:59'),
(43, 'Ferris Moon', '7777854785', 'uploads/aadhaar/AWUmpDNHHHsmf8Hpb1eJYOANegAsLwaDwWvnzJ75.pdf', 10, 15, 3, NULL, 1, 'Ashton Foster', 0, 'Dara Fields', 'Dolorem hic quam ut', NULL, 'Sed voluptatem illo', 'uploads/5VFIUt1guV3Ai4ZNKCnRIFLugV7hua38JapEnAzH.pdf', NULL, NULL, 'uploads/membership_forms/uXnIeTWydkVUymKiVpva48m0F1RImZI8dnFSqeSo.pdf', 'uploads/declarations/BqvNsowfQwVVDyIFxjJu3pVucRC7Bfl025UiDq9N.pdf', 'uploads/declarations/G0eb0nLaZ25Zb9KyHOIot8TDcqDKzs0rm208OykR.pdf', '2025-06-30 05:11:37', '2025-06-30 05:11:37'),
(44, 'Hedda Stein', '5852741369', 'uploads/aadhaar/BHhC8PTVHIDn4voab2xahhtkcvSaddXX834v4P3O.pdf', 11, 16, 2, NULL, 1, 'Winifred Simon', 0, 'Jordan Brennan', 'Dolor architecto qui', NULL, 'Nihil sunt et distin', 'uploads/MIL2bLMm742r49rJIGAunDnZ8VmeXa75ho7ySeDW.pdf', NULL, NULL, 'uploads/membership_forms/6sdqhQnbr69TrGiLtXqBOx7UGDhTUMfoHCBhSsId.pdf', 'uploads/declarations/2IVfB3fxPwHwpXYlfiFkYRREy0tigWQUtaD6ITOQ.pdf', 'uploads/declarations/sZSBJUD4Rj0u1C4QvFRUd0pcX3GE3eNKuX4xOrSI.pdf', '2025-06-30 06:56:18', '2025-06-30 06:56:18'),
(45, 'Hayfa Good', '7674123698', 'uploads/aadhaar/VyKDSIC6pueRqKPGA09Nqjs5cBpfwttPQisge2sc.pdf', 11, 16, 1, NULL, 1, 'Hedda Yates', 0, 'Herrod Hogan', '496 North Oak Road', NULL, 'Quis aliquam omnis s', 'uploads/A11SHyaO9DmopTCcDxHk39kkzzK95i03mJKNtEAz.pdf', NULL, NULL, 'uploads/membership_forms/yHMlj5PbC4WUOCgWm1ZTDLQKgljZ3j0x9cO2AOVO.pdf', 'uploads/declarations/O0wt0segx6pQ2Tcdj1MEC5AvzRXKm162kQtFp4sU.pdf', 'uploads/declarations/9s6XBLVFckOMkR9jow4czsAOfscXXhZ9JuCmmhLP.pdf', '2025-06-30 06:57:25', '2025-06-30 06:57:25'),
(46, 'Mikayla Glover', '3911111125', 'uploads/aadhaar/GlLdUPfWkbzelVxMeXG2cPqGKC4vhPclgaK4hcly.pdf', 11, 16, 2, NULL, 1, 'Destiny Sheppard', 0, 'Dante Schroeder', 'Sit velit magnam ut', NULL, 'Fugit et voluptatem', 'uploads/L9Ox9po0VMW02tcftR9OI69ec8m2pYXp03o0t3Qm.pdf', NULL, NULL, 'uploads/membership_forms/DzaXKDH10wWTgHmUU234A71xs1O7arzIklN5goRP.pdf', 'uploads/declarations/jRubQIgk9C0SOtInnVtR4gh6EHTyearb4HFIBycH.pdf', 'uploads/declarations/WsSgcrAqeXewx2DaARaDnVsxkhQczjCeMccEomBm.pdf', '2025-06-30 06:58:03', '2025-06-30 06:58:03'),
(47, 'Clementine Berry', '4385236974', 'uploads/aadhaar/M17YMI0ZdZLAKhyKFznBR5aEaIL2hnW0WOjwPWu5.pdf', 11, 16, 3, NULL, 1, 'Noel Camacho', 0, 'Mechelle Terry', 'Voluptas libero quo', NULL, 'Ipsum quaerat volupt', 'uploads/OWcT5CUfPHE6Q74jwhy7Qfq254E72oJZ1VkcMoeW.pdf', NULL, NULL, 'uploads/membership_forms/x25hCslFNV8VFMnPEw2RwYbNurzw7uOmY8y0H6qk.pdf', 'uploads/declarations/K1GyOzUaFndg1eH7F0sZuGcbCugJWUhkMB3gvohb.pdf', 'uploads/declarations/lkMXPMlvDngxUfnioa8z6J8uV5iuGXgnE2pXkwA5.pdf', '2025-06-30 06:58:38', '2025-06-30 06:58:38'),
(48, 'Sophia Lang', '1001234569', 'uploads/aadhaar/YYRudFgbpmCWUZbu565ZRlmuJOo0NqlVSMVQS7JS.pdf', 11, 16, 1, NULL, 1, 'Jonah Wilkerson', 0, 'Zia Ramirez', 'Qui totam deserunt d', NULL, 'Et magnam quam susci', 'uploads/lBzjTaeqisV1QsMBl48eIMSoDOFkFqa71PYKwRNB.pdf', NULL, NULL, 'uploads/membership_forms/MQ3lyqLRJlFcNZxknNdgXaeV1fJEIc8QrQRChxla.pdf', 'uploads/declarations/sTjJzYvAB5g2QfAbJZVqWpGZW3ChyiUrBaG0h6Uo.pdf', 'uploads/declarations/z7X3Jdu6Q1DjxGiZM2MBmIAE2aONuxqvC7gpls4f.pdf', '2025-06-30 06:59:11', '2025-06-30 06:59:11'),
(49, 'Gannon Park', '5352413698', 'uploads/aadhaar/RDsJ3jw3NiYpKi8JxlyYTDBgbek8wY0lA57L4Qen.pdf', 11, 16, 2, NULL, 1, 'Joelle Haley', 0, 'Ann Jennings', 'Nemo culpa facere a', NULL, 'Quae voluptatem Max', 'uploads/Gux39PDbOCZRctRLSa9emeYT0qT7tdtvUQj2k4Ys.pdf', NULL, NULL, 'uploads/membership_forms/6SlyCsQBpbu7aSbRhAjl0jo6X2DFfeyXzTUCvBlm.pdf', 'uploads/declarations/GPR48wn4ZEDAyw9WlK4lHwSdXRsMKSPJLs8x7Tk7.pdf', 'uploads/declarations/HoYbkRDuIwMWp2J6xINXtj75gBp64teuFSyjU64Q.pdf', '2025-06-30 06:59:43', '2025-06-30 06:59:43'),
(50, 'Kirby Hanson', '4885236987', 'uploads/aadhaar/6NYBy2B5N7sFiuIAPcGPuvMqUx4toK7C8FkXTzh9.pdf', 11, 16, 3, NULL, 2, 'Leigh Goodwin', 0, 'Chanda Valdez', 'Repudiandae earum id', NULL, 'Maiores reprehenderi', 'uploads/YC1LdonW7YQVpZa8arczeoLz2cmt8c1FIVUS1CMm.pdf', NULL, NULL, 'uploads/membership_forms/4xeA5MIVISIbHjQie2bU9b4pMTkAJ0o5RxwbMv2X.pdf', 'uploads/declarations/IrF8nYVmXAA3r1goed16ApFPCLaVnpRRdTPPSaPQ.pdf', 'uploads/declarations/sYJ7STbBAParEeDZ3WgMylPEuaEY3odKHnYV1Ttn.pdf', '2025-06-30 07:00:16', '2025-06-30 07:00:16'),
(51, 'Drake Miller', '6374125896', 'uploads/aadhaar/yuk77cwXHfiq5ubIMGCSQd3slzCFo6OCTEtjkNUT.pdf', 11, 16, 2, NULL, 1, 'Lacy Roman', 0, 'Zachery Oneil', 'Ipsum aut nobis qui', NULL, 'Suscipit reprehender', 'uploads/omcoaL33zURUHpSivbvg4UOJz6u4Syq1qb5Macg5.pdf', NULL, NULL, 'uploads/membership_forms/2nlxSaiVZDJ9TnswvCcUOdd1PCB8PyAwrSFqjJVF.pdf', 'uploads/declarations/goENmv8yn6pzQH4jhbXPpSZjff62ILQNayxMcrD8.pdf', 'uploads/declarations/F9MwrjcN2SFemuF59nOUgAuqsxLdBo9knsf4p4Zo.pdf', '2025-06-30 07:00:59', '2025-06-30 07:00:59'),
(52, 'Colleen Duffy', '9485236974', 'uploads/aadhaar/oifvvU2pukSLWt4o0DlmWQUKkzaVu55Q3XdJWkWU.pdf', 4, 17, 1, NULL, 1, 'Hop Dixon', 0, 'Michael Bryant', 'Cillum culpa nihil', NULL, 'Autem quia vel aut d', 'uploads/IBkvYHQHzqUnHCoPjPbbxVXtrFJvfRcAn124i201.pdf', NULL, NULL, 'uploads/membership_forms/vC0jHrIapGpRM50frfSSa8T5SamNMf91OPe5ng1p.pdf', 'uploads/declarations/vTm1XQU2eudgvcOrBPvNhZWh5R2vJ8xLoKNbQW6T.pdf', 'uploads/declarations/sQvL2tvfMsm8HVe413NAdzJ48e42ELUY4J4SEoAZ.pdf', '2025-06-30 08:38:10', '2025-06-30 08:38:10'),
(53, 'Quinn Salazar', '1885236985', 'uploads/aadhaar/324OKrTYY0XR3tpghCfi7No8o33TX16TLeNXN3l8.pdf', 4, 17, 3, NULL, 1, 'Ramona Kirkland', 0, 'Raphael Chavez', '268 Milton Parkway', NULL, 'Nostrum eum rerum ex', 'uploads/EIl3cQl4OhTdGAJITkY2PqSpk4kdkfbrejz4Ib71.pdf', NULL, NULL, 'uploads/membership_forms/cKUCIwiGyysC54f6ceIkx49aFlZxdfUws0rDWyvw.pdf', 'uploads/declarations/ZHdq7Gi6Vs7hvQejhsmLpJv96QHrRHdiSmGo0CXx.pdf', 'uploads/declarations/XUFdjHDhlwrCqk2sq7ZqGvdVoADmBzu0yOtectZt.pdf', '2025-06-30 08:39:58', '2025-06-30 08:39:58'),
(54, 'Sybil Solomon', '4585654565', 'uploads/aadhaar/mrWdnPtV7RIc8QuCOB2rbpc0m7DJa98xGbKtsgm1.pdf', 4, 17, 1, NULL, 2, 'Burke Booker', 0, 'Signe Dawson', 'Rerum nemo cupiditat', NULL, 'Anim veniam rerum n', 'uploads/7tImUiNmIs3dTTvQhK5BiE9piA0DkakWnSWWuo90.pdf', NULL, NULL, 'uploads/membership_forms/qACSyZmyzbic9Ci6R2jf6iSAKUHlo45QY4GIZtzp.pdf', 'uploads/declarations/00OlTDFqMPOfAe7MwAKOg8AvV4eltfwbxsBz9wZ1.pdf', 'uploads/declarations/P36TqOPK5CfmvwQovGxq2XOJH6lHX6oL9uvteWzo.pdf', '2025-06-30 08:40:50', '2025-06-30 08:40:50'),
(55, 'Beau Heath', '9978451236', 'uploads/aadhaar/5aP0uT12pBTwQPHRtOIE3xnMdsQGCriYIiBgLIIF.pdf', 4, 17, 1, NULL, 2, 'Sydney Elliott', 0, 'Jonah Wallace', 'Et reiciendis lorem', NULL, 'Et dolores ipsam sin', 'uploads/jCUePVyvGLvKlEOb72YlWicAvtT5vPYgKx542eBU.pdf', NULL, NULL, 'uploads/membership_forms/TycMx4v7gpWtdJp0OxESfdjNRs0BE0fHhFm5PcK4.pdf', 'uploads/declarations/NziAtFkjHbEQ6Li03I6yfZXYeCts6N52DCOSFEN3.pdf', 'uploads/declarations/e4aAQ23xxR7qNXD1JhRQMlb3uI74Ne7nq1oQRHIT.pdf', '2025-06-30 08:42:06', '2025-06-30 08:42:06'),
(56, 'Bo Schwartz', '4478963255', 'uploads/aadhaar/kMPVsuevGvcVNJd7MrZqPcpnlQscPPQYn1PuL5Zn.pdf', 4, 17, 3, NULL, 2, 'Orli King', 0, 'Jermaine Donaldson', 'Praesentium veritati', NULL, 'Eos quia excepturi', 'uploads/x7XY3AjoQdbJlONzYA9U9WK2bLcYy56j1R3ppwRD.pdf', NULL, NULL, 'uploads/membership_forms/RAB25yz3tAcz84MNAV3TUlqPs80zwinXAtHF9BNY.pdf', 'uploads/declarations/GlSSFlFiYefKYSa6moH7N8ukCae4J6N1KYFfMWF6.pdf', 'uploads/declarations/lnz9MnudevfSfWui08456RxhlgdR3OlRTRn8Sg1N.pdf', '2025-06-30 08:42:55', '2025-06-30 08:42:55'),
(57, 'Yuri Patton', '5685236541', 'uploads/aadhaar/MDR3SNFwdJbt4IyNr8Vh05WW9KIsdw4xkrSsdfJQ.pdf', 4, 17, 3, NULL, 2, 'Nina Fowler', 0, 'Elvis Schultz', 'Deleniti debitis eum', NULL, 'Et et aut tempor sun', 'uploads/n42jkBYQVaxTJgOoiy6JPbXZwaQa1E0qhnOA2a9v.pdf', NULL, NULL, 'uploads/membership_forms/8UObhaWdaqYeYaIzEteo7ZTOYi3oZ0Ec86Xs1gN8.pdf', 'uploads/declarations/I73O0FOx0wSU1mV0psG0uP7fpEr6l29Nl2qm4nw3.pdf', 'uploads/declarations/EHyAc6XOZqLZJvyjaKq6CyE1mEBIPnauHVw2xg44.pdf', '2025-06-30 08:43:42', '2025-06-30 08:43:42'),
(58, 'Fatima Mercado', '9112333212', 'uploads/aadhaar/5CeqBWgaJKBwKD65NLMcfdBXFzsdENMNdhGqypXM.pdf', 4, 17, 2, NULL, 2, 'Sierra Singleton', 0, 'Emerald Puckett', 'Praesentium sit in a', NULL, 'Qui aliquam ut totam', 'uploads/C9UzkDyJ52HYMDKMgr4v9bbO4bsdwDL8aa0eE1eP.pdf', NULL, NULL, 'uploads/membership_forms/5MAXTpTnGoCkYB0DZlGRp8gVmEXnlRRfUyHvulVd.pdf', 'uploads/declarations/hRNtzgCNcInODypOEilWgHy0ONELu1EsZikW2dHK.pdf', 'uploads/declarations/q5A8KcqJnARwuo1fHteRjXdmhYJHtKClgk9tIygc.pdf', '2025-06-30 08:44:21', '2025-06-30 08:44:21'),
(59, 'Chelsea Moses', '7285285214', 'uploads/aadhaar/25CiIoVnxshHXQkBQ9HjqSo5h4jOtFr16stkN4by.pdf', 12, 18, 3, NULL, 2, 'Omar Foley', 0, 'Fleur Good', 'Non dolores tempore', NULL, 'Deleniti quo molesti', 'uploads/kLAZp4XRGxGBJ1gzavOyfzA4tlBssWgsceSmLKNP.pdf', NULL, NULL, 'uploads/membership_forms/yZevJUWnUFZngvmP6LWEQH3PTSIUXNRImiqy6qXb.pdf', 'uploads/declarations/yp4X0SiYLILbLa80fudOGjEZJKutfsf8jmv7RJcE.pdf', 'uploads/declarations/nPyQ4sZdWso1uRno6syzUpYJr1Oj7d3v83baD188.pdf', '2025-06-30 10:49:05', '2025-06-30 10:49:05'),
(60, 'Josiah Bradshaw', '8778451236', 'uploads/aadhaar/QbQcxAP37Cbpjwx3eNjlArZqVwcc6GbwQMB1NkYb.pdf', 12, 18, 1, NULL, 2, 'Melanie Franco', 0, 'Noble Daniels', '992 Second Lane', NULL, 'Qui et ut et labore', 'uploads/YY0EATXfrSuV3y9B5uSwhdDjZVZDj0ZyJBtu4tj9.pdf', NULL, NULL, 'uploads/membership_forms/IEbON3Kt4ngIo3FA86GCB98aJhuFd7QiRjtJ95JP.pdf', 'uploads/declarations/deurIMdN6XBLySTM2AtNJVyisVlaKs7WD8s6TtG5.pdf', 'uploads/declarations/Eg7THlU3Yp0SED5yHhxFhRuCczbqwl7JWhfz8bRM.pdf', '2025-06-30 10:52:26', '2025-06-30 10:52:26'),
(61, 'Madeline Thompson', '7777845125', 'uploads/aadhaar/DWaZVk1VQ5rJCZtI3dEpePpo9qnqlHmRhu6KFyBH.pdf', 12, 18, 3, NULL, 2, 'Zeus Brock', 0, 'Athena Gallagher', 'Temporibus dolores i', NULL, 'Hic voluptatem cons', 'uploads/limefIZEHQvReOPvxFCzqTJqWFf09AE6w4XUiEHs.pdf', NULL, NULL, 'uploads/membership_forms/6n7W7NlndaqLaPi1BLpWMxglowcLhewgCtmnJWyo.pdf', 'uploads/declarations/402o7Unx4g2zdnxO3aCrgSBJ2tagsZAhX5DISu1T.pdf', 'uploads/declarations/0cSiHAeO2pakxbxfZIHsqDTj5o0cSMs91tZ2ZsnL.pdf', '2025-06-30 10:54:13', '2025-06-30 10:54:13'),
(62, 'Jade Villarreal', '1278451236', 'uploads/aadhaar/fjFSmfznTbijvqX86ZeOIxS2bE4A9F5g61GSEjwQ.pdf', 12, 18, 3, NULL, 2, 'Kamal Nguyen', 0, 'Minerva Soto', 'Consequatur Et ulla', NULL, 'Occaecat dolor aut e', 'uploads/JXv5dSIpSuLnrV32wjFm7alu1EX3jNieX9sFon3x.pdf', NULL, NULL, 'uploads/membership_forms/gKOiQKvrdS1l6NivNrNKvMo22vNOLrh14jRAWCzh.pdf', 'uploads/declarations/EM2qisaokqesibJ5y3c2B3vwQq7bcSLJz4njKbBa.pdf', 'uploads/declarations/UdhHzDCiZGD6vaq6KBFQolv1blWaCwlnv8zGgUAi.pdf', '2025-06-30 10:56:37', '2025-06-30 10:56:37'),
(63, 'James Dillard', '8852528523', 'uploads/aadhaar/guVsn4Kj332BF32KC84Dw3j4tuQVnmB4yrfFhDxj.pdf', 12, 18, 3, NULL, 1, 'Xyla Park', 0, 'Stella Guerrero', 'Et sit nihil culpa', NULL, 'Tempora quis porro s', 'uploads/xbeCmIDhd1dZ4FynTGigwUXqGtCylu9vASUjOHkW.pdf', NULL, NULL, 'uploads/membership_forms/DZcuEoCadlkSlJQDtX9pTKre2Dri4RPRzTeNU0hs.pdf', 'uploads/declarations/eJGHLUrFq2SSEYiECviJjD0vTdlO436RgjROU0rP.pdf', 'uploads/declarations/yFPo6iOEoQrV9NN7ZGDcAiEQNpVmBc5nN8iqjeMl.pdf', '2025-06-30 10:58:06', '2025-06-30 10:58:06'),
(64, 'Aristotle Padilla', '6785214785', 'uploads/aadhaar/ALbLypY7SgUA0AvH4Ius9k5zt9d8DQ0HhhApV84s.pdf', 12, 18, 1, NULL, 1, 'Cathleen Bailey', 0, 'Ezekiel Ayers', 'Ea in consequatur es', NULL, 'Incidunt aut et aut', 'uploads/aikDLWUGtdQOe2mP5ntSOpyKLN7eluTddCUkTlzx.pdf', NULL, NULL, 'uploads/membership_forms/CuwIki1O7zfBrv8BPU6ul8iUiswJID8JZLdfgBs7.pdf', 'uploads/declarations/gIZ7KU7JKhOFQg4mrEvdbre70Nm27PKbixbd8ijE.pdf', 'uploads/declarations/0Cxm0hg9w6VAu1d6q4uR7o4cp4LfjKLBfpXhcYBm.pdf', '2025-06-30 10:58:41', '2025-06-30 10:58:41'),
(65, 'Orlando Holman', '9085236978', 'uploads/aadhaar/THvcadO3hLbFycePqpzv2Z0t2ULtRci0jHoncAmH.pdf', 12, 18, 2, NULL, 2, 'Phyllis Aguirre', 0, 'Leo Orr', 'Qui dolor minim volu', NULL, 'Adipisci rerum nulla', 'uploads/fZXUhL7rbB4TjKhSccOwh2pVy5Q6c4j4A1jcttBf.pdf', NULL, NULL, 'uploads/membership_forms/K9xyfGrmajJDvOMVtTAyRS4W3T1aQdwx7C3PmXXI.pdf', 'uploads/declarations/0CfCg7nKm9jtzHajHSaPgF9hz1rESqZjAd5mLQYK.pdf', 'uploads/declarations/UCKbhGNTGRDqfszk8xebgsy5NBvl416ssM7CEPtm.pdf', '2025-06-30 10:59:17', '2025-06-30 10:59:17'),
(66, 'Tatyana Harper', '8852369874', 'uploads/aadhaar/H1wVGTJfW0rayOvab0mB0mJ8c5YJhZUoKZNaPwKZ.pdf', 13, 19, 3, NULL, 2, 'Dora Harrington', 0, 'Madaline Bruce', 'Sunt minima id praes', NULL, 'Dolor provident aut', 'uploads/L55VZ717G3ALX6GgkiNn6QRBovBE01hWrXyszGas.pdf', NULL, NULL, 'uploads/membership_forms/zxDfFHeU2h9gPw5FPKi9irfh4m2RGEPv3lSAh6cA.pdf', 'uploads/declarations/SRVpjSr0UJWU3KwwEo5MtCKpegKDkbUDKGCp5v2c.pdf', 'uploads/declarations/GSwxhibHYWMjzctyAPXyrGG2V4sJ3UPfi9F53Gxt.pdf', '2025-06-30 12:15:23', '2025-06-30 12:15:23'),
(67, 'Whilemina Wells', '7612345698', 'uploads/aadhaar/DHg3GiT7Y4qZUPSoFHNTZpj6FruhT8fPIuLnElb1.pdf', 13, 19, 3, NULL, 1, 'Flynn Bridges', 0, 'Calvin Rollins', '677 Second Street', NULL, 'Tempor qui at sint u', 'uploads/JdgXC1YMrd9xlpEZYs4OkazNhA7JpzDwxMu6JkeR.pdf', NULL, NULL, 'uploads/membership_forms/tr8h9UTs6hcyucghwj7fFzpOVJaT4ZRJhCMby9hf.pdf', 'uploads/declarations/9HManWLtKTDKeXCVWqfvHjacDzYDjADfYSO5Vh14.pdf', 'uploads/declarations/tL6UgLVVgq2Suyp4KdYXRZpCWHZt7oILJmNIGfEc.pdf', '2025-06-30 12:15:56', '2025-06-30 12:15:56'),
(68, 'Cullen Keller', '5778451239', 'uploads/aadhaar/59o410IgeRlSCyYkH6X42kXjZeHidhTRiwIvv1tB.pdf', 13, 19, 3, NULL, 2, 'Gannon Trujillo', 0, 'Dakota Porter', 'Dolore explicabo Vo', NULL, 'Quis omnis vitae ali', 'uploads/ICYS98A0fxwloFH7HCyQxVQJxwPTXnT9SpPku5Qb.pdf', NULL, NULL, 'uploads/membership_forms/P67QD9qtda9ikZwVCz4TaWozeWdeLchE7BS3h3GP.pdf', 'uploads/declarations/3RPVNB5zkOHFSrP1csq6HNb9qF2UdAxwFgoxiKih.pdf', 'uploads/declarations/vRT5iuiI9DiXLKysmgD1QacG2U0XzCcdxKC49odn.pdf', '2025-06-30 12:17:11', '2025-06-30 12:17:11'),
(69, 'Orla Wells', '8741111111', 'uploads/aadhaar/ZjB3dwVB72YNSanLpXcwWFyUPNx3QqSbfjMXPTHm.pdf', 13, 19, 3, NULL, 1, 'Giacomo Mcmahon', 0, 'Alan Joseph', 'Fuga Exercitation q', NULL, 'Quia et ut eum quis', 'uploads/xbLDMXO4SUX2djhufwRuELNTMnpvhnpsOurzxqbA.pdf', NULL, NULL, 'uploads/membership_forms/AbECWZ3oRkdszfh4KFWr4idU3b3FidfX1xY02dub.pdf', 'uploads/declarations/OjTMqYwyOs5YjjeuuO71y1nl9z56qdoSlwtJE5HE.pdf', 'uploads/declarations/W0fF0O8RW3sWntklNQTfwKFA2CKScaT4ZsV7IrN9.pdf', '2025-06-30 12:18:04', '2025-06-30 12:18:04'),
(70, 'Gavin Blackburn', '4777412587', 'uploads/aadhaar/jttysMoScRmwp6fVcGPwdupZXNL6PqsUNSkami50.pdf', 13, 19, 1, NULL, 2, 'Hilel Holland', 0, 'Porter Stout', 'Blanditiis voluptas', NULL, 'Debitis exercitation', 'uploads/jAKzMtHolxCCTZHKbNArt36VSVMXHgC8yS1hhbk2.pdf', NULL, NULL, 'uploads/membership_forms/utLM5Rh39F0JEFXETtV6teLW8Oi4FJ0e9kntfZ1x.pdf', 'uploads/declarations/8W1dkbZpeU1IAMpQcF5sYf1vd4tcwcTP7FC8au3u.pdf', 'uploads/declarations/GTSiUzfj0v8XgjrWxDeploVbotrj9BCVpPW32Kvg.pdf', '2025-06-30 12:18:43', '2025-06-30 12:18:43'),
(71, 'Camden Rojas', '9612365478', 'uploads/aadhaar/xRYnkp1se8lzttIr4QYoPo2KmbJOmb4oZDIDxg3r.pdf', 13, 19, 3, NULL, 1, 'Andrew Ayers', 0, 'Wynne House', 'Aut voluptas qui sit', NULL, 'Architecto quam maio', 'uploads/2GP7wy4C1KOvMgRFGK6LW4FTigJbdbMx7ScY7RbG.pdf', NULL, NULL, 'uploads/membership_forms/36Rl5dFZcdIh9AkxEFJSFnBTtXCWlTjLDj4q3VXo.pdf', 'uploads/declarations/kkmjqVhGJQCZVKd219SIIlH3G97aNzDCA0jBMblW.pdf', 'uploads/declarations/iIObkxBhx7FE5DyWTFA3TUayGLSTPqoHcnUcYaQs.pdf', '2025-06-30 12:19:26', '2025-06-30 12:19:26'),
(72, 'Whilemina Hays', '4004125874', 'uploads/aadhaar/KkdGuy3dvnLLa63NZXJ4mMAD8x08JVwubGa3NGmK.pdf', 13, 19, 1, NULL, 2, 'Cedric Walters', 0, 'Tanner Herman', 'Quo sed sed magnam d', NULL, 'Corporis minus conse', 'uploads/Hf20dWGz7G31hPQjj4cnBCM00ZnHU7A1Nh2mT8dj.pdf', NULL, NULL, 'uploads/membership_forms/Za0LuZDlg0b8cyTUBYsf5xrVPiQtJAG1zBFVJRj0.pdf', 'uploads/declarations/iQE29zV9xPQlnrWTaPwi9riNP3iqi1Xcj4TAEBXJ.pdf', 'uploads/declarations/Iy9cj8tQoPJGFCpq8SMgsLZrxrTmMG4Cpd5tk7k8.pdf', '2025-06-30 12:20:04', '2025-06-30 12:20:04'),
(73, 'Hedy Morris', '7200368521', 'uploads/aadhaar/0IWmZD5NXXLLTA5Cc5jWP5ykru1KC4nPIqvEWqAb.pdf', 14, 20, 3, NULL, 1, 'Colt Todd', 0, 'Nathan Waters', 'Occaecat voluptas qu', NULL, 'Nostrud vitae vero n', 'uploads/icJ4IPQQrafI7Tyb1wyx0RtGcIPmualPVYyScbaj.pdf', NULL, NULL, 'uploads/membership_forms/3YNo3uBSTO3hzuSopugXII53RUXv3OvoVhOupPNc.pdf', 'uploads/declarations/7dl6S5VwlguGJmr4kEtOW61LBLgwNaPRMSFdPq3q.pdf', 'uploads/declarations/x18N3p7zPW2J7ZUa6joxWi9M662rGsDRrdRRo07p.pdf', '2025-06-30 12:23:19', '2025-06-30 12:23:19'),
(74, 'Jeremy Rice', '2526321458', 'uploads/aadhaar/qCrscN24x17z6FDArUzaBJ3ArKNNt3S1Gz52wY7E.pdf', 14, 20, 2, NULL, 1, 'Callum Acevedo', 0, 'Jesse Church', '805 Hague Street', NULL, 'Voluptatem atque qua', 'uploads/njiM6fMpGdaWGVWYic5vMq68S5gnyhqaLx2s78tx.pdf', NULL, NULL, 'uploads/membership_forms/0UK3cDuv7MPsrVUJxar4icXrj9wr8uimJeWYvJRQ.pdf', 'uploads/declarations/tuNlOjZK3pjYR1Kf61VNW8YOF4qfWtRUrH5cz0U0.pdf', 'uploads/declarations/KMMtepNY8ItZIEpCY9EmtDSj2H6UP5okdHSR2c10.pdf', '2025-06-30 12:23:59', '2025-06-30 12:23:59'),
(75, 'Chava Horne', '4585214563', 'uploads/aadhaar/vZvxqD7hHizaYaVdUUxh452PuvRDmJsAbMwkUEno.pdf', 14, 20, 2, NULL, 1, 'Wayne Cardenas', 0, 'Nell Charles', 'Dolor nisi veniam d', NULL, 'Voluptatem Est et c', 'uploads/OOtAtYJmRlnPW6AvJQ905ZqYkZOU4UpPl35vt6E8.pdf', NULL, NULL, 'uploads/membership_forms/lUY3UZ7BRdeIA7jOMfDy6ekwYFW8wu2730FtPvu1.pdf', 'uploads/declarations/gXvpYv37hfDKF0l4k8CNeNzwxJadQXdpOA3RgFQJ.pdf', 'uploads/declarations/ulg0oMZrL7a8NJTNlShMl8c5aCojt99ffXeuGCtm.pdf', '2025-06-30 12:24:38', '2025-06-30 12:24:38'),
(76, 'Lars Henderson', '6060253125', 'uploads/aadhaar/LOKMgQGsRcY05jz0hU88P2QIR3ugDzc2r1KmuNxH.pdf', 14, 20, 1, NULL, 2, 'Quinn Murray', 0, 'Tobias Jennings', 'Veniam assumenda qu', NULL, 'Quia in reiciendis e', 'uploads/a6fIYBVnLHXeQISr93VnktbP7qo0QBJQAbPZHT4f.pdf', NULL, NULL, 'uploads/membership_forms/Vo1SEC5YmcVyTPrRV6sHAUXOjJt1vNWIVfPYWKhE.pdf', 'uploads/declarations/tlF0cXDi4p7T1xsVvD4jWqj1whhhr0H8Lzgq33yc.pdf', 'uploads/declarations/vZWzZ4gLb63JyYiQmBrMbnqatt0Rnkb9zLkjVnSS.pdf', '2025-06-30 12:25:16', '2025-06-30 12:25:16'),
(77, 'Quentin Bolton', '4652412365', 'uploads/aadhaar/SRad7mKm4aGxi1mL22TiJdOZsGuFlWBioM3UY5mT.pdf', 14, 20, 3, NULL, 1, 'Maisie Wells', 0, 'Venus Caldwell', 'Enim minus dolore qu', NULL, 'Commodo consectetur', 'uploads/YNkZHCLBO3Gk4PHgLUqV5ko6HvLkMyasG0KmUeMw.pdf', NULL, NULL, 'uploads/membership_forms/KE7fVrmp5o1P1ezIjieFNuaol8HrW4GahDGqLi9A.pdf', 'uploads/declarations/AOqm3qzqUjoYjiuUgdcaALtOgHi7ftRgOg06CChU.pdf', 'uploads/declarations/DSW9MmShkneEk0rgRs5F7PFNL0lGpZd49eNz1xNy.pdf', '2025-06-30 12:26:03', '2025-06-30 12:26:03'),
(78, 'Ruby Mcleod', '2612321232', 'uploads/aadhaar/QyP3OCp3ejohw6kpGhsmw7IDpNtTbIWNDFOq6uRC.pdf', 14, 20, 3, NULL, 1, 'Oren Dunlap', 0, 'Malachi Carey', 'Odio expedita itaque', NULL, 'Culpa alias recusan', 'uploads/9Bh4Kb9dj7O3dpr7Q1JaVcySAgPR0JUeizTSyKm4.pdf', NULL, NULL, 'uploads/membership_forms/EQdwnRrMqRllQsR5K4UtEe4piBwnnCW4Pd0GqQn1.pdf', 'uploads/declarations/oWkAXiKifp2uu3FKfsOPf3NTXo2eozzH1kCspL2w.pdf', 'uploads/declarations/jA3wpsmkmi5UEVJcESra4u3y7pWKZbUSxXbFzMSU.pdf', '2025-06-30 12:26:38', '2025-06-30 12:26:38'),
(79, 'Amber Vazquez', '3885120321', 'uploads/aadhaar/YPyIFCfuqQvJimQp1CTkJ5HgekSCrTrZICUBypqo.pdf', 14, 20, 3, NULL, 1, 'Angelica Decker', 0, 'Hanae Macdonald', 'Veniam libero delen', NULL, 'Proident adipisci m', 'uploads/eDXSt8Tr6bHLSwiabyDhS8p6gcGEsglrJrfgdQp1.pdf', NULL, NULL, 'uploads/membership_forms/wBn2DC0HhAh2YVeoLF6J2wu9b96m029F4EHLlMUz.pdf', 'uploads/declarations/xmViTpfcpngBQGYXeQJqve8cREcz46VyAzsA9EsX.pdf', 'uploads/declarations/wQnigkfQWHCy2RmqmEP5MuhHqzi3TeaLUzelAsgK.pdf', '2025-06-30 12:27:20', '2025-06-30 12:27:20'),
(80, 'George Booker', '7845210365', 'uploads/aadhaar/dcl2bP0HxjQjlhPaxtsId6awswnQ370ROD4zOTUT.pdf', 15, 21, 1, NULL, 1, 'Rhona Riley', 0, 'Maryam Moore', 'Illo quia dolore hic', NULL, 'Reiciendis dolore es', 'uploads/yR13oexN2bNtK7imB3RRtqRqBoTkKaHjGDwKCebo.pdf', NULL, NULL, 'uploads/membership_forms/mb7BH56wwIkCIBUf6xVMF5jyWL4zy3ifNbExD86t.pdf', 'uploads/declarations/BvyHqyZKsQWy69u79NPMExWtOX8VceBUsaAOAFuN.pdf', 'uploads/declarations/3gDhY8EY22IxoKrc5HrChsT48TruxgHlOX0Xm5lT.pdf', '2025-07-01 06:16:29', '2025-07-01 06:16:29'),
(81, 'Rajah Bradford', '3322115544', 'uploads/aadhaar/rg0xKUhPGVgFhDcGc4TpiEsmnbCtQXW6WMA9SXkk.pdf', 15, 21, 1, NULL, 2, 'Shelby Houston', 0, 'Darius Rosales', '860 First Drive', NULL, 'Ad eos explicabo I', 'uploads/o5cPoKzkD7M2bkEDlcW6paX7fqIyLnZqcsjhw8Ds.pdf', NULL, NULL, 'uploads/membership_forms/nwhTcSbC53c0hWUwkW8ZjwLVFAtpGAhlb9dxaxY1.pdf', 'uploads/declarations/Hfg52WFfGpGUTQLV3Jz0QGRCHDT1GFwj54ERpPor.pdf', 'uploads/declarations/ZqMApUZ89YnWtK1V6uuaHYxXWGCpxIP61mJf8CRm.pdf', '2025-07-01 06:17:02', '2025-07-01 06:17:02'),
(82, 'Jaden Kirkland', '5111258742', 'uploads/aadhaar/PJLLUOPzH73dZ8ySu28W3OOkJPaFCm01QVw1eOIZ.pdf', 15, 21, 2, NULL, 2, 'Uma Hanson', 0, 'Ian Stokes', 'Eius laboris aut et', NULL, 'Id non ullam ex ipsu', 'uploads/8RJmOH77jQQpezdIrbOq1f7w6szQxPzcFKQLJX1T.pdf', NULL, NULL, 'uploads/membership_forms/er1f38NqtHPnG4bs1re9tSxXt1yv2LU8JvZYRWQj.pdf', 'uploads/declarations/9eJwW4lFVNPtW5SDbKdZTIgMNpd2If6TJtV6vqet.pdf', 'uploads/declarations/5YgdvQOk21iDSTFHoplUyueqyyDmm60CdelQO6Pu.pdf', '2025-07-01 06:17:37', '2025-07-01 06:17:37'),
(83, 'Maya Moore', '1452123698', 'uploads/aadhaar/95UN8Wp0D5MkcGfOVUp4LHRfoct12NYbbHUt3hcB.pdf', 15, 21, 3, NULL, 1, 'Herrod Velez', 0, 'Burton Harrington', 'Ut ut officia omnis', NULL, 'Et officia alias omn', 'uploads/ArnD3Z1MpdKlTTlwBB7179BuNOnrwnXscFOVrKto.pdf', NULL, NULL, 'uploads/membership_forms/sobaJNVSymFlbgJ5sJE6nviDWsRSV7O2swBD3YKX.pdf', 'uploads/declarations/T09O4WmCnXgo7V9BwSu71gEvo3nULx83ztTFxRGi.pdf', 'uploads/declarations/jWMub8k7YNrEFTX11E6WqaojFUFoLnjzrzpCEfRe.pdf', '2025-07-01 06:19:15', '2025-07-01 06:19:15'),
(84, 'Karen Sullivan', '2774136952', 'uploads/aadhaar/xoR6q90iMr7LmgoIR5M9lr3wBISHA5HsdG8b1Z88.pdf', 15, 21, 3, NULL, 1, 'Trevor Estes', 0, 'Raven Cruz', 'Dolore dolor similiq', NULL, 'Officiis velit eum s', 'uploads/jXP6kLxEFIs5544Jx0qY2BnIiMY66ButjNhe5Dwn.pdf', NULL, NULL, 'uploads/membership_forms/i0JBI7KE84Tox1CnYcBpQM2e4MLfRRiiASiLqiHg.pdf', 'uploads/declarations/WrF3SzmHdw6O1qmtqVnVm04MPANkHHBbna6MLGFv.pdf', 'uploads/declarations/Eu5Jiq8Yri6BlNg6Zc0xpgEs2wZVDLSdNMfAN0Js.pdf', '2025-07-01 06:19:53', '2025-07-01 06:19:53'),
(85, 'Deacon Emerson', '6885214723', 'uploads/aadhaar/eBxx1GrpJkV6V5XgWUnURcH0S35F1Yz7THdwWQek.pdf', 15, 21, 2, NULL, 1, 'Hakeem Vang', 0, 'Kyra Wong', 'Nisi molestiae illo', NULL, 'Consequatur quia adi', 'uploads/a3fp9QoeRS9A1ajAM5WBHIOdAAhp4VN5mv1tm16O.pdf', NULL, NULL, 'uploads/membership_forms/IcQLtofF4MiluIzmvvPEDSGocoo948LoLBm4ALMH.pdf', 'uploads/declarations/oGAa8zeH2Vni4gsCw6IGcKpm3DwhPcI6XNwtEeoD.pdf', 'uploads/declarations/oghcH9VxMKQXiRxTumeNRPikCcyxBIqoTpdJQd5S.pdf', '2025-07-01 06:20:31', '2025-07-01 06:20:31'),
(86, 'Vivien Petty', '8720316987', 'uploads/aadhaar/m5FJXIWgsHdnjQCrc4cmXDDw7mcULom01UtRDLPP.pdf', 15, 21, 2, NULL, 1, 'Shelby Peters', 0, 'Rina Jones', 'Omnis deleniti offic', NULL, 'Unde aut et eiusmod', 'uploads/4JQvQhoGE2LRVF7lJnyHGy0ty3J4dmmvpDTawfxc.pdf', NULL, NULL, 'uploads/membership_forms/Dis0hBxqJwpvgDZwD1feOMk5C8EJ5gO7YZm0lIQv.pdf', 'uploads/declarations/rXo5PJFxgZyDJM5NeoRllwKTymGAJCxFwsaqynJ2.pdf', 'uploads/declarations/lX4iLm7Ir6f9zSuW82FU8oAFx5lqjvDa4oXKd3oa.pdf', '2025-07-01 06:21:07', '2025-07-01 06:21:07'),
(87, 'Yardley Williamson', '1515251436', 'uploads/aadhaar/kj0of8S7axLle5AxryyjKU4edkE6xEacRFGzWOhs.pdf', 16, 22, 2, NULL, 2, 'Ann Weiss', 0, 'Tatum Albert', 'Expedita aute volupt', NULL, 'Officiis cupidatat N', 'uploads/6m4EUFFURSdx5GLxmypkAA3taPseJiDSpH1FzyfK.pdf', NULL, NULL, 'uploads/membership_forms/EVwC3noA5QHeecaRimLnM5nvpBO31gNWibuTKbG3.pdf', 'uploads/declarations/777smN4qZ1vxvx56zGldpQQJ3waMkcbo3SWhBdvp.pdf', 'uploads/declarations/zWjngf8C5A6yL9OUIcRcdJA0o9hhhbpix0EQBOaE.pdf', '2025-07-01 08:48:07', '2025-07-01 08:48:07'),
(88, 'Adrienne Best', '6363521236', 'uploads/aadhaar/8ojc1h8A4NeMLpLycrk4DpV62Ufsa5nXQE5RDtCg.pdf', 16, 22, 1, NULL, 2, 'Lane Petty', 0, 'Raya Pope', '60 Oak Freeway', NULL, 'Reprehenderit digni', 'uploads/wDbkhtn13W6AArjKNtUa39KcLi1y5y2Tyh5tTEeC.pdf', NULL, NULL, 'uploads/membership_forms/rXgzCt4rCI9AAR9t1OarSr5oyxVc4EAMulEajNf7.pdf', 'uploads/declarations/Al78oHCJhZj3PutJzZ5dW2TMHqOi2Sp42SaiNMaN.pdf', 'uploads/declarations/puay5jC99AaJRFHXeV9wOeEL6G39t4I2F6eAiOXI.pdf', '2025-07-01 08:48:37', '2025-07-01 08:48:37'),
(89, 'Ina Juarez', '1541236985', 'uploads/aadhaar/QFF6FGyurKZbg9oFVaHFLxWDocEoYazmoYa9nNtG.pdf', 16, 22, 2, NULL, 2, 'Rowan Carlson', 0, 'Leandra Mcintosh', 'Rem Nam obcaecati er', NULL, 'Qui a sunt earum dol', 'uploads/C3VZpeLjOCN4Re4fCfxOc2lkBEQTwvfhFrXZXJeT.pdf', NULL, NULL, 'uploads/membership_forms/rx42EvkOvJQC7jQD1hKYOo9AzVWQDh1trn3nCN2Q.pdf', 'uploads/declarations/MOW4gKq17g9deysJngpGmsPGg22cyp4c8RN2mzN2.pdf', 'uploads/declarations/H5OcMvtPI2ODv5GwShdGvp6bHPL2DSO1BdwCebi9.pdf', '2025-07-01 08:49:12', '2025-07-01 08:49:12'),
(90, 'Charlotte Butler', '5252124852', 'uploads/aadhaar/sIfwrvry5Gpxey2UJGnHnWvjgNxbge3oDzLDiK2s.pdf', 16, 22, 3, NULL, 2, 'Quintessa Talley', 0, 'Maisie Moon', 'Est architecto culp', NULL, 'Mollit eos sint qu', 'uploads/AZbOJXlbiWJ1nTWI5l8li1Kd7UiP1aD9zf7DJHs0.pdf', NULL, NULL, 'uploads/membership_forms/U18BL2bRtLrsJlc1m58NOisAWZZw6e9MzNQ6T0RB.pdf', 'uploads/declarations/abt6JD2tWS2aEZANbnxyJeCw5gLk3ApEYkFZOGXy.pdf', 'uploads/declarations/cDMqGPJ7kTsaqcbT0VeHtowqYJ7IrCcwRfAjqBQZ.pdf', '2025-07-01 08:49:45', '2025-07-01 08:49:45'),
(91, 'Belle Phillips', '4222033154', 'uploads/aadhaar/Rh7WmFzA2BOHaoXohrfTkHx95SAEy0TJAlJmAG9j.pdf', 16, 22, 2, NULL, 1, 'Reagan Roth', 0, 'Ross Deleon', 'Esse quod in volupta', NULL, 'Rerum rerum animi p', 'uploads/FBs3T8sJgnUmAgGCT9fQyr1xVEHDyHDEMEeClsxM.pdf', NULL, NULL, 'uploads/membership_forms/Ij1o7pCrPt5RH9v27iObzcT53UTkPd9EtCwnFBEY.pdf', 'uploads/declarations/hFc0FLr7RTJZdUXwL54saW2JsrKISrDeu6Z498zt.pdf', 'uploads/declarations/26YMipM1RUQQZ64GcaUd5t8VVsagCU5zXdW0DHk8.pdf', '2025-07-01 08:50:24', '2025-07-01 08:50:24'),
(92, 'Sophia Sweet', '4010405214', 'uploads/aadhaar/bkQ64Vyt3DBfvWyksR87Q4MPRMOqF5YrRYnn87WS.pdf', 16, 22, 3, NULL, 2, 'Kamal Mitchell', 0, 'Nell Goodman', 'Non quam iure accusa', NULL, 'In velit quasi recu', 'uploads/Jtrpo0D5SPkY3bWjPMwgQj0bAyl8YGYaVAilcN0R.pdf', NULL, NULL, 'uploads/membership_forms/f5URu16icOGwoVrfgsjwOUSvkGlbIdLeFWTBupB0.pdf', 'uploads/declarations/mQZtZ7JAEHWFLZPo8ODkCBdVq6Cc9zp9BLkouzvd.pdf', 'uploads/declarations/2tTt4r4HWYZPyaf1DiNup7Dxq8qK6u6nAk3sJmcH.pdf', '2025-07-01 08:50:56', '2025-07-01 08:50:56'),
(93, 'Astra Decker', '1010521036', 'uploads/aadhaar/i4BLz1hRvhgox4xtXIGFRlzJC12HwxykB909O6A7.pdf', 16, 22, 3, NULL, 1, 'Donovan Cooper', 0, 'Alana Rice', 'Minus minus ut iste', NULL, 'Veniam a in ad sit', 'uploads/SjhBuLpcm90t3cXRdLbvJbwGG0uHFTothHEb0TSM.pdf', NULL, NULL, 'uploads/membership_forms/RuFCIHqiQzeNrMydY3BtSl4aAvAVdMlYB3e4zrsP.pdf', 'uploads/declarations/9n7ZLDeRuthzA0voForj1kXG2ZbUsXh9tFbdQ9VT.pdf', 'uploads/declarations/EPJyh1o8c6tLI86SOoSUVXh7ntwHqcp2sF5B5tU7.pdf', '2025-07-01 08:51:34', '2025-07-01 08:51:34');
INSERT INTO `members` (`id`, `name`, `contact_no`, `aadhar_no`, `society_id`, `member_declaration_id`, `gender`, `category`, `is_married`, `father_spouse_name`, `is_buisness`, `buisness_name`, `address`, `business`, `designation`, `signature`, `start_date`, `end_date`, `membership_form`, `declaration1`, `declaration2`, `created_at`, `updated_at`) VALUES
(94, 'Gannon Britt', '6002410052', 'uploads/aadhaar/f52NX2RLHKhTtM45PInVOLGfj9oXq2sUfFNvNOQd.pdf', 17, 23, 1, NULL, 1, 'Abraham Stuart', 0, 'Dorian Vance', 'Corporis velit commo', NULL, 'Maiores id laborum a', 'uploads/MhntcUve3cCpDxqRQL5E2aGFzHD6zK7O1qGbfbRW.pdf', NULL, NULL, 'uploads/membership_forms/hw9W0qxGqc98x8W5a1Y0uqsEXlP8hIIaQ33kML4n.pdf', 'uploads/declarations/ezaFfNiU9VRkhpzcqePFFvXyPKzptEJ9BdQl9zHO.pdf', 'uploads/declarations/Lme9cEb2VyyDbQc0eSMDlXxMiowEwBZZ7NW7hIQr.pdf', '2025-07-01 09:58:32', '2025-07-01 09:58:32'),
(95, 'Thor Shaffer', '9874152036', 'uploads/aadhaar/ZijBlwlpsVrn7gmx52fsyliAM3E4KlDwpVXf4Obv.pdf', 17, 23, 2, NULL, 1, 'Mary Fitzgerald', 0, 'Malik Roman', '170 South White Clarendon Extension', NULL, 'Eos fugiat est ea', 'uploads/9an3aow53Y6GDTdTWNXMPT21t6ff435dBGpJ5Pn5.pdf', NULL, NULL, 'uploads/membership_forms/RVKMeLLIUHN9ggjys2RGBD2NdwFEOKlUf0ublIIP.pdf', 'uploads/declarations/MPsPoOJqZTWvht1oMbbi5HQzs6BRTKcmFROGNSfk.pdf', 'uploads/declarations/qIRsOmdHo3CWHeiOxUNcsYxentKD2vpum49wfVFk.pdf', '2025-07-01 09:59:21', '2025-07-01 09:59:21'),
(96, 'Hayes Richmond', '3141526321', 'uploads/aadhaar/Ix5F3h5LLKSXUENjunWSlb0ZLmcgvkcmEMBdmkvT.pdf', 17, 23, 1, NULL, 2, 'Jasmine Jimenez', 0, 'Serena Hawkins', 'Tenetur et reprehend', NULL, 'Adipisci voluptate v', 'uploads/2t3PhLxvbWHogsBoeRlvK99fJmgRknpTlMGZcmzJ.pdf', NULL, NULL, 'uploads/membership_forms/5QajcGKi4JDB90Cu2jKxpLCL5s1kDV3ChLWXglmu.pdf', 'uploads/declarations/NKEl0TnHqElhTNcMMN0hVL7TpbWVuXRSWMAJAr4P.pdf', 'uploads/declarations/NiMYqD9pml7IjxsPjUsqzLYgsp7lzYTPuoKncj94.pdf', '2025-07-01 09:59:52', '2025-07-01 09:59:52'),
(97, 'Tarik Hubbard', '2424242424', 'uploads/aadhaar/jVuwmRfUS1yfPENWxx9hTGsvHRbYa498qrxhT5zV.pdf', 17, 23, 2, NULL, 2, 'Grady Williamson', 0, 'Bethany Hansen', 'Ab ea voluptatibus p', NULL, 'Enim distinctio Id', 'uploads/yqFFZXNkrc7XCWXjlgtdIh12FxRlxBtZUJEK3Cq1.pdf', NULL, NULL, 'uploads/membership_forms/MOm2sS0mvHabXu6qUTzcSyQObUVQrEvthv9AUbTg.pdf', 'uploads/declarations/6SrjDdh35SW4AGsGMsTiT5PX9HrtPgDxGVfPqT6Y.pdf', 'uploads/declarations/TPnQI09isNYMReBaPkCu0b6R6BZT4rLt2YmMtnq7.pdf', '2025-07-01 10:00:22', '2025-07-01 10:00:22'),
(98, 'Catherine Byers', '3782145214', 'uploads/aadhaar/UK23mXR2K3W5sprurDFWAlX1DT8cNQ5KniFRKD0j.pdf', 17, 23, 2, NULL, 2, 'Cameron Young', 0, 'Rhonda Marquez', 'Eos aut nihil qui i', NULL, 'Nulla facilis ut exc', 'uploads/xF4chaWAC1aVLMTBstqN6uYYqJVmY3XSbHr1VkdC.pdf', NULL, NULL, 'uploads/membership_forms/mxCDCPFjBCe4YLtNa6jU6CL5s2GE7DolcbNYE0Lx.pdf', 'uploads/declarations/1screPF5zNvOzN7IsA8hbgJsQ55U8uVwmfypkc8v.pdf', 'uploads/declarations/o6pMKj0yxuVxkUJ2udEdul93mWHLUUIVBDFLjfzL.pdf', '2025-07-01 10:00:55', '2025-07-01 10:00:55'),
(99, 'Meghan Levy', '3112021478', 'uploads/aadhaar/UHRqEw0hkw1g77lstHTmcipgnz7iAwb2zIKHpEMk.pdf', 17, 23, 3, NULL, 1, 'Winifred Sellers', 0, 'Maite Gould', 'Inventore et id quo', NULL, 'Qui commodo iste rei', 'uploads/kqANHwIhVXAvJ0i9H3sQhHlBd7ReuIL5BK6bffkx.pdf', NULL, NULL, 'uploads/membership_forms/cFOQTT8rXa28nGWdxNTUuiMHtpIw0NFCK8rVOUJ2.pdf', 'uploads/declarations/a43LNaWlGzynxM9K885zyIy6BpU3KACPbiQ4HmbL.pdf', 'uploads/declarations/Qb43JdJO5xTM2GDMAby6ipgUQ60VhRkdRPwJKTup.pdf', '2025-07-01 10:01:27', '2025-07-01 10:01:27'),
(100, 'Brent Hodge', '4112032147', 'uploads/aadhaar/J8ckiImq1HTA1m7RMtTm8C3GG1WS1AHQKmxM07mw.pdf', 17, 23, 2, NULL, 1, 'Simon Vega', 0, 'Timon Petty', 'At enim in ut labore', NULL, 'Exercitationem et di', 'uploads/mkRVAf7o5ChLA6O2b9v571FG46GBCu9T6bnc0GTT.pdf', NULL, NULL, 'uploads/membership_forms/qJMEMilxwMV8n2BDnv5MwxuuPUCRbtmewThzLhlY.pdf', 'uploads/declarations/AWfAG1Xz1ZqihnvMwLIqV79MPwti36PtcDkwhgR1.pdf', 'uploads/declarations/jab8QXGRTTcR9gOsJa1iQadWFkMATMoU1rP11Wbu.pdf', '2025-07-01 10:02:03', '2025-07-01 10:02:03'),
(101, 'Emily Weeks', '9999999900', 'uploads/aadhaar/lps75ggNz48rpExRdrFRE7YuY2OaFhbBQMTIluMj.pdf', 18, 24, 1, NULL, 1, 'Florence Barnes', 0, 'Ezekiel Guthrie', 'Omnis sapiente quasi', NULL, 'Et excepturi totam e', 'uploads/gwpy0LOUxcBYy8k70keAArbYIQcXJMQf6pnb2WqH.png', NULL, NULL, 'uploads/membership_forms/sRvxYCHnYD4gTek8gZr7sf9tbjDDq1pqwLlSbJGB.pdf', 'uploads/declarations/u12P75c9bp303YXZL19T0BdtY5SJj9gwv9cK4YsV.pdf', 'uploads/declarations/UBb5ehAV6FDyF7ZvMmlqPvrwRUrGXuIewKO2rlL4.pdf', '2025-07-01 10:27:28', '2025-07-01 10:27:28'),
(102, 'Kaseem Villarreal', '5656789009', 'uploads/aadhaar/LItVlX9XrrvxGqsGvGdbhR6TENJ3hnAixkPmCRJB.pdf', 18, 24, 1, NULL, 1, 'Patience Walls', 0, 'Merrill Delacruz', '13 West New Court', NULL, 'Recusandae Voluptat', 'uploads/p9U4JIS9HpqD5RtcKAbhIVATI1WXwAy2AJBNPrOt.pdf', NULL, NULL, 'uploads/membership_forms/sbbcYXk3rWYLmt3LBwYkLqtmfLuJhbMbQcgyHzdu.pdf', 'uploads/declarations/rR4tMieufeeaoQzt9OdWx7Dt2gEbRnk91VqMuDEw.pdf', 'uploads/declarations/gQRY7NiCAjLFaVbzxBeYIcoq7mQXFAHC6oY07Exh.pdf', '2025-07-01 10:28:21', '2025-07-01 10:28:21'),
(103, 'Indigo Cross', '8787888787', 'uploads/aadhaar/SyMbpEd76GaeQpGCtjDq36KDg9LWX1RNUZ5OhiTD.pdf', 18, 24, 2, NULL, 2, 'Chaim Weber', 0, 'Kim Flores', 'Quis voluptas nemo v', NULL, 'Excepteur aut earum', 'uploads/2oTq46o5s2E515NWX0XTQ7XCIHYenwG14iKnfBaD.pdf', NULL, NULL, 'uploads/membership_forms/qSz1srzS6PYman6K4tDCLwEkvQMfxSGHDVUaRyN0.pdf', 'uploads/declarations/e4XI8L14255fkj9KyPzp7YAT7zYR5N5yFHzbljui.pdf', 'uploads/declarations/ZtpBN5bUtG2bb4Xlumw5Xb6G9ynGKQHoXZpha9zU.pdf', '2025-07-01 10:29:06', '2025-07-01 10:29:06'),
(104, 'Simon Barr', '6767656545', 'uploads/aadhaar/DHCDErlnCY5xJWlnL7CoSbkzL9aNajl8kD8h7Dw0.pdf', 18, 24, 1, NULL, 1, 'Cara Cash', 0, 'Cheryl Waller', 'Cum sit ut cillum m', NULL, 'Proident nostrud it', 'uploads/46bzLDwTTXtrF1fArRp4z32YVwEUCHyCITGXQjvm.pdf', NULL, NULL, 'uploads/membership_forms/oMmLBfWHvNAIxKJMm229fXvYb5TnXDZEMSgHrP1I.pdf', 'uploads/declarations/rgDsAv4s6J6ILqI44FhtwUMbICnssZqPfYPudlCJ.pdf', 'uploads/declarations/KXn4cjGqIFZVnTCTn9XnemJQhqnZlLh9qgtJYVeq.pdf', '2025-07-01 10:29:50', '2025-07-01 10:29:50'),
(105, 'Lev Brewer', '7678765434', 'uploads/aadhaar/0tNIiqaSvuqKhci8vfH7CQPuIOa35rcjGKl7AV9a.pdf', 18, 24, 3, NULL, 2, 'Phyllis Miller', 0, 'Quentin Melton', 'Velit laboriosam e', NULL, 'Quo blanditiis sed i', 'uploads/FYnDvNEYORA8Fc7qaFmaO9WEscKIR4qdGqrVQbbj.pdf', NULL, NULL, 'uploads/membership_forms/6FLcqpJXpJfO321KxJDAwPHgkxVZvxpTlYibf59i.pdf', 'uploads/declarations/gWmBgSzIdYEz8oam4twqNCXaS9NeTD5uKr57cqDj.pdf', 'uploads/declarations/R6WRoy0EAHR8qPsWcu8uTi4eYyoxGmYgTIwWRHCV.pdf', '2025-07-01 10:30:37', '2025-07-01 10:30:37'),
(106, 'Callie Rivers', '7876567898', 'uploads/aadhaar/7hIiU67Kbohh1yFcVUYw6ZVb8cQPUHSGxbv0Mg4H.pdf', 18, 24, 1, NULL, 2, 'Flavia Valdez', 0, 'Ruby Small', 'Perferendis quia iru', NULL, 'Nisi dolore architec', 'uploads/mcahGbq2dudJqtd1H87VkMGlrdwenUhrvxoBX6xt.pdf', NULL, NULL, 'uploads/membership_forms/HzVW8enuZkxcieny7wBdgHwn5iuM9hOLJJL3Hos7.pdf', 'uploads/declarations/ibpG9HeMOaGE1EpNcIULLgL9dktCar1LvDIQoee2.pdf', 'uploads/declarations/KromuwasLiUZ8vPElHhEjOUB9VYxD9Q5BmLc9LpX.pdf', '2025-07-01 10:31:21', '2025-07-01 10:31:21'),
(107, 'Dacey Mosley', '7876778767', 'uploads/aadhaar/QsvycLk3sFW0dWcfSKmiW1gQwLtsQHImsYPMijhF.pdf', 18, 24, 1, NULL, 1, 'Kellie Wood', 0, 'Giacomo Merrill', 'Similique dolor ad n', NULL, 'Laudantium ad id vo', 'uploads/36HhNtlyf3pcM9PQ640Ij1sjxldJX6s0Kz3G5tV6.pdf', NULL, NULL, 'uploads/membership_forms/qYId62axk0fHAcO6BJXl2cQaiKu9MWSaXmpUrmdS.pdf', 'uploads/declarations/8NagGVLrzttagnWwGEbNiYxK0lVzbzdWt2KMfzkv.pdf', 'uploads/declarations/OEpSL1UjYITWwKLBDyWXaaNzGntBqXvaOxdZDnLk.pdf', '2025-07-01 10:32:08', '2025-07-01 10:32:08'),
(108, 'Wallace Harrell', '1111111111', 'uploads/aadhaar/sUDb7Zyp6ktMXR99fA2sc0yNuYCiulhnohafgAN9.pdf', 19, 25, 1, NULL, 2, 'Clarke Cline', 0, 'Cain Kane', 'Dignissimos dolorem', NULL, 'Qui dolor dolorum et', 'uploads/212RBJhtMBBDNqD1swbwhfTa5SAJvSgLsHqyXL3g.pdf', NULL, NULL, 'uploads/membership_forms/JwkgZeMvGxthZ4BismwJhAvBwxYZVI96dpERCSwW.pdf', 'uploads/declarations/cHbNLwK9tvoy0AG5CvFYov23RsHd2n3XPWfYMBDB.pdf', 'uploads/declarations/g1dY9llxqtgMjcmwfGgumt0QyNOIBbxXvmFfuk7q.pdf', '2025-07-01 13:02:15', '2025-07-01 13:02:15'),
(109, 'Keelie Collier', '6777898767', 'uploads/aadhaar/meLILt9gwcZ5xV8tV8kXRTnDlJB9r5zNUOtud1Gp.pdf', 19, 25, 2, NULL, 2, 'Sacha Mcdowell', 0, 'Theodore Valenzuela', '47 Green Milton Road', NULL, 'Ut nulla deleniti ve', 'uploads/qnsXqLvWzhzQt4q1Q73EFuSUDagLA2l63c2dmbXR.pdf', NULL, NULL, 'uploads/membership_forms/sZ60QejBbd5TLYgSoDgLtEPPtitKzUBVqhpQ4J9Q.pdf', 'uploads/declarations/Rq2nySjqfBmBes5sroqoJzoRLLyEFaCVYQTGAwQG.pdf', 'uploads/declarations/2atpl6pda3IE9UyKJN2UDMQxMQapJ1wkKLRlNk8F.pdf', '2025-07-01 13:03:28', '2025-07-01 13:03:28'),
(110, 'Quynn Long', '7876545677', 'uploads/aadhaar/gM7pKbNcEyMX6tP3QbZ9UHanZVzVvy9RMquaNjg9.pdf', 19, 25, 1, NULL, 1, 'Doris Aguirre', 0, 'Nayda Nash', 'Voluptate quaerat di', NULL, 'Qui ab minima aute v', 'uploads/slllFOS1Fg3qKgbkQdRR0MgDWpoFRlu1oakh3vbC.pdf', NULL, NULL, 'uploads/membership_forms/dHQE3rLRCVNdgUVGMQB1fBBCyqKldpd7SxwZkq0O.pdf', 'uploads/declarations/idy4OypwljmtOpptyforzQ2Ecx715raILfoOJZaf.pdf', 'uploads/declarations/Y4L0TI1wFK3HPNGUAYKk6i770iKShl83tm6YvUfa.pdf', '2025-07-01 13:04:15', '2025-07-01 13:04:15'),
(111, 'Raphael Parks', '5878743234', 'uploads/aadhaar/NKjEJepLGCGdNdxNQZqcT7ctrrORNua9SXP8drnm.pdf', 19, 25, 3, NULL, 2, 'Peter Wise', 0, 'Lareina Warren', 'Perferendis et totam', NULL, 'Iste voluptatem sed', 'uploads/qHMaM9Aya5PBM9COxtbiESuuohdUVcNRZ8I5gahN.pdf', NULL, NULL, 'uploads/membership_forms/iMMbby60b93NgiRnoJRd7qpasmWB14bYUmtnrbyf.pdf', 'uploads/declarations/kv0Y8ILp56qCjC0DLwcpUj8EDe7GjTyZ9eZBKmmS.pdf', 'uploads/declarations/Ilep8K0uQmKXf4UZwn4STXN2n8zh85mFyqto6EFQ.pdf', '2025-07-01 13:04:54', '2025-07-01 13:04:54'),
(112, 'Akeem Woodard', '8209098987', 'uploads/aadhaar/1L7XgrD6bYWZgcHFQJQfMn9h2JVBlPMavurwXFx7.pdf', 19, 25, 2, NULL, 1, 'Inez Conner', 0, 'Clayton Alexander', 'Voluptas dicta repre', NULL, 'Alias consequatur re', 'uploads/YYhrQBQgOsTMb1PFezfFT93jNgCgeVzae4Ye3i5j.pdf', NULL, NULL, 'uploads/membership_forms/q4cyZEesF7c8NhjmaXlwSVY7NRnciOJOB3gyGKBE.pdf', 'uploads/declarations/EVG6MhklfbS0mSi4NK2RBySpaXTFvKZlhg9EOYia.pdf', 'uploads/declarations/kZuKVLJYktealEfeY68tB86q9rINkUQ0YeuhKZPt.pdf', '2025-07-01 13:05:39', '2025-07-01 13:05:39'),
(113, 'Lila Santana', '5587678767', 'uploads/aadhaar/r6yROxFa4fbJoKrbvbGodyfnjAjhTg0LV0OCcPAU.pdf', 19, 25, 1, NULL, 1, 'Fallon Conrad', 0, 'Damon Bentley', 'Ex neque iste autem', NULL, 'Perferendis dolores', 'uploads/mMOkbNYfwdnUaYF484Exn3Hc5XDgI61TvmkJZ2qx.pdf', NULL, NULL, 'uploads/membership_forms/FsBglJm3TgxoXAcexbw4Xcul4LQnkcrTaV3APat7.pdf', 'uploads/declarations/xZMBW1cs49vjBf1K0e5da3iyVNmOlVk3ukgmsxhp.pdf', 'uploads/declarations/dFa8Ud4yzdZF2eKcJ7EsKTQBt9ibICt3QMGbo63R.pdf', '2025-07-01 13:06:19', '2025-07-01 13:06:19'),
(114, 'Sawyer Lloyd', '8578765434', 'uploads/aadhaar/69LQEOdyZpzlVJje50jOyJigSNHU1XDu2bx9cnYt.pdf', 19, 25, 1, NULL, 1, 'Hayley Simpson', 0, 'Acton Mcclain', 'Natus nostrum placea', NULL, 'Officia ex aliquam s', 'uploads/8LrHoeXRiEjC0cZwCzeQ0Ljn3KHpSU29kd3MaGEA.pdf', NULL, NULL, 'uploads/membership_forms/qTM093HnmNPyR7JCu6MYCUXAq0QyRw3aN7skHmFg.pdf', 'uploads/declarations/gYwZhrjyI74xNd2vDjYfgBc2fgYv48zVHh7krb00.pdf', 'uploads/declarations/e6xBbTVX3RsG6L70FxYBBvE1iutAEKfHY9vumiNN.pdf', '2025-07-01 13:06:58', '2025-07-01 13:06:58'),
(115, 'Rose Raymond', '3510203041', 'uploads/aadhaar/YvZ7YWJkHwEIRB1odCcCfpsPMKkfzGOuEsk2yFml.pdf', 22, 26, 2, NULL, 1, 'Roary Kelley', 0, 'Lillith Haney', 'Autem ullamco ut eli', NULL, 'Ullamco voluptas mag', 'uploads/O3U39ePg8a6LFtIYXkou7dt44KpW5cs4x4kQTHxx.pdf', NULL, NULL, 'uploads/membership_forms/BKSeo3rjan3k5WM0DqOTbughCRJi3UwXDxRFqfVo.pdf', 'uploads/declarations/qoJFCwl3qlmcrCpf5hyS57V73goUtqt798TDnqlj.pdf', 'uploads/declarations/0NBafyrvP5Ca5OjFEduMin5aib6RuZjQ7DMN4FdM.pdf', '2025-07-01 18:26:49', '2025-07-01 18:26:49'),
(116, 'Barrett Dunlap', '2230123012', 'uploads/aadhaar/8sfa4xOXR2GTl6wct4d4sqUCvQhCviGV5yVmCcao.pdf', 22, 26, 2, NULL, 1, 'Zane Mullins', 0, 'Knox Hall', '997 East Rocky New Lane', NULL, 'Vice Chairman', 'uploads/IOSxfTFtvGwJfc6eQjPnSAr2DnsHNlxZr4K3BOfA.pdf', NULL, NULL, 'uploads/membership_forms/CmKDR1BBmsxqAZbn9GAsKNAx1aF8EHMnlNmewmHS.pdf', 'uploads/declarations/BYSRiZgbHAGlAGRKu2Z1j3jpy1XlBDYJxL9FKzzb.pdf', 'uploads/declarations/OKfKaUKiUFGILCkFjePoxoqxyeqqz4d5OcSktqrr.pdf', '2025-07-01 19:59:10', '2025-07-01 19:59:10'),
(117, 'Yetta Nichols', '8177123697', 'uploads/aadhaar/ZuH94o4mgxvbpMBBne80nEjXPehoYLf1kqcc5Jbz.pdf', 21, 27, 1, NULL, 2, 'Rashad Yates', 0, 'Valentine Duke', 'Dolore iusto aut min', NULL, 'Chairman', 'uploads/r0K3Lng9rwWzf2eHTiDDCl9sNR7nWS7I0SDbxxZD.pdf', NULL, NULL, 'uploads/membership_forms/oo0jaYR39lhra1JhE0fTdcrdNvyvZF2FCh3p2XHl.pdf', 'uploads/declarations/BH3dCfX8qGqIRGIT4SWB8174R2EPSBHwltZvyGI0.pdf', 'uploads/declarations/H2hSika5tfjS8rxReF80nPET5dhuNAXqnf9lFnEd.pdf', '2025-07-02 05:55:31', '2025-07-02 05:55:31'),
(118, 'Uma Jackson', '8710203010', 'uploads/aadhaar/TBYncPYZQLjtswJcW73VVDyr2DsZJji2NWHD8GTv.pdf', 21, 27, 2, NULL, 2, 'Colin Schwartz', 0, 'Melvin Fernandez', '82 White Nobel Freeway', NULL, 'Vice Chairman', 'uploads/naIHWKdTtOh8Sb8HQnxkYMv9ZaistD4AvxT3v5Tx.pdf', NULL, NULL, 'uploads/membership_forms/L6WGepvR9onoyAeoOllQnHaaJjO1poDhNBEWRc6o.pdf', 'uploads/declarations/87Z83zuNWfV5LQYIaZSwK99EJXdUNhG2GteImugN.pdf', 'uploads/declarations/MuXeqSi0ts0LbyRekmUcZMQ6kEhIlAtVe1tJqB5J.pdf', '2025-07-02 05:56:04', '2025-07-02 05:56:04'),
(119, 'Zena Cotton', '4310458745', 'uploads/aadhaar/hJ87uvc7qu1b5kfOiLovgT7YrSWfnaBoFbwEYjbn.pdf', 21, 27, 1, NULL, 2, 'Madison Bullock', 0, 'Jameson Stout', 'Ipsa sint consectet', NULL, 'Vice Chairman', 'uploads/RJwDeSKiFbdTxpspwJYeHN0xqeGZMZ90p3k4pWoL.pdf', NULL, NULL, 'uploads/membership_forms/xA9CLICLkJlAPpu0qRI6UUrutsx2WnsPnQYO0qgJ.pdf', 'uploads/declarations/wJltsWgITzw1UkKycjeJ9n7v2XaaVyJ8WiDHDLhl.pdf', 'uploads/declarations/PfeXNDqgPe7ptgNx93U1CYyzjKvWTF3jvuvfps36.pdf', '2025-07-02 05:56:43', '2025-07-02 05:56:43'),
(120, 'Quentin Alston', '2610307452', 'uploads/aadhaar/aL85HUjoD56jN21HlA0wacArOTuimAf7G8qDT3gV.pdf', 21, 27, 2, NULL, 1, 'Jesse Barry', 0, 'Aimee Haley', 'Ea blanditiis offici', NULL, 'Board Member', 'uploads/0z3wRlzbySr80uT4tjz2koNUesUYeb56PjmceAn2.pdf', NULL, NULL, 'uploads/membership_forms/O4Tkc9nt2imzJa8x14Kxt3I6tCuapNGz48PeFceI.pdf', 'uploads/declarations/yFoWWO8MxREyEcOAOt42TSJ7Px4bJZTW3EQDDYIx.pdf', 'uploads/declarations/NhXJmjNIaUPZgV8Y3eFkH5tuaUWkyvVKvVNOZ8kX.pdf', '2025-07-02 05:57:26', '2025-07-02 05:57:26'),
(121, 'Casey Carlson', '9010639875', 'uploads/aadhaar/vaQjfkqSnN7ni1OmRZOD4WzpvTfzWfdu3R0AhILI.pdf', 21, 27, 3, NULL, 2, 'Guy Burns', 0, 'Bernard Mcguire', 'Commodo eaque volupt', NULL, 'Vice Chairman', 'uploads/0H9MSfB3bxCF0e7J2HZCppmQ24m1phPzIkouzCEx.pdf', NULL, NULL, 'uploads/membership_forms/Z8zHVBnGhVwH08BE3ajxLnymytkht12pJe8duGJH.pdf', 'uploads/declarations/AqQf3q216QpYlIHUvOaAvIfYTxVgPo6OYO2Ua0rO.pdf', 'uploads/declarations/5uRbPuTpOB1AYnJZk0SHuptdIxeePsxMg9jRgaiX.pdf', '2025-07-02 05:57:56', '2025-07-02 05:57:56'),
(122, 'Mary Miranda', '4085231479', 'uploads/aadhaar/IHVklhAo49HmR8DrVefI0HBeAEeBCixDEaiRlcCh.pdf', 21, 27, 2, NULL, 2, 'Cassandra Peck', 0, 'Lilah Chen', 'Corrupti ad delectu', NULL, 'Vice Chairman', 'uploads/M9R2q3b8ARjZzaJLmFHCVVFqxj9fFmi3PjfjaZ0h.pdf', NULL, NULL, 'uploads/membership_forms/lC1qNi4uuq8HcOwGo5BKdgFmPUe63IoB57jfNEqq.pdf', 'uploads/declarations/DEzYWG6Ize3Rg4C08JAliBWqnD5WSu6fWqe5jyGu.pdf', 'uploads/declarations/S1JkEteKCuIxYHbfAkIYfITpxQ1dXzVxnzOa3Dzf.pdf', '2025-07-02 05:58:26', '2025-07-02 05:58:26'),
(123, 'Kadeem Johnston', '6910698732', 'uploads/aadhaar/UHDk77hQr6L5755MDSqgCUagD1cu8oaPordcIBqY.pdf', 21, 27, 2, NULL, 1, 'Tad Dillard', 0, 'Tanya Christensen', 'Tempora facere porro', NULL, 'Chairman', 'uploads/h8vs6rbSd6J5pfHjmFgTve4VJfBxCq5OUCCTVMrV.pdf', NULL, NULL, 'uploads/membership_forms/I5hh1DMlUK4XL4C8OHl23ailubvI2N47ZSSifn9I.pdf', 'uploads/declarations/0upzHwrA36azoTQUB3waTeg6w74c0WW2tTRxgEnQ.pdf', 'uploads/declarations/bMn7XUjh1Ppe4RSYsTlWyJQ6SLErEQFWZ0iHQk5X.pdf', '2025-07-02 05:58:58', '2025-07-02 05:58:58'),
(124, 'Melvin Terry', '1912304120', 'uploads/aadhaar/Anj5YZGGBTG7roiQTYNbiVWptdKO8AFsEtdYnmzW.pdf', 23, 28, 2, NULL, 2, 'Karina Carrillo', 0, 'MacKenzie Savage', 'Et velit quas minim', NULL, 'Board Member', 'uploads/ZLOwI0ssZXAHGl1vy3j92LYos8elRp6KDrw9xRjq.pdf', NULL, NULL, 'uploads/membership_forms/yvtzuwG2iVWGxQa4mLm9KfGecQ1CFyf04b6DHPzq.pdf', 'uploads/declarations/jOnkS9u0rzj1bbEQUZEGKraalW4fl3gGemoDc9xT.pdf', 'uploads/declarations/gwkLFQdOCK0wYDBER4vCngAWkoX4kLPcv5tL11Fc.pdf', '2025-07-02 10:39:02', '2025-07-02 10:39:02'),
(125, 'Zane Prince', '9900003030', 'uploads/aadhaar/LyjTnJ8KGVYSyghHQA4Qc48CDC16gtZnOYEYzfGY.pdf', 23, 28, 1, NULL, 1, 'Joseph Snyder', 0, 'Aiko Peterson', '81 Green Old Street', NULL, 'Board Member', 'uploads/JwbUyqVlBIXZYPpB8cWC92M3hOKrFocsRwzDiIr3.pdf', NULL, NULL, 'uploads/membership_forms/KQUhx6FkFIXfP1ofQKsWXjDTprbwrngpzD5nHKf0.pdf', 'uploads/declarations/Rx2gAV4fjst8AgAEx6vAnO6jGsmwOi4bx1ShsiNs.pdf', 'uploads/declarations/tfm8nUHbqgF03jaS9RE6RmltJdndfo5N5PWUDqid.pdf', '2025-07-02 10:40:27', '2025-07-02 10:40:27'),
(126, 'Sandra Osborn', '5710302040', 'uploads/aadhaar/Cepfgt0WIvUXOSxDQo4ersf29wZPPywKciferKfY.pdf', 23, 28, 2, NULL, 2, 'Kalia Mcgowan', 0, 'Valentine Mooney', 'Unde dolores quisqua', NULL, 'Secretary', 'uploads/SZQY4gpQWyZsiFnW1x4TcmNJgkt0o84c7W0z5uVI.pdf', NULL, NULL, 'uploads/membership_forms/QXQF4HmGlAhSSxebTneCdhwGP1ozkXtFbT6Xe0ld.pdf', 'uploads/declarations/FuXaE5yXiqo2m4jmqVJCQGXo4fgWXqah6xWYONYl.pdf', 'uploads/declarations/lteyaODE3pTKGBx0uXo10OHMp1fG0d0o0neNKGpn.pdf', '2025-07-02 10:41:07', '2025-07-02 10:41:07'),
(127, 'Alice Dillon', '5510320123', 'uploads/aadhaar/bUZXJWb75vPJQapuoWO4Niwbu0B4uF0TiXtb2nK8.pdf', 23, 28, 3, NULL, 2, 'Nerea Carlson', 0, 'Jillian Rodriquez', 'Ut sed odio ratione', NULL, 'Vice Chairman', 'uploads/uHQgrqb9tEJcYYpM4TCQ4Cza4KR4kv6IsLoh54cU.pdf', NULL, NULL, 'uploads/membership_forms/8UYKXLAX4wiDj5spVPEaIlPMjHUdVIoJrbF3KWc7.pdf', 'uploads/declarations/n8RRifHmaHZNRQCYGyFovXuCbJEYGNrf3paq95Xv.pdf', 'uploads/declarations/EL2PYTwssQSE4RmA15IRUJJ48s4ez0nt4b2n58M3.pdf', '2025-07-02 10:41:44', '2025-07-02 10:41:44'),
(128, 'Ruby Cabrera', '2910302010', 'uploads/aadhaar/FUbtSpOQBhiCKcIaE7C8GRjTPsINb85DSlFMVIlI.pdf', 23, 28, 3, NULL, 1, 'Lenore Aguilar', 0, 'Grant Chang', 'Duis voluptate ea se', NULL, 'Vice Chairman', 'uploads/ONKFa2PEtUwo8xphLcm22a6XpxxKmqlNELbNdFVS.pdf', NULL, NULL, 'uploads/membership_forms/vZ96sKsI4pp9rjm7T9xRFMlFjTgZoTrvtrjAfEbQ.pdf', 'uploads/declarations/oc29jSAEd0pxIVl4twxjCom7pIeKhdF0XdFLpMX3.pdf', 'uploads/declarations/5z86TDKs2hQ7WcFV1Ti9w6P2DpUkXsGKNohXcDYU.pdf', '2025-07-02 10:42:17', '2025-07-02 10:42:17'),
(129, 'Adele Mcdaniel', '7914723650', 'uploads/aadhaar/NV7sNyXMMBWyaKZZiHoqBeRPExauXeJu6jAI8j27.pdf', 23, 28, 1, NULL, 2, 'Halla Dejesus', 0, 'Cally Parrish', 'Consequuntur sequi p', NULL, 'Secretary', 'uploads/NvXIa2SQu52ix5b2UJK680uuJ8vnp3sQOWmhFSLF.pdf', NULL, NULL, 'uploads/membership_forms/OLtPzBSXGkcN9peeyCLH5td94Bjf7Qlk4Rrmwgxw.pdf', 'uploads/declarations/V0R2tMTn5HdZkcpD9cfOQllEB92ODF0OjNOKZsyq.pdf', 'uploads/declarations/xGAEO2NWsUahJ3jG3JrEBI6C7Qj2tWzbWRCDQ160.pdf', '2025-07-02 10:43:43', '2025-07-02 10:43:43'),
(130, 'Lacota Burch', '3910304021', 'uploads/aadhaar/p7somjUfUrjvbVRyqg6s3P2qiLkRVMSru7FI6YeJ.pdf', 23, 28, 2, NULL, 1, 'Orson Spence', 0, 'Zena Kirkland', 'Dolore cumque veniam', NULL, 'Board Member', 'uploads/jKYiAfbWC199sDXr1p7Nx4M7tEl15YjcOKXuUMO8.pdf', NULL, NULL, 'uploads/membership_forms/LiQPowaHBmNLfJoiKBHiYFlA7WumkLeb7I9p4uha.pdf', 'uploads/declarations/ivSuGEevk3nQUjFGwzWnBXNFThA7mEmrB5EZvsBo.pdf', 'uploads/declarations/RKKlsBxdR8Ft2tYywEslf7jUWHLP7f3e8xzbHkLh.pdf', '2025-07-02 10:44:29', '2025-07-02 10:44:29'),
(131, 'Ashely Hyde', '6541036920', 'uploads/aadhaar/CsmDc2qijQ4ucbjDzUimv4NARfHjfri1pjgHHm4l.pdf', 26, 29, 1, NULL, 1, 'Neve Atkins', 0, 'Arsenio Whitehead', 'Similique ullamco su', NULL, 'Chairman', 'uploads/22PCFlIdjCorjSImeu4S93tCw0r6DvZi60BMThAv.pdf', NULL, NULL, 'uploads/membership_forms/uQzbW0wbM3C2Cj2PmFMyRmjuDs4cxTq3JkTv2k6B.pdf', 'uploads/declarations/b7W4oWeu1a3FYMPbUBBa1oglkwYx0O08dafenfTl.pdf', 'uploads/declarations/JHXIojm6n8V82DEaKGLpG5dOn9wXu2wtLN9BCrRm.pdf', '2025-07-02 13:04:01', '2025-07-02 13:04:01'),
(132, 'Hasad Odom', '9277523698', 'uploads/aadhaar/WgNQuIFo1qcBxVbIrgo2SE6xG4UIIPe8DQUTqLbo.pdf', 26, 29, 1, NULL, 1, 'Shafira Rose', 0, 'Evangeline Hull', '152 South Oak Parkway', NULL, 'Vice Chairman', 'uploads/l7IhZbAeFAftd68gqgJdHVjUplPBPWPUpkhIRWV2.pdf', NULL, NULL, 'uploads/membership_forms/UMMCPelB1id3aUWLgWPn63OpK7CMCeNCJoLQ9eW3.pdf', 'uploads/declarations/B0NxVLOo2rUEfuAJO42w92A5o3pXrkrNorB7vvq4.pdf', 'uploads/declarations/4EQlpXXQSNPxifUJpfzVqX1U6kjxt1zX2zDVpSLb.pdf', '2025-07-02 13:39:43', '2025-07-02 13:39:43'),
(133, 'Kristen Mcfarland', '2810302041', 'uploads/aadhaar/YBWJQfrBhglXS3kheNBChQNBmQvCHCpVH9Iypr6W.pdf', 26, 29, 1, NULL, 1, 'Zahir Fuller', 0, 'Jack Cook', 'Autem a excepturi la', NULL, 'Vice Chairman', 'uploads/BKRe861IKniZ7dznvU6pUZcMQEZ2MoG081eDS9KY.pdf', NULL, NULL, 'uploads/membership_forms/FQZ0utdiBLwj4CMHmo6pgd9sOhhpFxySKDKtlQR9.pdf', 'uploads/declarations/5ooGTz8dW5Vf9zHRwQVi1k7W089NrQ9SCq9KCuPn.pdf', 'uploads/declarations/BQaLGrIB7H0vGeTiAKqnbHnqhcXKMUWhIPU1gFoB.pdf', '2025-07-02 13:47:55', '2025-07-02 13:47:55'),
(134, 'Norman Nielsen', '9310203020', 'uploads/aadhaar/V1oVHgQkdqAFWstVsEXgbsw9IdcN8IvirGekQJhK.pdf', 27, 30, 1, NULL, 2, 'Jenna Short', 0, 'Alexandra Marshall', 'Et cupidatat laudant', NULL, 'Secretary', 'uploads/XohbsqJxSvHEWaKf6SAdhtMboNSFFyQmnf8pVgFs.pdf', NULL, NULL, 'uploads/membership_forms/XXG0LdybXxKQ6n1I2eJWSDWULYI5whT2pLrvvRVR.pdf', 'uploads/declarations/Ht1aMpL98clnNVn66QgAeXbCtZVkLidP4DDkaptD.pdf', 'uploads/declarations/UyUGnJJGDNLN1L7jjMZYlGbQVKRah2lr5VDyuwKg.pdf', '2025-07-04 06:26:36', '2025-07-04 06:26:36'),
(135, 'Colleen Rios', '1341030201', 'uploads/aadhaar/BJdkMF35NXgUufVUewZ6mui9zHqKobX50jKiB3ot.pdf', 28, 31, 3, NULL, 1, 'Nadine Baxter', 0, 'Warren Bailey', 'Asperiores lorem qua', NULL, 'Board Member', 'uploads/gaaoGuWVE6GkPbyQqBOl3c0c8927NJPcLPrVuloZ.pdf', NULL, NULL, 'uploads/membership_forms/PZpKlUKe5t8PwgNQWFNhjvBIAnAule6vHqG6Po8k.pdf', 'uploads/declarations/kPvwRnpFCECCKgyiyAxtUDUs0icy1cP8I0Iuu1UI.pdf', 'uploads/declarations/3LuJdoktSB1MEEN362Gd6Lr2VJvhWiImPRTDZ5K1.pdf', '2025-07-04 06:46:34', '2025-07-04 06:46:34'),
(136, 'Alexander Vinson', '1520301458', 'uploads/aadhaar/xwC6iDQ21Hyrroz1k8JBGYBAFOO4nTmjK9slKUVl.pdf', 28, 31, 3, NULL, 2, 'Kiayada Roth', 0, 'Winter Norris', '988 Clarendon Avenue', NULL, 'Chairman', 'uploads/P1CWrtYZxM8f9iIux7vVnE9RNcey1n6M1VpJR1LR.pdf', NULL, NULL, 'uploads/membership_forms/RUv8RxuNkZ5bO5amN59LTXkjYtdg1AevJgMBr8as.pdf', 'uploads/declarations/b0Nlmbi5i51C2vgWeruBFqMAUmJVENR65Oe7JxMl.pdf', 'uploads/declarations/HYMkC8jXnDddf9RSiHT4kNzTNYGnoGOECBClwgP9.pdf', '2025-07-04 07:00:15', '2025-07-04 07:00:15'),
(137, 'Alden Pruitt', '1102030582', 'uploads/aadhaar/JrsRX7RsVn63VNv4S7PGFsLpkt4sAxPMNlKS9dDy.pdf', 28, 31, 1, NULL, 1, 'Karly Cabrera', 0, 'Sydney Hogan', 'Corporis ea consequa', NULL, 'Secretary', 'uploads/2cJ0BdT1LDhGIMRua3bU1lOOXBio92xYO61lwnZm.pdf', NULL, NULL, 'uploads/membership_forms/y6Q69MA5PZJzPl4E3my0wt2Nx7qjqxixW5Mgk6V2.pdf', 'uploads/declarations/ziIPnXoxK9jafZeJ2eg6VEK3E0qNaTsC02svNmvO.pdf', 'uploads/declarations/4GxRX6rPIVburcvCsAoo71TyBnBsPf51L0tT8DYX.pdf', '2025-07-04 07:01:10', '2025-07-04 07:01:10'),
(138, 'Kimberly Kennedy', '2410302587', 'uploads/aadhaar/8WQ0JsFti0q7Ti0qYnieHiL6JA2SqRgvu553Ail9.pdf', 28, 31, 3, NULL, 1, 'Julie Freeman', 0, 'Yen Peters', 'Esse placeat volup', NULL, 'Chairman', 'uploads/DXp3z4JOkt9x43TjBvzDnzVoQ0yrZemwvF5eRJAI.pdf', NULL, NULL, 'uploads/membership_forms/7Gd9cjpGE0mFLzS9XLLKG3N8D2uGdruaT4JZ48Nq.pdf', 'uploads/declarations/kCBjlDFXY7rTPCsr4J9indJLjju1tyvy1rvGWwfp.pdf', 'uploads/declarations/DgcAwGuK4uPVPRwcF0b809t8Ck6rUU4Oo6o7Umt9.pdf', '2025-07-04 07:02:06', '2025-07-04 07:02:06'),
(139, 'Madison Carney', '9241023698', 'uploads/aadhaar/8bolimjNvDLUtClQQm9FCY1iyN5HFVFxzeOknsPN.pdf', 28, 31, 2, NULL, 1, 'Declan Burris', 0, 'Cain Buck', 'Aute perferendis vel', NULL, 'Secretary', 'uploads/YomHWCNF1kM8Jl0jAIkS5pNKEAjQHR0FxyIFnV3h.pdf', NULL, NULL, 'uploads/membership_forms/DGUvf7OpsYGPwJLh4NwW0hhiDwuoCsUhkiO1SpJn.pdf', 'uploads/declarations/d5XrAoNCLOiDMN09KGv6nEhDxofrIPEAU99PGAzb.pdf', 'uploads/declarations/bBJ0cndTYFQYp2pJhL7eHTSX9I16GqP3PdE66Ox8.pdf', '2025-07-04 07:03:00', '2025-07-04 07:03:00'),
(140, 'Shafira Andrews', '7410326585', 'uploads/aadhaar/ioDa5AB3AwmyhzLflv90ivFUT9uMjowLYKCSH7Hx.pdf', 28, 31, 3, NULL, 2, 'Carter Davenport', 0, 'Allegra Petty', 'Id laboris possimus', NULL, 'Board Member', 'uploads/idKCKkVZ3TYrK038IQbAcan9CqCEL8fDfQbL1urX.pdf', NULL, NULL, 'uploads/membership_forms/DCGbVaUq1YUGO9KfelLSMDJbILXZ6mRkaz8YRyAx.pdf', 'uploads/declarations/4rS9yAUFAsV2AAzxafXAGjFgM9D4EromljtOHIEJ.pdf', 'uploads/declarations/BvTEm09pyoCEFtlj2yQFjIJVKpRbjtdRUTKVrBNJ.pdf', '2025-07-04 07:04:34', '2025-07-04 07:04:34'),
(141, 'Fiona Morales', '9410302587', 'uploads/aadhaar/lBZUCXVaEDdyQWqGAhdQjFnbrlP4rbSlIZts0Wzq.pdf', 28, 31, 1, NULL, 2, 'Nayda Nguyen', 0, 'Violet Dennis', 'Architecto eum id te', NULL, 'Board Member', 'uploads/TWbnIQTy98vOET2B7umrbMWcirul37T7hqxACBHi.pdf', NULL, NULL, 'uploads/membership_forms/ypl8BcBWYSl0pj4NiUrCU0XRxzEosaO6LK1xkYHo.pdf', 'uploads/declarations/jUs1Movb7qjFG4i2NgvjtGbswkYXMbcJw5IPfNyd.pdf', 'uploads/declarations/H9MlDYfQiQDpihDiIuMQvSt48n73S1A0LwXCYagz.pdf', '2025-07-04 07:05:18', '2025-07-04 07:05:18');

-- --------------------------------------------------------

--
-- Table structure for table `members_objective`
--

DROP TABLE IF EXISTS `members_objective`;
CREATE TABLE IF NOT EXISTS `members_objective` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` bigint NOT NULL,
  `member_responsibility_type` int DEFAULT NULL,
  `capital_valuation_type` int DEFAULT NULL,
  `capital_amount` decimal(8,2) DEFAULT NULL,
  `society_operational_area` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_objective` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_share_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_liability` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `general_member_count` int DEFAULT NULL,
  `society_record_language` int DEFAULT NULL COMMENT '1-English,2-Hindi',
  `society_representative_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_representative_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_representative_signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_secretary_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_secretary_address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_secretary_signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `subscription_rate` decimal(8,2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=28 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `members_objective`
--

INSERT INTO `members_objective` (`id`, `society_id`, `member_responsibility_type`, `capital_valuation_type`, `capital_amount`, `society_operational_area`, `society_objective`, `society_share_value`, `member_liability`, `general_member_count`, `society_record_language`, `society_representative_name`, `society_representative_address`, `society_representative_signature`, `society_secretary_name`, `society_secretary_address`, `society_secretary_signature`, `created_at`, `updated_at`, `subscription_rate`) VALUES
(1, 1, 1, 1, 0.00, 'ukytiu', '8899', '900', '900', 9, 1, 'sohel', 'bbsr', 'uploads/k11HriJF5B4w7I0ShSc2svyLplX8Ff6UTpYhqWXx.pdf', 'soumya', 'ctc', 'uploads/HysKCTdMBsdz8mKqjseLFlEJJ9RUQXHr1GJR6vNd.pdf', '2025-06-13 07:01:45', '2025-06-13 07:01:45', 900.00),
(2, 7, 2, 0, 0.00, 'Quis quos id eos n', 'Deleniti ipsam ut es', '32', 'Molestiae et commodo', 65, 1, 'Bernard Barker', 'Autem accusamus vel', 'uploads/lDnIsZrXROHAIJ8cNh2lHwBDS9rnsRXb9NB6sMVa.pdf', 'Briar Humphrey', 'Neque porro do enim', 'uploads/OIeFEIk98JvIrBCyK9hn0yG5PFha6zYqsBeqoMay.pdf', '2025-06-17 04:58:48', '2025-06-17 04:58:48', 28.00),
(3, 6, 1, 1, 0.00, 'Perspiciatis conseq', 'In ea ut sapiente qu', '96', 'Modi et est sit et d', 5, 2, 'Shay Herman', 'Atque non numquam ul', 'uploads/0sFHP5eHRX9YzSRA1S2rKfl8zHLX3mrEmHJEV0uP.pdf', 'Katelyn Weiss', 'Molestias tempora id', 'uploads/DAkTxyFFEshaeMOvuJ7Ibt1B6ZqCiqCLAHnNmjFO.pdf', '2025-06-17 05:40:47', '2025-06-17 05:40:47', 85.00),
(4, 5, 2, 0, 0.00, 'Quia magni totam ver', 'Quod ea assumenda ne', '48', 'Nemo cum ab est offi', 29, 2, 'Veronica Carver', 'Nisi dicta reprehend', 'uploads/c1AWmk7fewP375WM2NU8yXhbVMvgdjnFQh6uFC61.pdf', 'Madonna Benjamin', 'Elit in voluptas ma', 'uploads/N0ebokwDGDcADtNrGiara52WPlMh7cxEX9tqceA9.pdf', '2025-06-24 09:28:59', '2025-06-30 13:29:47', 40.00),
(5, 2, 2, 0, 0.00, ',kkkk', '88', '777', '55', 88, 2, 'kkk', 'nm', 'uploads/I9jNwLtuMNDnz42aYR1DYRMOOr7lnx2aPS2NO8XY.pdf', 'mm', 'nnn', 'uploads/mogefAxDDYWzqq9wJUzYs0DkV5W01vZlkRvqanxZ.pdf', '2025-06-24 09:30:34', '2025-06-24 09:30:34', 55.00),
(6, 8, 1, 1, 0.00, 'Accusamus esse dolo', 'Ut quo est cillum cu', '11', 'Ad ut quae aperiam f', 65, 1, 'Lucy Gill', 'Quidem ipsam deserun', 'uploads/nDGrhMpRvaIpZzpU6RcUKwTTrDZb01JTiuIhtVoY.pdf', 'Quintessa Mcpherson', 'Aliquid quis fugit', 'uploads/7h9pbSSlEaq9WQN57Sl6rVgCdWzUcUrH3qxjC31i.pdf', '2025-06-26 08:50:36', '2025-06-26 08:50:36', 6.00),
(7, 9, 2, 0, 0.00, 'Odio non itaque dign', 'Ipsum sed expedita m', '42', 'Quae porro dicta exc', 51, 1, 'Buckminster Adkins', 'Architecto cupidatat', 'uploads/E3oo6ZCngAHfXkdKlYpEupSpqdygju0Tfx21t0ko.pdf', 'Sylvester Petty', 'Sunt nihil dolore om', 'uploads/DRTIMiKzJGci7iVPzEZ2gFwbem4nWE1kanBj8SA5.pdf', '2025-06-26 10:31:00', '2025-06-30 08:35:46', 69.00),
(8, 10, 1, 1, 0.00, 'Anim doloribus non a', 'Optio voluptatibus', '16', 'Fuga Ut ipsum tempo', 49, 2, 'Judah Schneider', 'Ullamco quaerat cupi', 'uploads/uOY4jUXBPARBxNzwZ8pPwASCJlIfg2rP9zcnGdc6.pdf', 'Pascale Moss', 'Nisi voluptatem Et', 'uploads/YcqZMV1HXYU2LHlAojYnBjWijEHMpuMIewBBXuUV.pdf', '2025-06-30 05:06:43', '2025-06-30 05:06:43', 74.00),
(9, 11, 2, 0, 0.00, 'Voluptatem fugiat lo', 'Ipsa illum est qui', '31', 'Id est illum eaque', 96, 3, 'Tyler Ross', 'Molestias cillum nes', 'uploads/PYV3z8GFa4xj2ctWE3mBn1uSSivvqKSK1MlesWJw.pdf', 'Madonna Nicholson', 'In ut reprehenderit', 'uploads/PnZINCDGNUP3ACHBbzEx9FdPMMJnrH3quY8ZZWW6.pdf', '2025-06-30 06:55:41', '2025-06-30 06:55:41', 1.00),
(10, 4, 1, 1, 0.00, 'Neque nulla voluptas', 'Nam nobis eius nulla', '58', 'Minim sint quisquam', 92, 1, 'Rahim Ramsey', 'Tempora aute qui eum', 'uploads/C30JvYLczwC8jHdNaPekike7eR3KaO0xZv3Uys2q.pdf', 'Rina Benton', 'Consectetur perferen', 'uploads/Fuc8RMev9d9bKKJBstxYiwXVc0VtwT3qwJwhAADF.pdf', '2025-06-30 08:37:15', '2025-06-30 08:45:12', 34.00),
(11, 12, 2, 0, 0.00, 'Ut nihil cumque dese', 'Et et doloribus eum', '33', 'Amet deserunt lorem', 90, 1, 'Nolan Long', 'Eligendi ut ipsum te', 'uploads/NMYB5QQ210OVgvaExHP8br2ldkCc1pC22X4raEEh.pdf', 'Frances Finch', 'Aut accusantium fugi', 'uploads/pEatkuEmTBfVaTs1oed1yYRcP1WDZqGf67sB1IY9.pdf', '2025-06-30 10:46:25', '2025-06-30 10:46:25', 24.00),
(12, 13, 2, 0, 0.00, 'Reprehenderit labor', 'Eu deserunt fugiat', '23', 'In qui aliquip archi', 15, 3, 'Hop Waller', 'Voluptate magnam qui', 'uploads/zOziiw9O2B6uAjgSn08bthbwnCkDqwkGA7fKm4kS.pdf', 'Kenyon Wells', 'Velit delectus dele', 'uploads/zJhWFbIo8LbxDA2HUBfmmge2kvNxvYJndoWeJ8kM.pdf', '2025-06-30 12:14:36', '2025-06-30 12:40:44', 38.00),
(13, 14, 2, 0, 0.00, 'Non quo quae cumque', 'Aut aperiam rerum fu', '70', 'Accusantium ducimus', 71, 2, 'Iola Vance', 'Laboris eiusmod ex d', 'uploads/ztGsH7vfSVjsnhsz2b74rc6FpLaQSD5VsbeN3MOV.pdf', 'Sandra Carrillo', 'Aut ex velit volupt', 'uploads/K2sRu7pXFWje3pqzSRGfEi2kbzlK5TP58kdHdu5q.pdf', '2025-06-30 12:22:25', '2025-07-01 05:20:46', 89.00),
(14, 15, 1, 1, 0.00, 'Debitis sint vel ab', 'Nulla rerum rerum qu', '62', 'Reiciendis qui volup', 49, 2, 'Lee Clarke', 'Fugit vitae culpa i', 'uploads/jZa0ZTAL9bi4HjVDS98fkxyr63ualzYuUu4RtDBN.pdf', 'Leroy Munoz', 'Ullam iusto officiis', 'uploads/aOAHTYfzSLbbwVscYxUrHviXabHJmttUxDigNjP6.pdf', '2025-07-01 06:15:30', '2025-07-01 06:15:30', 53.00),
(15, 16, 2, 0, 0.00, 'Ipsum veniam minim', 'Quis quia magni arch', '66', 'Eaque minima est vol', 7, 2, 'Hiram Delaney', 'Enim magnam velit v', 'uploads/5hIASqoE81kyCCrvHtoEfOqlmAY9QWrawCKzwArC.pdf', 'Deacon Fitzgerald', 'Voluptate delectus', 'uploads/hsayX3iil8deeHQxdmp9KefpzeZPzuvXU8pCwiuM.pdf', '2025-07-01 08:47:34', '2025-07-01 08:47:34', 42.00),
(16, 17, 2, 0, 0.00, 'Corporis molestiae q', 'Architecto rerum mol', '92', 'Velit dolor aliquip', 68, 3, 'Connor Rutledge', 'Qui magna non cupida', 'uploads/BcI7HpHn1nh7OgngvNaH0Iy2NNzfzYEwOvo8cVWC.pdf', 'Stella Morrison', 'Minim adipisci Nam q', 'uploads/jifXt0xenGI9ziO4qza8DtVaP97Ne1xiV1AzNU22.pdf', '2025-07-01 09:54:26', '2025-07-01 09:54:26', 83.00),
(17, 18, 1, 1, 0.00, 'Sit adipisicing qua', 'Et eius in esse adi', '36', 'Reprehenderit quae r', 12, 3, 'Sophia Nolan', 'Qui ut maxime in har', 'uploads/kb00MLbIdWfXEDk639F1dSTFskfdNkPDEVHVlPEo.pdf', 'Ifeoma Haney', 'Suscipit voluptas et', 'uploads/L1sEzEvy4OOITy7dtivQStNoGaCrX8wlgOssSWol.pdf', '2025-07-01 10:25:55', '2025-07-01 10:25:55', 85.00),
(18, 19, 2, 0, 0.00, 'Maxime omnis cupidat', 'Illum lorem id vero', '4', 'Ex atque est quia ve', 96, 2, 'Karyn Harrison', 'Adipisicing molestia', 'uploads/B84FAH8OBBTAArctcCQyH6EWC8DHTfBmKOB2SWsv.pdf', 'Gil Evans', 'Delectus aut cumque', 'uploads/hZZLrOHZrLKZeJENgXv2lRVGQnlTYbOWyPNoQMFk.pdf', '2025-07-01 13:00:03', '2025-07-01 13:00:03', 1.00),
(19, 20, 2, 0, 0.00, 'Provident vitae qui', 'Rem maxime itaque qu', '88', 'Deserunt aliquid und', 66, 1, 'John Macdonald', 'Ad vero enim assumen', 'uploads/KRU5KZFFnfI3DFoQ4vGcPbclbQLfG1nK4568ghqO.pdf', 'Kevin Fitzpatrick', 'Ratione ad do ut dol', 'uploads/5KBGIlvxEEQJvtjbkyeSzfYa44DOAbtPjYsh5eol.pdf', '2025-07-01 18:09:10', '2025-07-01 18:09:10', 25.00),
(20, 21, 2, 0, 0.00, 'Ad Nam nulla ad exer', 'Aliquam et quae exce', '36', 'Est eu soluta accusa', 48, 1, 'Patrick Madden', 'Iste laborum modi qu', 'uploads/HdDpdPn11ClgJjOJZDGyk2eFABXgVJ0JDEVorxRQ.pdf', 'Quinn Roach', 'Qui proident molest', 'uploads/i1WhC8eRPExuaMffdD82dIhEp80ZUwhXf7ywgOCr.pdf', '2025-07-01 18:09:51', '2025-07-02 05:59:39', 5.00),
(21, 22, 2, 0, 0.00, 'Expedita minus deser', 'Incidunt sit libero', '31', 'Commodo incidunt vo', 52, 3, 'Isabelle Chandler', 'Earum facilis omnis', 'uploads/z0g8omPi0kRRZCIo9ZV8c8ELHlzjCnkXE0r0SwBm.pdf', 'Brennan Hunt', 'Minus dolore optio', 'uploads/dQeEIcG17XDVcTDpLQm7kXquSyN9JduGRT37xRlM.pdf', '2025-07-01 18:20:16', '2025-07-01 19:58:28', 37.00),
(22, 23, 2, 0, 0.00, 'Provident voluptatu', 'Vero at aperiam amet', '10', 'Qui iusto et sunt e', 34, 2, 'Abbot Boyle', 'Laborum quaerat aut', 'uploads/6q3jOqR4DX6MY60c9uWnN4F2tMveCucPpk1zcX8w.pdf', 'Astra Rivera', 'Eligendi culpa quam', 'uploads/ux2GJYfPrglxIvsxr5sWHwW59f9sxD8D2QpHmsf2.pdf', '2025-07-02 10:38:14', '2025-07-02 10:48:36', 63.00),
(23, 24, 2, 0, 0.00, 'Quasi tempor rerum e', 'Et ab et deserunt in', '96', 'Sit cum distinctio', 2, 1, 'Illana Nielsen', 'Occaecat deleniti fu', 'uploads/UnIHKOmdHXIKM6yzdtKrzAWVvC4gO8YBsgnqMg1C.pdf', 'Brynne Dodson', 'Non est sit quia par', 'uploads/4JQQH9oYH6CDQ8mR3kq8iaG7OBmYOOLt24Zdiioy.pdf', '2025-07-02 12:19:25', '2025-07-02 12:34:13', 15.00),
(24, 25, 2, 0, 0.00, 'Vel dolor sint magn', 'Harum maiores sed qu', '38', 'Voluptates est volup', 14, 1, 'Selma Quinn', 'Et est laborum et nu', 'uploads/PBTeqt9Y2lolRLjNy5FwZ7TAGOMmuR6dEycsD5Bk.pdf', 'Astra Buck', 'Asperiores perspicia', 'uploads/n6v0PTinfJAEzeCQjdWb7ZY284Ep7pmUv282nKPG.pdf', '2025-07-02 12:36:10', '2025-07-02 12:53:31', 15.00),
(25, 26, 2, 0, 0.00, 'Id voluptatem nisi s', 'Qui libero quia sit', '67', 'Architecto quia expe', 40, 2, 'Aquila Hurst', 'Quasi consequuntur l', 'uploads/k3QW7dFdWLlFjt9lWmfVfTroeuVvGKSqZQTdKRhK.pdf', 'Sophia Rowland', 'Dolor natus ut liber', 'uploads/EwNnQQMQYy2W23qdHNQsg7loi2MnhXW5iRPUitzI.pdf', '2025-07-02 12:56:21', '2025-07-02 13:47:14', 10.00),
(26, 27, 2, 0, 0.00, 'Laborum ipsum magni', 'Aliquam quia eum dol', '14', 'Eiusmod optio elit', 20, 3, 'Wanda Rivers', 'Iste aut quia et atq', 'uploads/MZoeeJoeLKtyLpBbHCUkrYJ7fBRWJywY42IcLTTl.pdf', 'Matthew Summers', 'Nisi est aliquid su', 'uploads/7o73KKDFxmt8Ne5AqNUturBxJoqMuIEIsss5Dpg9.pdf', '2025-07-04 06:22:09', '2025-07-04 06:31:08', 12.00),
(27, 28, 2, 0, 0.00, 'Quia qui rerum ad mo', 'Neque numquam deleni', '60', 'Quo officia aut in q', 57, 3, 'Thaddeus Bowman', 'Sapiente nihil est', 'uploads/0IWBmyoF40peQ9BEVEdQ957lPWjSUf7hEZiE6ICg.pdf', 'Abigail Gallagher', 'Omnis sit aut ut cum', 'uploads/ej2GQjAtm6dtCQj5uo3mBVNLF4xkp7Iab5JQZreq.pdf', '2025-07-04 06:45:41', '2025-07-04 06:59:09', 51.00);

-- --------------------------------------------------------

--
-- Table structure for table `member_declarations`
--

DROP TABLE IF EXISTS `member_declarations`;
CREATE TABLE IF NOT EXISTS `member_declarations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `is_declared` tinyint(1) NOT NULL DEFAULT '0' COMMENT '1-yes,0-no',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `society_id` bigint DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=32 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `member_declarations`
--

INSERT INTO `member_declarations` (`id`, `is_declared`, `created_at`, `updated_at`, `society_id`) VALUES
(1, 0, '2025-06-13 07:02:29', '2025-06-13 07:02:29', 1),
(2, 0, '2025-06-13 07:02:48', '2025-06-13 07:02:48', 1),
(3, 0, '2025-06-13 07:04:07', '2025-06-13 07:04:07', 1),
(4, 0, '2025-06-13 07:04:54', '2025-06-13 07:04:54', 1),
(5, 0, '2025-06-13 07:06:42', '2025-06-13 07:06:42', 1),
(6, 0, '2025-06-13 07:08:26', '2025-06-13 07:08:26', 1),
(7, 0, '2025-06-13 07:09:12', '2025-06-13 07:09:12', 1),
(8, 0, '2025-06-13 07:09:47', '2025-06-13 07:09:47', 1),
(9, 0, '2025-06-13 07:10:23', '2025-06-13 07:10:23', 1),
(10, 0, '2025-06-13 07:10:56', '2025-06-13 07:10:56', 1),
(11, 0, '2025-06-17 04:59:29', '2025-06-17 04:59:29', 7),
(12, 0, '2025-06-17 05:41:33', '2025-06-17 05:41:33', 6),
(13, 0, '2025-06-26 08:51:23', '2025-06-26 08:51:23', 8),
(14, 0, '2025-06-26 10:33:02', '2025-06-26 10:33:02', 9),
(15, 0, '2025-06-30 05:07:25', '2025-06-30 05:07:25', 10),
(16, 0, '2025-06-30 06:56:17', '2025-06-30 06:56:17', 11),
(17, 0, '2025-06-30 08:38:10', '2025-06-30 08:38:10', 4),
(18, 0, '2025-06-30 10:49:05', '2025-06-30 10:49:05', 12),
(19, 0, '2025-06-30 12:15:23', '2025-06-30 12:15:23', 13),
(20, 0, '2025-06-30 12:23:19', '2025-06-30 12:23:19', 14),
(21, 0, '2025-07-01 06:16:28', '2025-07-01 06:16:28', 15),
(22, 0, '2025-07-01 08:48:07', '2025-07-01 08:48:07', 16),
(23, 0, '2025-07-01 09:58:32', '2025-07-01 09:58:32', 17),
(24, 0, '2025-07-01 10:27:28', '2025-07-01 10:27:28', 18),
(25, 0, '2025-07-01 13:02:15', '2025-07-01 13:02:15', 19),
(26, 0, '2025-07-01 18:26:49', '2025-07-01 18:26:49', 22),
(27, 0, '2025-07-02 05:55:31', '2025-07-02 05:55:31', 21),
(28, 0, '2025-07-02 10:39:02', '2025-07-02 10:39:02', 23),
(29, 0, '2025-07-02 13:04:01', '2025-07-02 13:04:01', 26),
(30, 0, '2025-07-04 06:26:35', '2025-07-04 06:26:35', 27),
(31, 0, '2025-07-04 06:46:34', '2025-07-04 06:46:34', 28);

-- --------------------------------------------------------

--
-- Table structure for table `member_type`
--

DROP TABLE IF EXISTS `member_type`;
CREATE TABLE IF NOT EXISTS `member_type` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=113 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '0001_01_01_000000_create_users_table', 1),
(2, '0001_01_01_000001_create_cache_table', 1),
(3, '0001_01_01_000002_create_jobs_table', 1),
(4, '2025_03_19_070840_add_column_to_users_table', 1),
(5, '2025_03_19_092545_create_scheme_table', 1),
(6, '2025_03_19_092725_create_society_details_table', 1),
(7, '2025_03_19_093649_create_members_objective_table', 1),
(8, '2025_03_19_095101_create_otps_table', 1),
(9, '2025_03_19_095232_create_members_table', 1),
(10, '2025_03_19_102556_create_feasibility_reports_table', 1),
(11, '2025_03_19_104932_create_signature_details_table', 1),
(12, '2025_03_19_110102_create_society_app_details_table', 1),
(13, '2025_03_19_110639_add_email_and_mob_no_to_otps_table', 1),
(14, '2025_03_19_111510_create_member_type_table', 1),
(15, '2025_03_21_084452_create_permission_tables', 1),
(16, '2025_03_24_101055_add_subscription_rate_to_members_objective__table', 1),
(17, '2025_03_25_052743_add_authority_designation_column_to_signature_details', 1),
(18, '2025_03_25_053432_rename_column_in_feasibility_report', 1),
(19, '2025_03_25_053747_add_society_id_to_members', 1),
(20, '2025_03_25_114403_create_member_declarations_table', 1),
(21, '2025_03_25_114944_remove_column_from_members_table', 1),
(22, '2025_03_26_103843_add_column_name_to_member_decalarations', 1),
(23, '2025_03_27_055522_remove_column_from_feasibility_reports', 1),
(24, '2025_03_27_055741_add_column_to_members', 1),
(25, '2025_04_04_065945_create_states_table', 1),
(26, '2025_04_04_070012_create_districts_table', 1),
(27, '2025_04_04_070144_create_blocks_table', 1),
(28, '2025_04_21_130053_create_amendment_commitee_details_table', 1),
(29, '2025_04_21_130329_create_amendment_resolution_details_types_table', 1),
(30, '2025_04_22_073236_create_area_of_operations_table', 1),
(31, '2025_04_22_094322_add_display_name_to_roles_table', 1),
(32, '2025_04_22_124315_add_module_id_to_permissions_table', 1),
(33, '2025_04_22_140948_create_complaint_types_table', 1),
(34, '2025_04_23_055311_create_divisions_table', 1),
(35, '2025_04_23_060108_create_sub_divisions_table', 1),
(36, '2025_04_23_060140_create_panchayats_table', 1),
(37, '2025_04_23_062221_add_columns_to_society_app_details_for_approval', 1),
(38, '2025_04_23_091311_create_society_application_flows_table', 1),
(39, '2025_04_23_094437_create_society_application_status_logs_table', 1),
(40, '2025_04_23_121132_add_society_id_table', 1),
(41, '2025_04_24_102510_add_division_id_to_users_table', 1),
(42, '2025_04_24_113408_create_complaints_table', 1),
(43, '2025_04_24_115530_create_amendment_societies_table', 1),
(44, '2025_04_24_161631_update_role_enum_values', 1),
(45, '2025_04_24_173525_add_district_id_table', 1),
(46, '2025_04_25_000936_create_managing_committes_table', 1),
(47, '2025_04_25_101815_alter_action_enum_in_society_application_flows', 1),
(48, '2025_04_25_112324_create_society_types_table', 1),
(49, '2025_04_25_112401_create_aam_sabha_meetings_table', 1),
(50, '2025_04_25_113117_create_voting_on_amendments_table', 1),
(51, '2025_04_25_115842_create_society_objectives_table', 1),
(52, '2025_04_28_150346_rename_aam_sabha_meetings_to_amendment_aam_sabha_meetings', 1),
(53, '2025_04_28_151020_rename_managing_committes_to_amendment_managing_committes', 1),
(54, '2025_04_28_151335_rename_voting_on_amendments_to_amendment_voting_on_amendments', 1),
(55, '2025_04_28_152034_drop_amendment_commitee_details', 1),
(56, '2025_04_28_152402_drop_amendment_resolution_details_types', 1),
(57, '2025_04_28_154952_add_status_to_amendment_societies', 1),
(58, '2025_04_28_163023_add_current_role_to_amendment_societies', 1),
(59, '2025_04_28_163230_add_com_no_to_complaints_table', 1),
(60, '2025_04_28_215523_add__role_to_amendment_societies', 1),
(61, '2025_04_29_123209_create_complaint_application_flows_table', 1),
(62, '2025_04_29_124806_create_amendment_application_flows_table', 1),
(63, '2025_04_29_154916_create_amendment_application_status_logs_table', 1),
(64, '2025_04_30_154629_create_complaint_application_flow_logs_table', 1),
(65, '2025_05_01_115415_add_complaint_by_to_complaints_table', 1),
(66, '2025_05_01_144952_add_attempted_at_to_password_reset_tokens_table', 1),
(67, '2025_05_01_150615_create_inquiries_table', 1),
(68, '2025_05_01_152718_create_inspections_table', 1),
(69, '2025_05_01_172016_create_inspectors_table', 1),
(70, '2025_05_05_140011_create_financial_years_table', 1),
(71, '2025_05_07_163830_add_remark_to_inspections_table', 1),
(72, '2025_05_08_102017_create_audit_alotments_table', 1),
(73, '2025_05_08_162422_alter_roles_to_lowercase_in_inspections_table', 1),
(74, '2025_05_12_125910_add_auditor_start_date_to_audit_alotments', 1),
(75, '2025_05_13_112843_create_inspection_application_flows_table', 1),
(76, '2025_05_13_113420_create_inspection_application_flow_logs_table', 1),
(77, '2025_05_13_115450_add_current_role_to_audit_alotments', 1),
(78, '2025_06_03_155016_add_area_operation_to_feasibility_reports', 1),
(79, '2025_06_03_171239_create_inspector_reports_table', 1),
(80, '2025_06_04_110206_create_society_register_documents_table', 1),
(81, '2025_06_04_120231_add_membership_to_members', 1),
(82, '2025_06_10_124335_create_society_sector_types_table', 1),
(83, '2025_06_10_144001_add_society_sector_type_id_to_society_details_table', 1),
(84, '2025_06_10_152648_add_district_block_to_amendment_societies', 1),
(85, '2025_06_12_142631_add_soiety_category_to_amendment_societies', 1),
(86, '2025_06_12_161941_add_registration_certificate_to_amendment_managing_committes', 1),
(87, '2025_06_13_124759_add_is_credit_to_society_app_details', 2),
(88, '2025_06_13_132614_add_contact_no_to_members_table', 3),
(89, '2025_06_13_153310_drop_is_credit_society_from_society_app_details_table', 3),
(90, '2025_06_13_153947_drop_is_credit_society_column_from_society_app_details_table', 4),
(91, '2025_06_13_154240_add_is_credit_to_society_details', 5),
(92, '2025_06_17_125247_add_aadhar_upload_to_complaints_table', 6),
(93, '2025_06_17_145019_update_current_role_enum_complaints', 6),
(94, '2025_06_20_100948_create_assign_committees_table', 6),
(95, '2025_06_24_143011_create_document_verification_flows_table', 6),
(96, '2025_06_25_154010_add_document_verification_fields_to_society_app_details', 7),
(97, '2025_06_25_182601_add_verification_details_to_society_register_documents', 8),
(98, '2025_06_26_120940_add_signature_to_complaint_application_flows_table', 9),
(99, '2025_06_26_122856_add_signature_to_complaint_application_flow_logs_table', 9),
(100, '2025_07_01_162015_add_is_member_add_to_complaints_table', 10),
(101, '2025_07_01_232120_add_society_email_to_society_details', 10),
(102, '2025_07_02_184426_create_tehsils_table', 11),
(103, '2025_07_03_151212_create_nominations_table', 12),
(104, '2025_07_03_153652_create_nomination_documents_table', 12),
(105, '2025_07_05_141547_create_inspection_targets_table', 13),
(106, '2025_07_05_114313_create_settlement_application_details_table', 14),
(107, '2025_07_05_120006_create_settlement_parties_involved_details_table', 14),
(108, '2025_07_05_120716_create_settlement_dispute_details_table', 14),
(109, '2025_07_05_122052_create_settlement_declaration_details_table', 14),
(110, '2025_07_05_122417_create_settlement_evidence_details_table', 14),
(111, '2025_07_05_175651_add_forward_complaint_to_to_complaints_table', 14),
(112, '2025_07_08_150641_create_inspection_target_societies_table', 15);

-- --------------------------------------------------------

--
-- Table structure for table `model_has_permissions`
--

DROP TABLE IF EXISTS `model_has_permissions`;
CREATE TABLE IF NOT EXISTS `model_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `model_has_roles`
--

DROP TABLE IF EXISTS `model_has_roles`;
CREATE TABLE IF NOT EXISTS `model_has_roles` (
  `role_id` bigint UNSIGNED NOT NULL,
  `model_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_id_model_type_index` (`model_id`,`model_type`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `model_has_roles`
--

INSERT INTO `model_has_roles` (`role_id`, `model_type`, `model_id`) VALUES
(1, 'App\\Models\\User', 7),
(3, 'App\\Models\\User', 1),
(4, 'App\\Models\\User', 2),
(5, 'App\\Models\\User', 3),
(6, 'App\\Models\\User', 4),
(7, 'App\\Models\\User', 8),
(8, 'App\\Models\\User', 5),
(8, 'App\\Models\\User', 6),
(11, 'App\\Models\\User', 10),
(12, 'App\\Models\\User', 9),
(13, 'App\\Models\\User', 11),
(13, 'App\\Models\\User', 12);

-- --------------------------------------------------------

--
-- Table structure for table `nominations`
--

DROP TABLE IF EXISTS `nominations`;
CREATE TABLE IF NOT EXISTS `nominations` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `society_category` int DEFAULT NULL COMMENT '1-primary,2-central,3-apex',
  `district_id` bigint UNSIGNED DEFAULT NULL,
  `block_id` bigint UNSIGNED DEFAULT NULL,
  `registration_number` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `total_members` int NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `status` int DEFAULT NULL COMMENT '1-pending,2-Reverted,3-Approved by admin,4-Approved by JRCS',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nominations_district_id_foreign` (`district_id`),
  KEY `nominations_block_id_foreign` (`block_id`),
  KEY `nominations_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nominations`
--

INSERT INTO `nominations` (`id`, `society_name`, `society_category`, `district_id`, `block_id`, `registration_number`, `total_members`, `user_id`, `status`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Tamekah Blair', 3, NULL, NULL, '619', 60, NULL, 0, '2025-07-03 10:24:53', '2025-07-03 10:24:53', NULL),
(2, 'Jeanette Rose', 3, NULL, NULL, '409', 89, NULL, 0, '2025-07-03 10:25:10', '2025-07-03 10:25:10', NULL),
(3, 'TaShya Weiss', 3, NULL, NULL, '964', 76, NULL, 1, '2025-07-03 10:50:27', '2025-07-03 10:52:59', NULL),
(4, 'wwwwwwwwwwwwwwwnhuuuu', 1, 13, 92, '111111111111111111111', 20, 8, 1, '2025-07-04 09:31:07', '2025-07-04 09:32:55', NULL),
(5, 'Timothy Peterson', 1, 7, 48, '164', 56, 8, 0, '2025-07-04 09:46:56', '2025-07-04 09:46:56', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `nomination_documents`
--

DROP TABLE IF EXISTS `nomination_documents`;
CREATE TABLE IF NOT EXISTS `nomination_documents` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `nomination_id` bigint UNSIGNED DEFAULT NULL,
  `is_new_society` tinyint(1) NOT NULL DEFAULT '0',
  `formation_date` date DEFAULT NULL,
  `last_election_date` date DEFAULT NULL,
  `election_certificate` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `balance_sheet` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `audit_report` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `proposal` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `members_list` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ward_allocation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `challan_receipt` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `secretary_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `secretary_signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `chairman_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `chairman_signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nomination_documents_nomination_id_foreign` (`nomination_id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `nomination_documents`
--

INSERT INTO `nomination_documents` (`id`, `nomination_id`, `is_new_society`, `formation_date`, `last_election_date`, `election_certificate`, `balance_sheet`, `audit_report`, `proposal`, `members_list`, `ward_allocation`, `challan_receipt`, `secretary_name`, `secretary_signature`, `chairman_name`, `chairman_signature`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 3, 1, '2025-07-03', '1988-09-19', NULL, NULL, NULL, 'nominations/l3ycGRC5505BfNQl7kNuUJTEEtp2t8cckPL8FW3r.png', 'nominations/vSkBkcZE6PFH3ATQdQgbZkSEQdpoxcFptrPW6Map.jpg', 'nominations/PDClbU6NZ6kIxoKBDHRcOgOB8ehvffLFx7xQvwQj.jpg', 'nominations/okzO3zGwLIua9yjsND8sZQ4Y83Ujp5H2RyM2y2Cf.png', 'Xandra Henson', 'nominations/EfzsIAB6DrFAHMIa3AWRYO462lWlZQwDTtwjKi7y.png', 'Louis Castaneda', 'nominations/ZC9lNq4EnHIma8PGbTiMfdYXnC1oqpSg9jHIUxyd.jpg', '2025-07-03 10:52:59', '2025-07-03 10:52:59', NULL),
(2, 4, 1, '1979-03-31', NULL, NULL, NULL, NULL, 'nominations/96a89QM8W8OZPxIPdbbZgN2gwuRuoagmx9DwOYGg.pdf', 'nominations/YBrqAsik82ISrtRxeaC9gn1BzHH8RcXHyfE4fWiN.pdf', 'nominations/9P8YaXA5xyHHVpvXcdPCxsUWrzeecn40OvcEBoQv.pdf', 'nominations/kV5BPWC5rInd38rPwHkrPcNLyEUgETKW96SoEav5.pdf', 'Karyn Goodwin', 'nominations/9YrUjihVlmJ6iewkEX67f2f3eDji37K0nnGaqXTR.png', 'Kelly Ratliff', 'nominations/vfAdpYKiPLaM3ca9yAyI3I0WnRo4LKVWewrCMb8L.jpg', '2025-07-04 09:32:55', '2025-07-04 09:32:55', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `otps`
--

DROP TABLE IF EXISTS `otps`;
CREATE TABLE IF NOT EXISTS `otps` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `role` varchar(11) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mob_no` varchar(15) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `msg_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp` int DEFAULT NULL,
  `status` enum('0','1','2') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '0',
  `error_code` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `otp_ex_time` datetime DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `otps`
--

INSERT INTO `otps` (`id`, `role`, `user_id`, `email`, `mob_no`, `msg_id`, `otp`, `status`, `error_code`, `otp_ex_time`, `created_at`, `updated_at`) VALUES
(1, NULL, NULL, 'madhu@gmail.com', '7846871663', NULL, 1234, '1', NULL, '2025-06-13 12:29:02', '2025-06-13 06:54:02', '2025-06-13 06:54:10');

-- --------------------------------------------------------

--
-- Table structure for table `panchayats`
--

DROP TABLE IF EXISTS `panchayats`;
CREATE TABLE IF NOT EXISTS `panchayats` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
CREATE TABLE IF NOT EXISTS `password_reset_tokens` (
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `attempted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `permissions`
--

DROP TABLE IF EXISTS `permissions`;
CREATE TABLE IF NOT EXISTS `permissions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `module_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `permissions_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=MyISAM AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `permissions`
--

INSERT INTO `permissions` (`id`, `module_id`, `name`, `guard_name`, `created_at`, `updated_at`) VALUES
(1, '1', 'society-registration', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(2, '1', 'society-registration-show', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(3, '1', 'society-registration-add', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(4, '1', 'society-registration-edit', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(5, '1', 'society-registration-delete', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(6, '1', 'registration-status', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(7, '1', 'registration-status-show', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(8, '1', 'registration-status-add', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(9, '1', 'registration-status-edit', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(10, '1', 'registration-status-delete', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(11, '1', 'society-member', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(12, '1', 'society-member-show', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(13, '1', 'society-member-add', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(14, '1', 'society-member-edit', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(15, '1', 'society-member-delete', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(16, '1', 'roles', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(17, '1', 'roles-show', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(18, '1', 'roles-add', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(19, '1', 'roles-edit', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41'),
(20, '1', 'roles-delete', 'web', '2025-06-13 12:19:41', '2025-06-13 12:19:41');

-- --------------------------------------------------------

--
-- Table structure for table `roles`
--

DROP TABLE IF EXISTS `roles`;
CREATE TABLE IF NOT EXISTS `roles` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `display_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guard_name` varchar(125) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `roles_name_guard_name_unique` (`name`,`guard_name`)
) ENGINE=MyISAM AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `roles`
--

INSERT INTO `roles` (`id`, `name`, `display_name`, `description`, `guard_name`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'superadmin', 'Super Admin', 'System Admistrator', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(2, 'admin', 'Admin', 'Admin', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(3, 'arcs', 'Assistant Registrar of Cooperative Societies', 'Initial scrutiny and verification, distsrict wise user', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(4, 'ado', 'District Agricultural Development Officer', 'Sectoral verification, block wise user', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(5, 'drcs', 'Deputy Registrar of Cooperative Societies', 'Final approval for Primary and Central, district or division wise user', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(6, 'registrar', 'Registrar of Cooperative Societies', 'Final authority for APEX societies.all over state', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(7, 'society', 'Society', 'society user / applicant', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(8, 'auditor', 'Auditor', 'Audit the Application', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(9, 'ldr', 'Liquidator', 'Liquidator authority', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(10, 'inspector', 'Inspector', 'Inspection authority for inspection module', 'web', '2025-06-13 12:19:40', '2025-06-13 12:19:40', NULL),
(11, 'additionalrcs', 'Additional RCS', 'Additional Registrar of Cooperative Societies', 'web', '2025-07-08 11:13:17', '2025-07-08 11:13:17', NULL),
(12, 'jrcs', 'Joint Registrar of Cooperative Societies', 'Joint Registrar of Cooperative Societies', 'web', '2025-07-08 11:13:17', '2025-07-08 11:13:17', NULL),
(13, 'adco', 'Assistant District Cooperative Officer', 'Assistant District Cooperative Officer', 'web', '2025-07-08 11:13:17', '2025-07-08 11:13:17', NULL),
(14, 'supervisor', 'Block Supervisor', 'Block Supervisor', 'web', '2025-07-08 11:13:17', '2025-07-08 11:13:17', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `role_has_permissions`
--

DROP TABLE IF EXISTS `role_has_permissions`;
CREATE TABLE IF NOT EXISTS `role_has_permissions` (
  `permission_id` bigint UNSIGNED NOT NULL,
  `role_id` bigint UNSIGNED NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `role_has_permissions`
--

INSERT INTO `role_has_permissions` (`permission_id`, `role_id`) VALUES
(1, 1),
(2, 1),
(3, 1),
(4, 1),
(5, 1),
(6, 1),
(7, 1),
(8, 1),
(9, 1),
(10, 1),
(11, 1),
(12, 1),
(13, 1),
(14, 1),
(15, 1),
(16, 1),
(17, 1),
(18, 1),
(19, 1),
(20, 1);

-- --------------------------------------------------------

--
-- Table structure for table `scheme`
--

DROP TABLE IF EXISTS `scheme`;
CREATE TABLE IF NOT EXISTS `scheme` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
CREATE TABLE IF NOT EXISTS `sessions` (
  `id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `payload` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('vR2v4g3qp8eMxxYmnk1S5e9dRbngkERGDcCpbq3r', 3, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiT3k1ekx3dU11Slo0NG1BWWpjS1JTQllzdHlHdVJkeXZGUm1KNHJQSSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NjE6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9pbnNwZWN0aW9uL2luc3BlY3Rpb24tdGFyZ2V0cy9oaXN0b3J5LzEiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aTozO30=', 1751978848),
('F7KdsQhElgsy4VN49gyuQOcUQqPVYM57PAWvpoEa', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiajRKS2tqWUhmOUs3ZlNiR0piQXNGQVBZdDN2YTcwbHlwczN5ektGOCI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo1MDoibG9naW5fd2ViXzU5YmEzNmFkZGMyYjJmOTQwMTU4MGYwMTRjN2Y1OGVhNGUzMDk4OWQiO2k6MTtzOjk6Il9wcmV2aW91cyI7YToxOntzOjM6InVybCI7czo1NToiaHR0cDovLzEyNy4wLjAuMTo4MDAwL2luc3BlY3Rpb24vaW5zcGVjdGlvbi1yZWNvcmQtbGlzdCI7fX0=', 1751982556),
('ewUL9oj2b67pqj922ynGs8e6tN34HppupOZootze', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YTozOntzOjY6Il90b2tlbiI7czo0MDoiWkRZUDMyY2l2ZHV4UFR4NndyNUxHRVV6U2lzeDBoMXJEcHFBcURZUSI7czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHA6Ly9sb2NhbGhvc3Q6ODAwMC9pbnNwZWN0aW9uL2luc3BlY3Rpb24tcmVjb3JkLWxpc3QiO31zOjY6Il9mbGFzaCI7YToyOntzOjM6Im9sZCI7YTowOnt9czozOiJuZXciO2E6MDp7fX19', 1752033760),
('jfuevXX1kETbsTikaJMXUfryluEAB9IQ5HKL5yIS', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YToyOntzOjY6Il90b2tlbiI7czo0MDoic1NJc2lKZTI3ZHpDdjBKSDFsMFJScnRNdVJSWHZ6Qmc5amVjOWx6OSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319fQ==', 1752033821),
('DmdWKOOD99JqJhH7M0lUhfUnB8lwzbZt80jvmNgI', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/137.0.0.0 Safari/537.36', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiRDNMNTY4R21hUWdHN3lHNmJYY1VtR1d1bGdFOHhDb2Q3V0Y1YlBDTSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9pbnNwZWN0aW9uL2luc3BlY3Rpb24tcmVjb3JkLWxpc3QiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=', 1752056965),
('0Z6KGYMcWhYgUcO5ynQP7hCwK6uOd0LS3xu2BdoZ', 1, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36 Edg/138.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiOUp6ak5ieVQxT0NsaEN1Tm83cTZZTnJJNG9mN25YN1Q5RmJsMHMyeiI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJuZXciO2E6MDp7fXM6Mzoib2xkIjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTU6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC9pbnNwZWN0aW9uL2luc3BlY3Rpb24tcmVjb3JkLWxpc3QiO31zOjUwOiJsb2dpbl93ZWJfNTliYTM2YWRkYzJiMmY5NDAxNTgwZjAxNGM3ZjU4ZWE0ZTMwOTg5ZCI7aToxO30=', 1752561874);

-- --------------------------------------------------------

--
-- Table structure for table `settlement_application_details`
--

DROP TABLE IF EXISTS `settlement_application_details`;
CREATE TABLE IF NOT EXISTS `settlement_application_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `applicant_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `father_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile_number` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `full_address` text COLLATE utf8mb4_unicode_ci,
  `submitted_to_role` enum('arcs','ado','adco','drcs','registrar','jrcs','additionalrcs') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_to_user_id` bigint UNSIGNED DEFAULT NULL,
  `current_role` enum('arcs','ado','drcs','adco','registrar','jrcs','additionalrcs') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settlement_application_details_user_id_foreign` (`user_id`),
  KEY `settlement_application_details_submitted_to_user_id_foreign` (`submitted_to_user_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settlement_declaration_details`
--

DROP TABLE IF EXISTS `settlement_declaration_details`;
CREATE TABLE IF NOT EXISTS `settlement_declaration_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `settlement_id` bigint UNSIGNED DEFAULT NULL,
  `is_confirmed` tinyint(1) DEFAULT NULL,
  `Upload_signature` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_individual` tinyint(1) DEFAULT NULL,
  `upload_resolution` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `aadhar_upload` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settlement_declaration_details_settlement_id_foreign` (`settlement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settlement_dispute_details`
--

DROP TABLE IF EXISTS `settlement_dispute_details`;
CREATE TABLE IF NOT EXISTS `settlement_dispute_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `settlement_id` bigint UNSIGNED DEFAULT NULL,
  `against_the_defendant` text COLLATE utf8mb4_unicode_ci,
  `plaintiff_seek_arbitration` text COLLATE utf8mb4_unicode_ci,
  `cause_of_action_arose` text COLLATE utf8mb4_unicode_ci,
  `valuation_case` text COLLATE utf8mb4_unicode_ci,
  `valuation_case_amount` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `desired_relief` text COLLATE utf8mb4_unicode_ci,
  `witnesses_and_documents` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settlement_dispute_details_settlement_id_foreign` (`settlement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settlement_evidence_details`
--

DROP TABLE IF EXISTS `settlement_evidence_details`;
CREATE TABLE IF NOT EXISTS `settlement_evidence_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `settlement_id` bigint UNSIGNED DEFAULT NULL,
  `amount_paid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `challan_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_challan_reciept` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_documentary_evidence` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_witness` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `upload_any_other_supporting` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settlement_evidence_details_settlement_id_foreign` (`settlement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `settlement_parties_involved_details`
--

DROP TABLE IF EXISTS `settlement_parties_involved_details`;
CREATE TABLE IF NOT EXISTS `settlement_parties_involved_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `settlement_id` bigint UNSIGNED DEFAULT NULL,
  `name1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address1` text COLLATE utf8mb4_unicode_ci,
  `name2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address2` text COLLATE utf8mb4_unicode_ci,
  `name3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address3` text COLLATE utf8mb4_unicode_ci,
  `dname1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `daddress1` text COLLATE utf8mb4_unicode_ci,
  `dname2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `daddress2` text COLLATE utf8mb4_unicode_ci,
  `dname3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `daddress3` text COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `settlement_parties_involved_details_settlement_id_foreign` (`settlement_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `signature_details`
--

DROP TABLE IF EXISTS `signature_details`;
CREATE TABLE IF NOT EXISTS `signature_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` int NOT NULL,
  `authority_signature` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `authority_designation` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `authority_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `society_application_flows`
--

DROP TABLE IF EXISTS `society_application_flows`;
CREATE TABLE IF NOT EXISTS `society_application_flows` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `application_id` bigint UNSIGNED NOT NULL,
  `from_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `from_user_id` bigint UNSIGNED DEFAULT NULL,
  `to_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `to_user_id` bigint UNSIGNED DEFAULT NULL,
  `direction` enum('forward','reverse') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'forward',
  `action` enum('send','approve','reject','revert','verification','recheck') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `attachments` json DEFAULT NULL,
  `is_action_taken` tinyint(1) NOT NULL DEFAULT '1',
  `acted_by` bigint UNSIGNED NOT NULL COMMENT 'action can only taken by',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `society_application_flows_acted_by_foreign` (`acted_by`),
  KEY `society_application_flows_to_user_id_foreign` (`to_user_id`),
  KEY `society_application_flows_from_user_id_foreign` (`from_user_id`),
  KEY `society_application_flows_application_id_foreign` (`application_id`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `society_application_flows`
--

INSERT INTO `society_application_flows` (`id`, `application_id`, `from_role`, `from_user_id`, `to_role`, `to_user_id`, `direction`, `action`, `remarks`, `attachments`, `is_action_taken`, `acted_by`, `created_at`, `updated_at`) VALUES
(1, 7, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'demo test flow1', '\"[\\\"official_attachments\\\\/MR1e9MVEIFO6lcbW0V8uNPtIP1U3OlxcgppUekmT.pdf\\\"]\"', 1, 1, '2025-06-17 05:13:59', '2025-06-17 05:13:59'),
(2, 7, 'ado', 2, 'drcs', 3, 'forward', 'verification', 'testdemo 2', '\"[\\\"official_attachments\\\\/6J4yRnQpZq0WIt8OZQ84wcVeHA3OOmBs6M3Ei9mi.pdf\\\"]\"', 1, 2, '2025-06-17 05:16:30', '2025-06-17 05:16:30'),
(3, 6, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'rfesfefe', '\"[\\\"official_attachments\\\\/Ys706E4JTK1qMDHs9gJR8hhXCpOiP1woi0Pv9L0u.pdf\\\"]\"', 1, 1, '2025-06-17 05:51:57', '2025-06-17 05:51:57'),
(4, 6, 'ado', 2, 'society', 8, 'reverse', 'reject', 'wwqww', '\"[\\\"official_attachments\\\\/yeqohJIKptmSvEjOzDq6WLVlkfUz4x9Qmz8OeTX9.pdf\\\"]\"', 1, 2, '2025-06-17 05:53:12', '2025-06-17 05:53:12'),
(5, 7, 'drcs', 3, NULL, NULL, 'forward', 'approve', 'wesfew', '\"[\\\"official_attachments\\\\/rWv0YKbFUbS5QRS6lRCoK9vswLMrliAaCWM4sYDO.pdf\\\"]\"', 1, 3, '2025-06-17 05:55:53', '2025-06-17 05:55:53'),
(6, 8, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'mnbnlll', '\"[\\\"official_attachments\\\\/qdChnw8fYs9hCeVtuuIFWzECmR2iWlS7gWoHekdb.pdf\\\"]\"', 1, 1, '2025-06-26 09:05:31', '2025-06-26 09:05:31'),
(7, 9, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'xzzxxzxz', '\"[\\\"official_attachments\\\\/nJ5E8HZXiZpfk0fTGhfu79otgJfeX3fYr3WTSFCm.pdf\\\"]\"', 1, 1, '2025-06-26 12:11:52', '2025-06-26 12:11:52'),
(8, 9, 'ado', 2, 'society', NULL, 'reverse', 'revert', 'Inspection completed. Reverting to ARCS for next action.', '\"[]\"', 1, 2, '2025-06-26 13:09:42', '2025-06-26 13:09:42'),
(9, 10, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'send to ado', '\"[\\\"official_attachments\\\\/K52O1rfQsKgWZX9KH3Jcx179z2SatY1kKb3pYmPR.pdf\\\"]\"', 1, 1, '2025-06-30 05:18:08', '2025-06-30 05:18:08'),
(10, 10, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-06-30 05:53:54', '2025-06-30 05:53:54'),
(11, 10, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'GO TO drcs', '\"[\\\"official_attachments\\\\/ZIXBV4HZNCdbHAvYmm7aja2RYSjxhlN67WpQRN7b.pdf\\\"]\"', 1, 1, '2025-06-30 05:55:30', '2025-06-30 05:55:30'),
(12, 8, 'drcs', 3, NULL, NULL, 'forward', 'approve', 'hghgjhjh', '\"[\\\"official_attachments\\\\/KmPg1A5a5Goyp9EdYKfv0tuh6ZB7zDrHC1uHhpj0.pdf\\\"]\"', 1, 3, '2025-06-30 05:57:51', '2025-06-30 05:57:51'),
(13, 10, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'go to drcs', '\"[\\\"official_attachments\\\\/4z8YzjLCpHDozj2kWMBSRvFuL2KmVurR3daYj400.pdf\\\"]\"', 1, 2, '2025-06-30 06:07:50', '2025-06-30 06:07:50'),
(14, 10, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'sdsdw', '\"[\\\"official_attachments\\\\/zn32NeFmytdEnEiyUilGSz8CjoDEF2sxHGBoUmsG.pdf\\\"]\"', 1, 1, '2025-06-30 06:31:44', '2025-06-30 06:31:44'),
(15, 10, 'ado', 2, '1', NULL, 'forward', 'verification', 'sdsdfsd', '\"[\\\"official_attachments\\\\/0rFrDS3MJbuOm32nkGRp0GNJRCIjaUR3DZakyx47.pdf\\\"]\"', 1, 2, '2025-06-30 06:33:50', '2025-06-30 06:33:50'),
(16, 11, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'bggydfgtys', '\"[\\\"official_attachments\\\\/tPFt1PjxJVvahJObI3fnz9S3wAfV3n1OoRlT27bn.pdf\\\"]\"', 1, 1, '2025-06-30 07:04:14', '2025-06-30 07:04:14'),
(17, 11, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-06-30 07:07:01', '2025-06-30 07:07:01'),
(18, 11, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'sdsdsadwdwwwqqqqqqqqqqqqqqqqq', '\"[\\\"official_attachments\\\\/oqNYDedITqXztFrRyMsKBgWfBUwSc0kLsm0NtB3I.pdf\\\"]\"', 1, 1, '2025-06-30 07:07:56', '2025-06-30 07:07:56'),
(19, 11, 'drcs', 3, NULL, NULL, 'forward', 'approve', 'sdsad', '\"[\\\"official_attachments\\\\/OErO2OeMyHkjo8V7jm6rviEJ9inTc0CUH2eRiaD4.pdf\\\"]\"', 1, 3, '2025-06-30 07:22:14', '2025-06-30 07:22:14'),
(20, 10, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'cvbcbv', '\"[\\\"official_attachments\\\\/d0U02HaB4ef4SkeZDfzcNhhR30TTiTMJlbnJwi9Z.pdf\\\"]\"', 1, 1, '2025-06-30 09:20:28', '2025-06-30 09:20:28'),
(21, 9, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'saasassad', '\"[\\\"official_attachments\\\\/Y7fk3q3EfbkLsmIC3gwz004LSkUeOMUYSFqP5eCV.pdf\\\"]\"', 1, 1, '2025-06-30 09:20:55', '2025-06-30 09:20:55'),
(22, 10, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'jjhjhjh', '\"[\\\"official_attachments\\\\/VLG3UvOiJ5w4DfdNr3Y5K5H3c0crkRMhj9ecssAs.pdf\\\"]\"', 1, 2, '2025-06-30 09:21:57', '2025-06-30 09:21:57'),
(23, 9, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'hvhghg', '\"[\\\"official_attachments\\\\/KVRsLaaMg57MEaeblXiJD0BeK2roqzJ1dgpCpzd4.docx\\\"]\"', 1, 2, '2025-06-30 09:22:17', '2025-06-30 09:22:17'),
(24, 9, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'bvhvhghggggggggggggggggggggggg', '\"[\\\"official_attachments\\\\/vVqtj6Q6nRJc5ol9ugtw0QC3aQ9u5sJoqf6bvPZe.pdf\\\"]\"', 1, 1, '2025-06-30 09:23:28', '2025-06-30 09:23:28'),
(25, 9, 'drcs', 3, 'registrar', 4, 'forward', 'verification', 'ryyryyryyy', '\"[\\\"official_attachments\\\\/ZcR4kRbz1lE3r4iinRSTguTmywjcFRtRmpfyPatK.pdf\\\"]\"', 1, 3, '2025-06-30 09:24:25', '2025-06-30 09:24:25'),
(26, 9, 'registrar', 4, NULL, NULL, 'forward', 'approve', 'zxzzxzxzX', '\"[\\\"official_attachments\\\\/LUnjk6JEjnZL9mEeDm25YxGzi1qq64V4U7F45B2p.pdf\\\"]\"', 1, 4, '2025-06-30 10:26:51', '2025-06-30 10:26:51'),
(27, 12, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'step1', '\"[\\\"official_attachments\\\\/BcgS01UjXKUd4Jm0oe69HPWix2jdtnGM7j2Htmw5.docx\\\"]\"', 1, 1, '2025-06-30 11:01:35', '2025-06-30 11:01:35'),
(28, 12, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-06-30 11:04:10', '2025-06-30 11:04:10'),
(29, 12, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'step 2', '\"[\\\"official_attachments\\\\/FmB6FfZJ8mRTD6pl2U4pUlYjZIwofJD7FZzESXri.pdf\\\"]\"', 1, 1, '2025-06-30 11:05:30', '2025-06-30 11:05:30'),
(30, 12, 'drcs', 3, NULL, NULL, 'forward', 'approve', 'sdfsdfsd', '\"[\\\"official_attachments\\\\/UAzmUqkp6ktMuCZG9RHdUkecPxCwwkFPf7j1L8xd.pdf\\\"]\"', 1, 3, '2025-06-30 11:06:05', '2025-06-30 11:06:05'),
(31, 13, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'zsdsadsxasasaaaaaaaaaaaaaaa', '\"[\\\"official_attachments\\\\/EZQ6W0BPUDcw1H18dWfeehLJKvRln6hGcIlZbrKo.pdf\\\"]\"', 1, 1, '2025-06-30 12:32:18', '2025-06-30 12:32:18'),
(32, 13, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-06-30 12:37:54', '2025-06-30 12:37:54'),
(33, 13, 'arcs', 1, 'society', NULL, 'reverse', 'revert', 'revertgfgfggggggggg', '\"[\\\"official_attachments\\\\/zep47tjKyybu1J0YGaR6U8HxCQCogIq0BTzEaqSW.pdf\\\"]\"', 1, 1, '2025-06-30 12:39:59', '2025-06-30 12:39:59'),
(34, 13, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'trtrty', '\"[\\\"official_attachments\\\\/DQxWkm9thDLmxOYfoBOaQEQ2D4GeTCnfieFQmH26.pdf\\\"]\"', 1, 1, '2025-06-30 12:42:33', '2025-06-30 12:42:33'),
(35, 13, 'drcs', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-06-30 12:44:33', '2025-06-30 12:44:33'),
(36, 13, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'mn nbnn', '\"[\\\"official_attachments\\\\/gnTwdfteHLPNwFfVcSyjjOpmRyIpnRPhujbC8qsV.pdf\\\"]\"', 1, 1, '2025-06-30 12:45:29', '2025-06-30 12:45:29'),
(37, 13, 'drcs', 3, 'registrar', 4, 'forward', 'verification', 'hgvgvg', '\"[\\\"official_attachments\\\\/uZINas9NEojizN5AoNYXIvBTKGiYFFNBgNjOnvtg.pdf\\\"]\"', 1, 3, '2025-06-30 12:46:07', '2025-06-30 12:46:07'),
(38, 13, 'registrar', 4, 'society', 8, 'reverse', 'reject', 'saaaaaaa', '\"[\\\"official_attachments\\\\/74QEpaIl66i0TJJQ3KD0iLS8lhvxRIBKDKYgG6Vo.pdf\\\"]\"', 1, 4, '2025-06-30 12:48:09', '2025-06-30 12:48:09'),
(39, 14, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'nnnnnnnnnnnnnnn', '\"[\\\"official_attachments\\\\/tne7VnjMfVD2jl6PSpTXNZi65hDbQd1YVw0JY3cf.pdf\\\"]\"', 1, 1, '2025-06-30 13:39:18', '2025-06-30 13:39:18'),
(40, 14, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-07-01 04:51:43', '2025-07-01 04:51:43'),
(41, 14, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'sending to drcs', '\"[\\\"official_attachments\\\\/s989yaizJ26YXQW5Q4l9uBXE6xUZRowqSi7XMuPt.pdf\\\"]\"', 1, 1, '2025-07-01 04:52:26', '2025-07-01 04:52:26'),
(42, 14, 'drcs', 3, 'society', NULL, 'reverse', 'revert', 'jhhghhhhhhhhhhhhh', '\"[\\\"official_attachments\\\\/DQWEkeezFrKNg334moiY5X3BeDx5c6fay9ePylqM.pdf\\\"]\"', 1, 3, '2025-07-01 04:53:43', '2025-07-01 04:53:43'),
(43, 15, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'dssssssssssss', '\"[\\\"official_attachments\\\\/eHVlwWxbLtXuIIIUzBcDMp0uaVl9G5tiG0z6bVRu.pdf\\\"]\"', 1, 1, '2025-07-01 06:36:48', '2025-07-01 06:36:48'),
(44, 15, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-07-01 07:39:30', '2025-07-01 07:39:30'),
(45, 16, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'step1333', '\"[\\\"official_attachments\\\\/VBTp2WbEDZseMI1Uj8csXx6TcitICm05ZveVCiRy.pdf\\\"]\"', 1, 1, '2025-07-01 09:03:07', '2025-07-01 09:03:07'),
(46, 17, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'stp09', '\"[\\\"official_attachments\\\\/GYLezq1smdnSRv0UR46el3tZadKYEP0wjskXl8A7.docx\\\"]\"', 1, 1, '2025-07-01 10:03:36', '2025-07-01 10:03:36'),
(47, 17, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-07-01 10:13:07', '2025-07-01 10:13:07'),
(48, 16, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-07-01 10:13:26', '2025-07-01 10:13:26'),
(49, 16, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'step09', '\"[\\\"official_attachments\\\\/FcjEM9e0s8IPcL24uor9ZIaOLthRD16qYaSptzxQ.docx\\\"]\"', 1, 1, '2025-07-01 10:14:13', '2025-07-01 10:14:13'),
(50, 17, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'step09', '\"[\\\"official_attachments\\\\/2CCS2OKGsgX1f7YHp2Lug7p2nspuDd5Xel4t11vC.docx\\\"]\"', 1, 1, '2025-07-01 10:14:28', '2025-07-01 10:14:28'),
(51, 16, 'drcs', 3, 'registrar', 4, 'forward', 'verification', 'aaaaaaaaaaaaaa', '\"[\\\"official_attachments\\\\/xScubUqxBxUDb6PTSexmEJfp2DCpi9BtvnUnRSeM.docx\\\"]\"', 1, 3, '2025-07-01 10:15:27', '2025-07-01 10:15:27'),
(52, 17, 'drcs', 3, NULL, NULL, 'forward', 'approve', 'AAAAAAAAAAAAAAAA', '\"[\\\"official_attachments\\\\/Cu0PI1Sl9QbioSLQDm0ZZoP20DMxworiZcaRAwtC.docx\\\"]\"', 1, 3, '2025-07-01 10:15:40', '2025-07-01 10:15:40'),
(53, 16, 'registrar', 4, NULL, NULL, 'forward', 'approve', 'YOOOOO', '\"[\\\"official_attachments\\\\/ssleSPglNgRqEZdNeiqsfMv5q9lxlDSdb6YAKVMv.docx\\\"]\"', 1, 4, '2025-07-01 10:17:38', '2025-07-01 10:17:38'),
(54, 18, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'ssssssssss', '\"[\\\"official_attachments\\\\/Rw2wjdRLqSqW1WCu2eHmGG3A8VWhnSMYTYSDQ3Uh.docx\\\"]\"', 1, 1, '2025-07-01 10:34:06', '2025-07-01 10:34:06'),
(55, 19, 'arcs', 1, 'society', NULL, 'reverse', 'revert', 'nnnnnnnnnnnnn', '\"[\\\"official_attachments\\\\/T7lfyeAxN88W1kSO0bp0IKqWtjpSZFA07oFuVRCT.pdf\\\"]\"', 1, 1, '2025-07-01 13:22:13', '2025-07-01 13:22:13'),
(56, 23, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'mmmmmmmmmmmmmmmmmmm', '\"[\\\"official_attachments\\\\/H6avJXkIQ9lWEHHbrVySlkpW5qiRnjheHkmcOu1l.docx\\\"]\"', 1, 1, '2025-07-02 10:52:05', '2025-07-02 10:52:05'),
(57, 23, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-07-02 10:54:30', '2025-07-02 10:54:30'),
(58, 23, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'ooooooooooooppppppp', '\"[\\\"official_attachments\\\\/1TTF6PFxJos30oGmKZOirCztONE2ZcHGc5QFGZsR.pdf\\\"]\"', 1, 1, '2025-07-02 10:58:52', '2025-07-02 10:58:52'),
(59, 23, 'drcs', 3, 'arcs', 1, 'reverse', 'recheck', 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '\"[\\\"official_attachments\\\\/CE5Bg4mrb3g6DnUuyxCsE5QV8B5v6LFTuNTXTgVu.pdf\\\"]\"', 1, 3, '2025-07-02 11:01:24', '2025-07-02 11:01:24'),
(60, 23, 'arcs', 3, NULL, NULL, 'reverse', 'recheck', 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '\"[\\\"official_attachments\\\\/9rUgGArQN4z55rpQwozivx7jUmFFOCtcMKVAnWQs.pdf\\\"]\"', 1, 3, '2025-07-02 11:04:43', '2025-07-02 11:04:43'),
(61, 28, 'arcs', 1, 'society', 8, 'reverse', 'reject', 'bhhfgg', '\"[\\\"official_attachments\\\\/FYsbYUivUlp0zJDDm8eZdyjIny9ZI069ViaUA77M.pdf\\\"]\"', 1, 1, '2025-07-04 07:08:20', '2025-07-04 07:08:20'),
(62, 21, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'xfdfdffff', '\"[\\\"official_attachments\\\\/0xR8TmYFuX27fiGk6fvBu1N0BWmrASEN8YgfRXnq.pdf\\\"]\"', 1, 1, '2025-07-04 07:28:24', '2025-07-04 07:28:24'),
(63, 14, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'sdfsf', '\"[\\\"official_attachments\\\\/AxVQRj0ypYzfx0mlUyG7KUyauB6LGqjonteGgOUa.pdf\\\"]\"', 1, 1, '2025-07-04 07:35:31', '2025-07-04 07:35:31'),
(64, 15, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'dfghjkl;', '\"[\\\"official_attachments\\\\/Wlxc1od9mpJIk6mDQ9mrttRAjTkmmZwXMiD11gkw.pdf\\\"]\"', 1, 1, '2025-07-04 07:52:42', '2025-07-04 07:52:42'),
(65, 18, 'ado', 2, 'arcs', 1, 'forward', 'verification', 'Inspection completed. Forwarding to ARCS.', '\"[]\"', 1, 2, '2025-07-04 08:44:51', '2025-07-04 08:44:51'),
(66, 18, 'arcs', 1, 'society', 8, 'reverse', 'reject', 'Voluptas ea lorem si', '\"[\\\"official_attachments\\\\/tT3u2WwVn7o68Oos8D9xMUGJUrQVIojF8rS6eIvK.pdf\\\"]\"', 1, 1, '2025-07-04 09:06:55', '2025-07-04 09:06:55'),
(67, 10, 'arcs', 1, 'drcs', 3, 'forward', 'verification', 'ssssssssssssssssss', '\"[\\\"official_attachments\\\\/dj3yA1XJeh6Gt2PtoklgpwdSg8qiDpitHxOEqlpD.pdf\\\"]\"', 1, 1, '2025-07-04 09:17:17', '2025-07-04 09:17:17'),
(68, 1, 'arcs', 1, 'ado', 2, 'forward', 'verification', 'Nulla reiciendis Nam', '\"[\\\"official_attachments\\\\/scnITKdZL5gxFU3u3YTTsOrUNhvScUXcvtDndBh0.pdf\\\"]\"', 1, 1, '2025-07-04 09:17:55', '2025-07-04 09:17:55');

-- --------------------------------------------------------

--
-- Table structure for table `society_application_status_logs`
--

DROP TABLE IF EXISTS `society_application_status_logs`;
CREATE TABLE IF NOT EXISTS `society_application_status_logs` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `application_id` bigint UNSIGNED DEFAULT NULL,
  `action_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `old_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `new_value` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_role` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `performed_by_user` bigint UNSIGNED DEFAULT NULL,
  `remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `society_application_status_logs_application_id_foreign` (`application_id`),
  KEY `society_application_status_logs_performed_by_user_foreign` (`performed_by_user`)
) ENGINE=MyISAM AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `society_application_status_logs`
--

INSERT INTO `society_application_status_logs` (`id`, `application_id`, `action_type`, `old_value`, `new_value`, `performed_by_role`, `performed_by_user`, `remarks`, `created_at`, `updated_at`) VALUES
(1, 7, 'approve', '0', '1', 'ado', 1, 'demo test flow1', '2025-06-17 05:13:59', '2025-06-17 05:13:59'),
(2, 7, 'approve', '0', '1', 'drcs', 2, 'testdemo 2', '2025-06-17 05:16:30', '2025-06-17 05:16:30'),
(3, 6, 'approve', '0', '1', 'ado', 1, 'rfesfefe', '2025-06-17 05:51:57', '2025-06-17 05:51:57'),
(4, 6, 'reject', '1', '5', NULL, 2, 'wwqww', '2025-06-17 05:53:12', '2025-06-17 05:53:12'),
(5, 7, 'approve', '0', '2', NULL, 3, 'wesfew', '2025-06-17 05:55:53', '2025-06-17 05:55:53'),
(6, 8, 'approve', '1', '1', 'drcs', 1, 'mnbnlll', '2025-06-26 09:05:31', '2025-06-26 09:05:31'),
(7, 9, 'approve', '1', '1', 'ado', 1, 'xzzxxzxz', '2025-06-26 12:11:52', '2025-06-26 12:11:52'),
(8, 9, 'revert', '1', '3', NULL, 2, 'Inspection completed. Reverting to ARCS for next action.', '2025-06-26 13:09:42', '2025-06-26 13:09:42'),
(9, 10, 'approve', '1', '1', 'ado', 1, 'send to ado', '2025-06-30 05:18:08', '2025-06-30 05:18:08'),
(10, 10, 'approve', '0', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-06-30 05:53:54', '2025-06-30 05:53:54'),
(11, 10, 'approve', '0', '1', 'ado', 1, 'GO TO drcs', '2025-06-30 05:55:30', '2025-06-30 05:55:30'),
(12, 8, 'approve', '0', '2', NULL, 3, 'hghgjhjh', '2025-06-30 05:57:51', '2025-06-30 05:57:51'),
(13, 10, 'approve', '0', '1', 'arcs', 2, 'go to drcs', '2025-06-30 06:07:50', '2025-06-30 06:07:50'),
(14, 10, 'approve', '0', '1', 'ado', 1, 'sdsdw', '2025-06-30 06:31:44', '2025-06-30 06:31:44'),
(15, 10, 'approve', '0', '1', '1', 2, 'sdsdfsd', '2025-06-30 06:33:50', '2025-06-30 06:33:50'),
(16, 11, 'approve', '1', '1', 'ado', 1, 'bggydfgtys', '2025-06-30 07:04:14', '2025-06-30 07:04:14'),
(17, 11, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-06-30 07:07:01', '2025-06-30 07:07:01'),
(18, 11, 'approve', '1', '1', 'drcs', 1, 'sdsdsadwdwwwqqqqqqqqqqqqqqqqq', '2025-06-30 07:07:56', '2025-06-30 07:07:56'),
(19, 11, 'approve', '1', '2', NULL, 3, 'sdsad', '2025-06-30 07:22:14', '2025-06-30 07:22:14'),
(20, 10, 'approve', '1', '1', 'ado', 1, 'cvbcbv', '2025-06-30 09:20:28', '2025-06-30 09:20:28'),
(21, 9, 'approve', '1', '1', 'ado', 1, 'saasassad', '2025-06-30 09:20:55', '2025-06-30 09:20:55'),
(22, 10, 'doc_verified', '1', '1', 'arcs', 2, 'jjhjhjh', '2025-06-30 09:21:57', '2025-06-30 09:21:57'),
(23, 9, 'doc_verified', '1', '1', 'arcs', 2, 'hvhghg', '2025-06-30 09:22:17', '2025-06-30 09:22:17'),
(24, 9, 'approve', '1', '1', 'drcs', 1, 'bvhvhghggggggggggggggggggggggg', '2025-06-30 09:23:28', '2025-06-30 09:23:28'),
(25, 9, 'approve', '1', '1', 'registrar', 3, 'ryyryyryyy', '2025-06-30 09:24:25', '2025-06-30 09:24:25'),
(26, 9, 'approve', '1', '2', NULL, 4, 'zxzzxzxzX', '2025-06-30 10:26:51', '2025-06-30 10:26:51'),
(27, 12, 'approve', '1', '1', 'ado', 1, 'step1', '2025-06-30 11:01:35', '2025-06-30 11:01:35'),
(28, 12, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-06-30 11:04:10', '2025-06-30 11:04:10'),
(29, 12, 'approve', '1', '1', 'drcs', 1, 'step 2', '2025-06-30 11:05:30', '2025-06-30 11:05:30'),
(30, 12, 'approve', '1', '2', NULL, 3, 'sdfsdfsd', '2025-06-30 11:06:05', '2025-06-30 11:06:05'),
(31, 13, 'approve', '1', '1', 'ado', 1, 'zsdsadsxasasaaaaaaaaaaaaaaa', '2025-06-30 12:32:18', '2025-06-30 12:32:18'),
(32, 13, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-06-30 12:37:54', '2025-06-30 12:37:54'),
(33, 13, 'revert', '1', '3', NULL, 1, 'revertgfgfggggggggg', '2025-06-30 12:39:59', '2025-06-30 12:39:59'),
(34, 13, 'approve', '1', '1', 'drcs', 1, 'trtrty', '2025-06-30 12:42:33', '2025-06-30 12:42:33'),
(35, 13, 'approve', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-06-30 12:44:33', '2025-06-30 12:44:33'),
(36, 13, 'approve', '1', '1', 'drcs', 1, 'mn nbnn', '2025-06-30 12:45:29', '2025-06-30 12:45:29'),
(37, 13, 'approve', '1', '1', 'registrar', 3, 'hgvgvg', '2025-06-30 12:46:07', '2025-06-30 12:46:07'),
(38, 13, 'reject', '1', '5', NULL, 4, 'saaaaaaa', '2025-06-30 12:48:09', '2025-06-30 12:48:09'),
(39, 14, 'approve', '1', '1', 'ado', 1, 'nnnnnnnnnnnnnnn', '2025-06-30 13:39:18', '2025-06-30 13:39:18'),
(40, 14, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-07-01 04:51:43', '2025-07-01 04:51:43'),
(41, 14, 'approve', '1', '1', 'drcs', 1, 'sending to drcs', '2025-07-01 04:52:26', '2025-07-01 04:52:26'),
(42, 14, 'revert', '1', '3', NULL, 3, 'jhhghhhhhhhhhhhhh', '2025-07-01 04:53:43', '2025-07-01 04:53:43'),
(43, 15, 'approve', '1', '1', 'ado', 1, 'dssssssssssss', '2025-07-01 06:36:48', '2025-07-01 06:36:48'),
(44, 15, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-07-01 07:39:30', '2025-07-01 07:39:30'),
(45, 16, 'approve', '1', '1', 'ado', 1, 'step1333', '2025-07-01 09:03:07', '2025-07-01 09:03:07'),
(46, 17, 'approve', '1', '1', 'ado', 1, 'stp09', '2025-07-01 10:03:36', '2025-07-01 10:03:36'),
(47, 17, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-07-01 10:13:07', '2025-07-01 10:13:07'),
(48, 16, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-07-01 10:13:26', '2025-07-01 10:13:26'),
(49, 16, 'approve', '1', '1', 'drcs', 1, 'step09', '2025-07-01 10:14:13', '2025-07-01 10:14:13'),
(50, 17, 'approve', '1', '1', 'drcs', 1, 'step09', '2025-07-01 10:14:28', '2025-07-01 10:14:28'),
(51, 16, 'approve', '1', '1', 'registrar', 3, 'aaaaaaaaaaaaaa', '2025-07-01 10:15:27', '2025-07-01 10:15:27'),
(52, 17, 'approve', '1', '2', NULL, 3, 'AAAAAAAAAAAAAAAA', '2025-07-01 10:15:40', '2025-07-01 10:15:40'),
(53, 16, 'approve', '1', '2', NULL, 4, 'YOOOOO', '2025-07-01 10:17:38', '2025-07-01 10:17:38'),
(54, 18, 'approve', '1', '1', 'ado', 1, 'ssssssssss', '2025-07-01 10:34:06', '2025-07-01 10:34:06'),
(55, 19, 'revert', '1', '3', NULL, 1, 'nnnnnnnnnnnnn', '2025-07-01 13:22:13', '2025-07-01 13:22:13'),
(56, 23, 'approve', '1', '1', 'ado', 1, 'mmmmmmmmmmmmmmmmmmm', '2025-07-02 10:52:05', '2025-07-02 10:52:05'),
(57, 23, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-07-02 10:54:30', '2025-07-02 10:54:30'),
(58, 23, 'approve', '1', '1', 'drcs', 1, 'ooooooooooooppppppp', '2025-07-02 10:58:52', '2025-07-02 10:58:52'),
(59, 23, 'approve', '1', '4', 'arcs', 3, 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '2025-07-02 11:01:24', '2025-07-02 11:01:24'),
(60, 23, 'approve', '4', '4', NULL, 3, 'ssssssssssssssssssssssssssssssssssssssssssssssssssssssss', '2025-07-02 11:04:43', '2025-07-02 11:04:43'),
(61, 28, 'reject', '1', '5', NULL, 1, 'bhhfgg', '2025-07-04 07:08:20', '2025-07-04 07:08:20'),
(62, 21, 'approve', '1', '1', 'ado', 1, 'xfdfdffff', '2025-07-04 07:28:24', '2025-07-04 07:28:24'),
(63, 14, 'approve', '1', '1', 'drcs', 1, 'sdfsf', '2025-07-04 07:35:31', '2025-07-04 07:35:31'),
(64, 15, 'approve', '1', '1', 'drcs', 1, 'dfghjkl;', '2025-07-04 07:52:42', '2025-07-04 07:52:42'),
(65, 18, 'doc_verified', '1', '1', 'arcs', 2, 'Inspection completed. Forwarding to ARCS.', '2025-07-04 08:44:51', '2025-07-04 08:44:51'),
(66, 18, 'reject', '1', '5', NULL, 1, 'Voluptas ea lorem si', '2025-07-04 09:06:55', '2025-07-04 09:06:55'),
(67, 10, 'approve', '1', '1', 'drcs', 1, 'ssssssssssssssssss', '2025-07-04 09:17:17', '2025-07-04 09:17:17'),
(68, 1, 'approve', '1', '1', 'ado', 1, 'Nulla reiciendis Nam', '2025-07-04 09:17:55', '2025-07-04 09:17:55');

-- --------------------------------------------------------

--
-- Table structure for table `society_app_details`
--

DROP TABLE IF EXISTS `society_app_details`;
CREATE TABLE IF NOT EXISTS `society_app_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `app_id` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `app_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` bigint UNSIGNED DEFAULT NULL,
  `division_id` bigint UNSIGNED DEFAULT NULL,
  `district_id` bigint UNSIGNED DEFAULT NULL,
  `block_id` bigint UNSIGNED DEFAULT NULL,
  `submitted_to_role` enum('arcs','ado','drcs','registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `submitted_to_user_id` bigint UNSIGNED DEFAULT NULL,
  `app_count` int NOT NULL,
  `app_phase` int NOT NULL,
  `scheme_id` int NOT NULL,
  `status` int NOT NULL COMMENT '1-pending,2-Reverted,3-Approved by admin,4-Approved by JRCS',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `app_progress` double DEFAULT NULL,
  `cutoff_date` date DEFAULT NULL,
  `current_role` enum('arcs','ado','drcs','registrar') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `documents_verified` tinyint(1) NOT NULL DEFAULT '0',
  `documents_verified_by` bigint UNSIGNED DEFAULT NULL,
  `documents_verified_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `society_app_details_user_id_foreign` (`user_id`),
  KEY `society_app_details_division_id_foreign` (`division_id`),
  KEY `society_app_details_district_id_foreign` (`district_id`),
  KEY `society_app_details_block_id_foreign` (`block_id`),
  KEY `society_app_details_submitted_to_user_id_foreign` (`submitted_to_user_id`),
  KEY `society_app_details_documents_verified_by_foreign` (`documents_verified_by`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `society_app_details`
--

INSERT INTO `society_app_details` (`id`, `app_id`, `app_no`, `user_id`, `division_id`, `district_id`, `block_id`, `submitted_to_role`, `submitted_to_user_id`, `app_count`, `app_phase`, `scheme_id`, `status`, `created_at`, `updated_at`, `app_progress`, `cutoff_date`, `current_role`, `documents_verified`, `documents_verified_by`, `documents_verified_at`) VALUES
(1, '1', 'APP#1', 8, NULL, 13, 92, 'ado', 2, 1, 1, 1, 1, '2025-06-13 06:59:56', '2025-07-04 09:17:55', NULL, '2025-09-11', 'ado', 0, NULL, NULL),
(2, '2', 'APP#2', 8, NULL, 13, 92, NULL, NULL, 2, 1, 1, 0, '2025-06-13 09:03:04', '2025-06-13 09:03:04', NULL, NULL, NULL, 0, NULL, NULL),
(3, '3', 'APP#3', 8, NULL, 13, 92, NULL, NULL, 3, 1, 1, 0, '2025-06-13 09:07:00', '2025-06-13 09:07:00', NULL, NULL, NULL, 0, NULL, NULL),
(4, '4', 'APP#4', 8, NULL, 10, 75, 'arcs', NULL, 4, 1, 1, 1, '2025-06-13 09:19:17', '2025-06-30 08:46:03', NULL, '2025-09-28', 'arcs', 0, NULL, NULL),
(5, '5', 'APP#5', 8, NULL, 10, 80, NULL, NULL, 5, 1, 1, 0, '2025-06-13 09:35:47', '2025-06-13 09:35:47', NULL, NULL, NULL, 0, NULL, NULL),
(6, '6', 'APP#6', 8, NULL, 13, 92, 'ado', NULL, 6, 1, 1, 5, '2025-06-13 09:39:46', '2025-06-17 05:53:12', NULL, '2025-09-15', NULL, 0, NULL, NULL),
(7, '7', 'APP#7', 8, NULL, 13, 92, NULL, NULL, 7, 1, 1, 2, '2025-06-13 09:42:33', '2025-06-17 05:55:53', NULL, '2025-09-15', NULL, 0, NULL, NULL),
(8, '8', 'APP#8', 8, NULL, 13, 92, NULL, NULL, 8, 1, 1, 2, '2025-06-26 08:50:17', '2025-06-30 05:57:51', NULL, '2025-09-24', NULL, 0, NULL, NULL),
(9, '9', 'APP#9', 8, NULL, 13, 92, NULL, NULL, 9, 1, 1, 2, '2025-06-26 10:30:28', '2025-06-30 10:26:51', NULL, '2025-09-28', NULL, 1, 2, '2025-06-30 09:22:17'),
(10, '10', 'APP#10', 8, NULL, 13, 92, 'drcs', 3, 10, 1, 1, 1, '2025-06-30 05:06:21', '2025-07-04 09:17:17', NULL, '2025-09-28', 'drcs', 1, 2, '2025-06-30 09:21:57'),
(11, '11', 'APP#11', 8, NULL, 13, 92, NULL, NULL, 11, 1, 1, 2, '2025-06-30 06:55:28', '2025-06-30 07:22:14', NULL, '2025-09-28', NULL, 1, 2, '2025-06-30 07:07:01'),
(12, '12', 'APP#12', 8, NULL, 13, 92, NULL, NULL, 12, 1, 1, 2, '2025-06-30 10:46:09', '2025-06-30 11:06:05', NULL, '2025-09-28', NULL, 1, 2, '2025-06-30 11:04:10'),
(13, '13', 'APP#13', 8, NULL, 13, 92, 'registrar', NULL, 13, 1, 1, 5, '2025-06-30 12:14:21', '2025-06-30 12:48:09', NULL, '2025-09-28', NULL, 1, 2, '2025-06-30 12:44:33'),
(14, '14', 'APP#14', 8, NULL, 13, 92, 'drcs', 3, 14, 1, 1, 1, '2025-06-30 12:21:58', '2025-07-04 07:35:31', NULL, '2025-09-29', 'drcs', 1, 2, '2025-07-01 04:51:43'),
(15, '15', 'APP#15', 8, NULL, 13, 92, 'drcs', 3, 15, 1, 1, 1, '2025-07-01 06:15:15', '2025-07-04 07:52:42', NULL, '2025-09-29', 'drcs', 1, 2, '2025-07-01 07:39:30'),
(16, '16', 'APP#16', 8, NULL, 13, 92, NULL, NULL, 16, 1, 1, 2, '2025-07-01 08:47:20', '2025-07-01 10:17:38', NULL, '2025-09-29', NULL, 1, 2, '2025-07-01 10:13:26'),
(17, '17', 'APP#17', 8, NULL, 13, 92, NULL, NULL, 17, 1, 1, 2, '2025-07-01 09:54:13', '2025-07-01 10:15:40', NULL, '2025-09-29', NULL, 1, 2, '2025-07-01 10:13:07'),
(18, '18', 'APP#18', 8, NULL, 13, 92, 'arcs', NULL, 18, 1, 1, 5, '2025-07-01 10:25:42', '2025-07-04 09:06:55', NULL, '2025-09-29', NULL, 1, 2, '2025-07-04 08:44:51'),
(19, '19', 'APP#19', 8, NULL, 13, 92, 'arcs', NULL, 19, 1, 1, 3, '2025-07-01 12:59:30', '2025-07-01 13:22:13', NULL, '2025-09-29', NULL, 0, NULL, NULL),
(20, '20', 'APP#20', 8, NULL, 13, 92, NULL, NULL, 20, 1, 1, 0, '2025-07-01 17:53:58', '2025-07-01 17:53:58', NULL, NULL, NULL, 0, NULL, NULL),
(21, '21', 'APP#21', 8, NULL, 13, 92, 'ado', 2, 21, 1, 1, 1, '2025-07-01 18:09:38', '2025-07-04 07:28:24', NULL, '2025-09-30', 'ado', 0, NULL, NULL),
(22, '22', 'APP#22', 8, NULL, 13, 92, NULL, NULL, 22, 1, 1, 0, '2025-07-01 18:20:02', '2025-07-01 18:20:02', NULL, NULL, NULL, 0, NULL, NULL),
(23, '23', 'APP#23', 8, NULL, 13, 92, NULL, NULL, 23, 1, 1, 4, '2025-07-02 10:38:00', '2025-07-02 11:04:43', NULL, '2025-09-30', NULL, 1, 2, '2025-07-02 10:54:30'),
(24, '24', 'APP#24', 8, NULL, 13, 92, NULL, NULL, 24, 1, 1, 0, '2025-07-02 12:19:06', '2025-07-02 12:19:06', NULL, NULL, NULL, 0, NULL, NULL),
(25, '25', 'APP#25', 8, NULL, 13, 92, NULL, NULL, 25, 1, 1, 0, '2025-07-02 12:35:53', '2025-07-02 12:35:53', NULL, NULL, NULL, 0, NULL, NULL),
(26, '26', 'APP#26', 8, NULL, 13, 92, NULL, NULL, 26, 1, 1, 0, '2025-07-02 12:56:07', '2025-07-02 12:56:07', NULL, NULL, NULL, 0, NULL, NULL),
(27, '27', 'APP#27', 8, NULL, 12, 90, NULL, NULL, 27, 1, 1, 0, '2025-07-03 07:50:45', '2025-07-03 07:50:45', NULL, NULL, NULL, 0, NULL, NULL),
(28, '28', 'APP#28', 8, NULL, 13, 92, 'arcs', NULL, 28, 1, 1, 5, '2025-07-04 06:45:24', '2025-07-04 07:08:20', NULL, '2025-10-02', NULL, 0, NULL, NULL),
(29, '29', 'APP#29', 8, NULL, 4, 30, NULL, NULL, 29, 1, 1, 0, '2025-07-05 05:23:03', '2025-07-05 05:23:03', NULL, NULL, NULL, 0, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `society_details`
--

DROP TABLE IF EXISTS `society_details`;
CREATE TABLE IF NOT EXISTS `society_details` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `auth_id` int NOT NULL,
  `scheme_id` bigint NOT NULL,
  `is_credit_society` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT '1 => yes, 0 => no',
  `society_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `locality` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `post_office` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `developement_area` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tehsil` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `nearest_station` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applied_on` date DEFAULT NULL,
  `society_category` int DEFAULT NULL COMMENT '1-primary,2-central or apex,3-agricultural',
  `society_sector_type_id` bigint UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `society_details_society_sector_type_id_foreign` (`society_sector_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `society_details`
--

INSERT INTO `society_details` (`id`, `auth_id`, `scheme_id`, `is_credit_society`, `society_name`, `society_email`, `locality`, `post_office`, `developement_area`, `tehsil`, `district`, `nearest_station`, `applied_on`, `society_category`, `society_sector_type_id`, `created_at`, `updated_at`) VALUES
(1, 8, 1, NULL, 'society Demo', NULL, 'lc1', 'ps1', '92', 'ts1', '13', 'bs1', '2025-06-13', 1, 1, '2025-06-13 06:59:56', '2025-06-13 06:59:56'),
(2, 8, 1, '1', 'Robin Delgado', NULL, 'Culpa deleniti nostr', 'Unde proident possi', '92', 'Nisi perferendis sae', '13', 'Non laboris commodi', '2025-06-13', 2, 1, '2025-06-13 09:03:04', '2025-06-24 09:29:45'),
(3, 8, 1, '1', 'Irene Joyner', NULL, 'Commodo accusamus re', 'Iusto laborum Id cu', '92', 'Doloribus cum eius i', '13', 'Provident est iusto', '2025-06-13', 3, 1, '2025-06-13 09:07:00', '2025-07-04 13:31:57'),
(4, 8, 1, '1', 'Cairo Lancaster', NULL, 'Molestiae sint enim', 'Autem nulla facere t', '92', 'Aut vel eu excepteur', '13', 'Quisquam et esse des', '2025-06-13', 3, 1, '2025-06-13 09:19:17', '2025-06-30 08:45:10'),
(5, 8, 1, '1', 'Chantale Fletcher', NULL, 'Quia dolore voluptat', 'Voluptas in porro do', '80', 'Totam nobis aliquip', '10', 'Mollitia eaque molli', '2025-06-13', 1, 2, '2025-06-13 09:35:47', '2025-06-30 13:29:43'),
(6, 8, 1, '1', 'Adrian Craig', NULL, 'Molestiae cumque ius', 'Obcaecati praesentiu', '92', 'Dicta necessitatibus', '13', 'In vel dolore aut no', '2025-06-13', 1, 1, '2025-06-13 09:39:46', '2025-06-17 05:40:31'),
(7, 8, 1, '1', 'Uriel Hansen', NULL, 'Assumenda esse adipi', 'Quos aut aut rerum e', '92', 'Incididunt esse har', '13', 'Dolore sunt excepteu', '2025-06-13', 1, 2, '2025-06-13 09:42:33', '2025-06-17 04:57:13'),
(8, 8, 1, '0', 'Dahlia Macdonald', NULL, 'Et in deleniti ut at', 'Nam lorem dolorem ve', '92', 'Tenetur sequi rerum', '13', 'Maiores officiis rer', '2025-06-26', 1, 1, '2025-06-26 08:50:17', '2025-06-26 08:50:17'),
(9, 8, 1, '1', 'Beck Mcbride', NULL, 'Atque dolore suscipi', 'Officia accusamus si', '92', 'Dolorem itaque eveni', '13', 'Et eos repudiandae', '2025-06-26', 3, 2, '2025-06-26 10:30:28', '2025-06-30 08:35:41'),
(10, 8, 1, '0', 'Driscoll Copeland', NULL, 'Nemo incidunt id q', 'Facilis neque doloru', '92', 'Pariatur Suscipit q', '13', 'Dolor laudantium su', '2025-06-30', 1, 1, '2025-06-30 05:06:21', '2025-06-30 05:06:21'),
(11, 8, 1, '1', 'Jessica Buchanan', NULL, 'Vel soluta molestiae', 'Eligendi omnis sed e', '92', 'Labore minima lorem', '13', 'Porro iure qui venia', '2025-06-30', 3, 1, '2025-06-30 06:55:28', '2025-06-30 06:55:28'),
(12, 8, 1, '0', 'Laith Lewis', NULL, 'Esse qui a laboris q', 'Voluptatem perferend', '92', 'Nisi odio qui cupida', '13', 'Dolore ea quia in ut', '2025-06-30', 1, 2, '2025-06-30 10:46:09', '2025-06-30 10:46:09'),
(13, 8, 1, '1', 'Aline Washington', NULL, 'Et dolorem temporibu', 'Aliqua Aliquid aliq', '92', 'Minus vitae illo qui', '13', 'Amet sunt totam per', '2025-06-30', 3, 1, '2025-06-30 12:14:21', '2025-06-30 12:40:42'),
(14, 8, 1, '0', 'Abbot Simon', NULL, 'Molestiae et enim in', 'Vel ut nisi in sed v', '92', 'Veniam velit adipi', '13', 'Consequatur Volupta', '2025-06-30', 1, 1, '2025-06-30 12:21:58', '2025-07-01 05:20:42'),
(15, 8, 1, '1', 'Rachel Jackson', NULL, 'Ipsum at quis ullam', 'Duis voluptas porro', '92', 'Consequatur velit qu', '13', 'Et alias eum consect', '2025-07-01', 3, 4, '2025-07-01 06:15:15', '2025-07-01 06:15:15'),
(16, 8, 1, '1', 'Madison Shelton', NULL, 'A vitae est esse do', 'Pariatur Doloribus', '92', 'Dolore sunt quod sed', '13', 'Quasi consequatur E', '2025-07-01', 3, 1, '2025-07-01 08:47:20', '2025-07-01 08:47:20'),
(17, 8, 1, '0', 'Denise Francis', NULL, 'Unde impedit quis v', 'Quisquam quo rerum l', '92', 'Labore inventore eiu', '13', 'Dicta sequi voluptat', '2025-07-01', 1, 1, '2025-07-01 09:54:13', '2025-07-01 09:54:13'),
(18, 8, 1, '0', 'Aaron Richmond', NULL, 'Ut explicabo Non cu', 'Necessitatibus hic d', '92', 'Reprehenderit obcae', '13', 'Quod quo blanditiis', '2025-07-01', 3, 1, '2025-07-01 10:25:42', '2025-07-01 10:25:42'),
(19, 8, 1, '1', 'Hedda Fulton', NULL, 'Cupiditate et est p', 'Nesciunt laboriosam', '92', 'Aliquam laboris dolo', '13', 'Ducimus qui esse no', '2025-07-01', 3, 1, '2025-07-01 12:59:30', '2025-07-01 12:59:30'),
(20, 8, 1, '1', 'Murphy Brennan', 'mefi@mailinator.com', 'Dolorem pariatur Au', 'Aliquid pariatur Qu', '92', 'Vitae lorem recusand', '13', 'Culpa et voluptas v', '2025-07-01', 3, 1, '2025-07-01 17:53:58', '2025-07-01 18:08:54'),
(21, 8, 1, '1', 'Veronica Huff', 'quxum@mailinator.com', 'Atque eligendi dolor', 'Eiusmod impedit vol', '12', 'Exercitation beatae', '2', 'Minim consequat Exe', '2025-07-01', 3, 1, '2025-07-01 18:09:38', '2025-07-02 05:59:37'),
(22, 8, 1, '1', 'Medge Wyatt', 'tokedog@mailinator.com', 'Ut numquam sed labor', 'Odit proident aperi', '92', 'Unde repudiandae tem', '13', 'Vitae voluptas in la', '2025-07-01', 1, 1, '2025-07-01 18:20:02', '2025-07-02 12:07:07'),
(23, 8, 1, '1', 'Daphne Mays', 'towomalyq@mailinator.com', 'Accusamus iure exerc', 'Non facilis ipsum d', '92', 'Non et unde quaerat', '13', 'Laborum Laboriosam', '2025-07-02', 1, 1, '2025-07-02 10:38:00', '2025-07-02 10:48:34'),
(24, 8, 1, '0', 'Ryan Jacobs', 'duxyf@mailinator.com', 'Animi occaecat sed', 'Quam aperiam ab quis', '92', 'Dolor sit debitis i', '13', 'Esse do laborum Sae', '2025-07-02', 2, 1, '2025-07-02 12:19:06', '2025-07-02 12:34:11'),
(25, 8, 1, '1', 'Joshua Francis', 'wohi@mailinator.com', 'Laborum Velit persp', 'Fugit lorem labore', '92', 'Voluptas facere volu', '13', 'Ullamco illum illum', '2025-07-02', 2, 1, '2025-07-02 12:35:53', '2025-07-02 12:53:29'),
(26, 8, 1, '1', 'Illana Knight', 'jepafydi@mailinator.com', 'Quia asperiores temp', 'Molestias quae vitae', '92', 'At qui velit officia', '13', 'Magna veniam aliqua', '2025-07-02', 3, 1, '2025-07-02 12:56:07', '2025-07-02 13:47:09'),
(27, 8, 1, '1', 'Dillon Shaffer', NULL, 'Nisi exercitationem', 'Ea ea sit adipisici', '90', '4', '12', 'Deserunt maxime libe', '2025-07-03', 2, 2, '2025-07-03 07:50:45', '2025-07-04 06:31:05'),
(28, 8, 1, '0', 'Allistair Ayala', 'fipo@mailinator.com', 'Corrupti quo mollit', 'Ratione debitis in o', '92', '19', '13', 'Praesentium cillum d', '2025-07-04', 3, 3, '2025-07-04 06:45:24', '2025-07-04 06:59:05'),
(29, 8, 1, NULL, 'Howard Casey', NULL, 'Quam ullam qui volup', 'Eaque deleniti aut c', '30', 'Deserunt vel magna s', '4', 'Quidem a architecto', '2025-07-05', 1, 1, '2025-07-05 05:23:03', '2025-07-05 05:23:03');

-- --------------------------------------------------------

--
-- Table structure for table `society_objectives`
--

DROP TABLE IF EXISTS `society_objectives`;
CREATE TABLE IF NOT EXISTS `society_objectives` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `objective` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `society_register_documents`
--

DROP TABLE IF EXISTS `society_register_documents`;
CREATE TABLE IF NOT EXISTS `society_register_documents` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `society_id` int DEFAULT NULL,
  `meeting1` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting1_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `meeting1_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meeting1_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting2` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting2_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `meeting2_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meeting2_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting3` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `meeting3_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `meeting3_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `meeting3_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `all_id_proof` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `all_id_proof_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `all_id_proof_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `all_id_proof_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `all_application_form` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `all_application_form_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `all_application_form_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `all_application_form_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `all_declaration_form` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `all_declaration_form_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `all_declaration_form_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `all_declaration_form_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_by_laws` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_by_laws_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `society_by_laws_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `society_by_laws_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `challan_proof` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `challan_proof_status` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'pending',
  `challan_proof_remarks` text CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci,
  `challan_proof_revised` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=20 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `society_register_documents`
--

INSERT INTO `society_register_documents` (`id`, `society_id`, `meeting1`, `meeting1_status`, `meeting1_remarks`, `meeting1_revised`, `meeting2`, `meeting2_status`, `meeting2_remarks`, `meeting2_revised`, `meeting3`, `meeting3_status`, `meeting3_remarks`, `meeting3_revised`, `all_id_proof`, `all_id_proof_status`, `all_id_proof_remarks`, `all_id_proof_revised`, `all_application_form`, `all_application_form_status`, `all_application_form_remarks`, `all_application_form_revised`, `all_declaration_form`, `all_declaration_form_status`, `all_declaration_form_remarks`, `all_declaration_form_revised`, `society_by_laws`, `society_by_laws_status`, `society_by_laws_remarks`, `society_by_laws_revised`, `challan_proof`, `challan_proof_status`, `challan_proof_remarks`, `challan_proof_revised`, `created_at`, `updated_at`) VALUES
(1, 1, 'uploads/OSUUzB7guEv01UIpH7noXRuHEgZgwQDVEOR7kL4K.pdf', 'pending', NULL, NULL, 'uploads/XAcu5V6RUlUIOYdB0RPF8kafVQcvUjDpDpM1S6jm.pdf', 'pending', NULL, NULL, 'uploads/CChuzex33hKqtLbRSOp7uqBzuc8QS3nvferbJ9AX.pdf', 'pending', NULL, NULL, 'uploads/606dX6LBg0MVrCHhrrocZsxCE78xGMhFIkx9OrV1.pdf', 'pending', NULL, NULL, 'uploads/VRGtnp0CQVmNhh9FaPLCUYkgiO2GTRt35NDgACfL.pdf', 'pending', NULL, NULL, 'uploads/CAocpCyT3mDHRyD25Hb0ZzXAuMC9YenS5k7ftbAB.pdf', 'pending', NULL, NULL, 'uploads/VwGCMixmbpMJU8wIGXhCbiZZqhXwVFrUg54eA19D.pdf', 'pending', NULL, NULL, 'uploads/xs1U9dF9NnOuvJ7bhXfRxgFfNJwS2Vf7Oak1ugCf.pdf', 'pending', NULL, NULL, '2025-06-13 07:12:37', '2025-06-13 07:12:37'),
(2, 7, 'uploads/1BcLiOVZwhoryUimsNj9HObuPeB6TYIzxqCeoVIt.pdf', 'approved', 'c ccv', NULL, 'uploads/V6ZgN5KK4IOXSTv5J3BkuTcbah6lRxQbP68JN5sc.pdf', 'approved', 'reejhkjdshf', NULL, 'uploads/ovKsop1VzU2Aum1ktQe6n3BLQvfwpcFZawwsBa2Z.pdf', 'approved', 'hgjhg', NULL, 'uploads/sQXb3OsABH1HQuWlkjy4XW5Dg51IaXcTCWyCELI6.pdf', 'approved', 'hgsdfhfs', NULL, 'uploads/02iBJehadIOZShPCSXRibN38I3f3WzqluKKOO4QB.pdf', 'approved', 'wsadasd', NULL, 'uploads/9PXltKzjOD0whV9dlCVQbCsWYtiepCxPSl3P8d72.pdf', 'approved', 'asdsadasdsad', NULL, 'uploads/eiOQyAyHQXaaHQa9xULGrSUfbtmXDAx0U7f9fZAM.pdf', 'approved', 'hhdstyys', NULL, 'uploads/AVOcv47jszX1kKkx1v9ZbnMc9sFALcSiK5oxUXIc.pdf', 'approved', 'asdasd', NULL, '2025-06-17 05:07:05', '2025-06-26 07:02:49'),
(3, 6, 'uploads/eQojpIGZSqDcl9uuXeKuRsyx1fSeq7Q7LI0lYzMW.pdf', 'approved', 'aaaaa', NULL, 'uploads/X8YTCW6fNxIkVJDaUD5YcDCVj8xcZZa0tAXLDWNk.pdf', 'rejected', 'aaaaabbb', NULL, 'uploads/uQ2Dxg6cCNYemb7mL2Y2rYR19UGRVKaVgFqLfURJ.pdf', 'approved', 'sssasasa', NULL, 'uploads/P28KUrL3GyxZEVMIQRLQ0mCtdcIthcUrObcv4J2w.pdf', 'rejected', 'ssss', NULL, 'uploads/x7lL8ZevHG5KZeeeIEbVz9wOAU4J1P4IO1y4D0bc.pdf', 'approved', 'sssass', NULL, 'uploads/bOrKIa1XayAVHb440rCyduPelGBxbCjC1vroVBxm.pdf', 'rejected', 'sasas', NULL, 'uploads/lOwo5vOBGHYVgg1e1kVFbtVkxVbjO7eqhOzbcpCo.pdf', 'rejected', 'mmmm', NULL, 'uploads/JD6BjGQBgxLImkGUtoZEgdbbjjJdq43BnwjWZu5t.pdf', 'approved', 'ssas', NULL, '2025-06-17 05:46:48', '2025-06-26 13:37:52'),
(4, 8, 'uploads/GXRP32XNNtmnt60y000Po8HluXnBtQCoXT5b4IZO.pdf', 'pending', NULL, NULL, 'uploads/QKRyoixMXQ85nbWDINOqCSXx8b6JdcTg3b5o3YZx.pdf', 'pending', NULL, NULL, 'uploads/tkvu32CsQm6ruj8TwycMJxriBPhesLZR1JzXIgJV.pdf', 'pending', NULL, NULL, 'uploads/PcSqiuaxuG8tkIQVm4Z4tnnmqdZHG1YlEhSR2uWX.pdf', 'pending', NULL, NULL, 'uploads/DfGBjvfBUyx7ebPwF1QgRhF3z5lQMD91j1rOcIQZ.pdf', 'pending', NULL, NULL, 'uploads/WHuAuCqv7qNig00CrhYTMMbZiCi0idjhaJPKds1L.pdf', 'pending', NULL, NULL, 'uploads/wWJ6ChYy1t5RkC8BtmFgpLzZCxGKNBSXog0WXhzK.pdf', 'pending', NULL, NULL, 'uploads/t2KYCin3b6c1Tqo11vmX5QPbuTxPsDCytzAdEWFy.pdf', 'pending', NULL, NULL, '2025-06-26 09:02:42', '2025-06-26 09:02:42'),
(5, 9, 'uploads/y5y5wdvyw2r2xBqOXBpNgIz3kQhABgkT4MBSeQwM.pdf', 'approved', 'dsffds', NULL, 'uploads/v0WYZnB8nQBNsuqladSDG8dCPLGRkqCEDUzpkbTL.pdf', 'approved', 'mkoo', NULL, 'uploads/Bx8fGOyWRsx7MHD2Xafvcq90zGCf8Hc4zT0weo1s.pdf', 'approved', 'jhjjjjj', NULL, 'uploads/NKL6Pzdx9sZmIkwQOf0RMv4fIDMOX8UYV9kGplML.pdf', 'approved', 'bgthyresf', NULL, 'uploads/V0EDZH7U1KeqYL0yZqQg4sl9DavvU7PRw3k238UK.pdf', 'approved', 'bgreeees', NULL, 'uploads/JFfCsfmo4xzCYz69nbsnL9E460flYtuwOU2W985d.pdf', 'approved', 'bvxcsgf', NULL, 'uploads/viNeMqFh4ctRamDKbwODw4Wik0F2V2IPVmA8u5ZV.pdf', 'approved', 'bhyyy', NULL, 'uploads/9SIaozvTd26vuMnNviTxG6RlibH1XbIgxziQsDEm.pdf', 'approved', 'hgdgds', NULL, '2025-06-26 10:40:47', '2025-06-30 08:36:08'),
(6, 10, 'uploads/2O54YNjiFiSNGTiSu0EtNlSgxBXVW4Rxex91O06E.pdf', 'approved', 'sfdsdf', NULL, 'uploads/SbOLv6MciFDs9l6S7uoTI02Vu2v6FxW8Hc4sgDAY.pdf', 'rejected', 'hgtfytf', NULL, 'uploads/90W76nkpqG3QpmY3Lk9IJwjJj2dSRJ3IGGXxFend.pdf', 'approved', 'dfdfd', NULL, 'uploads/HXkdk0u9kdhu5DOZvO9vXZbjXepJt536enLDWrDf.pdf', 'approved', 'sadsd', NULL, 'uploads/K6SBBA13KQzy1YLE6xfQ9nEtZjNEZEPjT0jJaFbv.pdf', 'approved', 'sdsds', NULL, 'uploads/qBbCm4TVFS6YrTz6yEaGTSQ7aDqWvgc3W3dYpbzt.pdf', 'approved', 'dsssf', NULL, 'uploads/bZ76vFFKKilWiq0dbuujeQaw5RzNEtUO0WtrZsOS.pdf', 'approved', 'sdasdasd', NULL, 'uploads/wOddgMszp2HHtXnvhuLaCEr6xTuksJtsXOK5Jv1O.pdf', 'rejected', 'sdfsds', NULL, '2025-06-30 05:12:53', '2025-06-30 05:38:50'),
(7, 11, 'uploads/soMXhvmd52m9q0JxjrqsX0cfgoLYfH7vnZbDBG4k.pdf', 'approved', 'asdasd', NULL, 'uploads/PNXl7UMdsAmRcNIgVXhZMby5NVGftFzLuEaHpnKE.pdf', 'rejected', 'asdsads', NULL, 'uploads/YYHtjuptS1NtMTLtBCziSZs9S0LKH8yQrtico8yR.pdf', 'approved', 'sdsss', NULL, 'uploads/uL93G1IPZ5tNNK3HnH5BeYipkTX2L5ZseBkYbf3K.pdf', 'approved', 'sdfsdfsd', NULL, 'uploads/zMPUfLHvBvgBF3QWfgyRYJ20NBhfeJsumFBDCgJE.pdf', 'approved', 'sdfsdfdf', NULL, 'uploads/LN4K37L0ymISEuKSbElQrkESW1xSnjfpC7ZXNpCf.pdf', 'approved', 'esdfsf', NULL, 'uploads/ZSmG3LTEzx5FVVnqkEs1mBvE1a4Psl58D9qdwYv6.pdf', 'approved', 'sdfsfs', NULL, 'uploads/toEgh7aBnASihiAVk7ddRGg9lN8F8dlrMfUApM7d.pdf', 'approved', 'esdfsdfsdf', NULL, '2025-06-30 07:02:48', '2025-06-30 07:06:19'),
(8, 4, 'uploads/977dPnYTG18DFsADPoewR4WdUsM86jPhJ0UylNoj.pdf', 'pending', NULL, NULL, 'uploads/fgPhecF7lBg12eUeGW2TecvY53JNHduyFnh5cyuQ.pdf', 'pending', NULL, NULL, 'uploads/BjOou2nkZUFNUzHZBdqrR3JMMqgUOUiNBgZScj3Y.pdf', 'pending', NULL, NULL, 'uploads/aXI0AVtGoHOpma4RfXJlhm2WDwapcLsx9CaKUp9p.pdf', 'pending', NULL, NULL, 'uploads/oswPz2jvQzNzbjbM4PZawRRyzATmnp5LfH90oy2k.pdf', 'pending', NULL, NULL, 'uploads/KvUy9STBq0wMuFqLgyyTC0e73Wyi5bini2gsDrd5.pdf', 'pending', NULL, NULL, 'uploads/aH2RjSwD3NJIk2t0FmUfOI0M3TzHKnknmtebZ19R.pdf', 'pending', NULL, NULL, 'uploads/ckZCDGKmjl1gs2t8HMoabIgYgDsPlVztliTCbNa3.pdf', 'pending', NULL, NULL, '2025-06-30 08:46:03', '2025-06-30 08:46:03'),
(9, 12, 'uploads/F442zxGMdsWJnWWbRD43saEhOr7WqT64I3LmqeEW.pdf', 'approved', 'nhbhbh', NULL, 'uploads/rEYAApO91vI9teZb6N35mzjlWQwE8xE0Nr5dqCDK.pdf', 'rejected', 'jhgyj', NULL, 'uploads/2lFzQTg1maaH94aUREZMNP3GgLjz5vwpWm0ryADN.pdf', 'approved', 'njuuuuuuu', NULL, 'uploads/lnFoFCLhamCn1n1KZMeG55X5jTWw67XF4uzHFIZP.pdf', 'rejected', 'nhyydstrtds', NULL, 'uploads/73vi0JhSWAYyBqfq8Gd9Tj9NE0CVkzjMl83yjbDx.pdf', 'approved', 'sdfsdfvdfds', NULL, 'uploads/V9eRTjujk0xX8ZrCGnzQF6oNrtGJcb68ko13a7mu.pdf', 'approved', 'wadsasdasd', NULL, 'uploads/PmUbVAXXsJP6ll89sSeemE0G85HjF6mo6Om9Le5Y.pdf', 'approved', 'nbhhghghghg', NULL, 'uploads/hH9DvFo5UOBVzVPf5cHQevO75EAc6Hnnb7aWDs9J.pdf', 'approved', 'wsdfsfsd', NULL, '2025-06-30 11:00:15', '2025-06-30 11:03:41'),
(10, 13, 'uploads/cf0tPEcusJD0GsFzd6w3xeOCd7suzrkGZWJGyOSM.pdf', 'rejected', 'gghfggggg', NULL, 'uploads/6TcxFdTZhc2o2a8NxTnL35jvzINlt1B6453w5b35.pdf', 'rejected', 'gggggggggggg', NULL, 'uploads/EE3iuMCKa5MzPZMKq36rQAiBIiGY36o7FGpE1MvA.pdf', 'rejected', 'hhhhhhhhhhhhh', NULL, 'uploads/ylgNFAFoH8FVcJfUIOTrdujnLqxhxt7JpfkMgAef.pdf', 'rejected', 'iiiiiiiiiiii', NULL, 'uploads/BvYSdfHBc2fusgs43RNqinvO09Oq1YTeCMADZvrZ.pdf', 'rejected', 'iiiiiiiiiii', NULL, 'uploads/HOmRycY8lP9Ayx3gcFMu7GSze6r5wUQfqPdv9oLd.pdf', 'rejected', 'yyyyyyyyyyyyy', NULL, 'uploads/MdjEmnpf0FprKcDgBZt669EVaDXu6pouK46pY9UA.pdf', 'rejected', 'uuuuuuuuu', NULL, 'uploads/TIrISfbIyPJctVF8egA94MIDDGhLYVO0WxizO2qT.pdf', 'approved', 'tttttttttttttttttt', NULL, '2025-06-30 12:21:05', '2025-06-30 12:40:54'),
(11, 14, 'uploads/8ee5AvnxbDhVLN5w87hWpeUFtZxtwiw4FpgUKX7i.pdf', 'rejected', 'Quo velit optio qu', NULL, 'uploads/GorpNBcp4oxiO1FHDXHBkhiDynNSdCa2iVhyHKKL.pdf', 'approved', 'Optio sed dolor et', NULL, 'uploads/SVOl25bpSgtG0UBHOm5qI9OdnLKcDQk3O1N9kbIH.pdf', 'approved', 'Culpa et labore pro', NULL, 'uploads/lWDtAWgtpewoIt72zPT9ZlrBQqPP7k3uV41oAaZj.pdf', 'rejected', 'Quas aut labore iust', NULL, 'uploads/lbHJI1APz3NqaNxrg7CC7FZUJFbe2u4QFcYC64Fr.pdf', 'rejected', 'Similique repudianda', NULL, 'uploads/zm1aLOcjEb1IYfdXaO7v4Ll7Gvxc5iZdltnS4qkz.pdf', 'approved', 'Quis doloremque eum', NULL, 'uploads/YSXpn8pZrIdAyti1BR45WeekTyQxxeARdLzTXDnZ.pdf', 'rejected', 'Quos nobis provident', NULL, 'uploads/4UUfIe5pSJFL7Pm52zKw8iBSTubpkApm6EHrOEjw.pdf', 'approved', 'Fugit consectetur', NULL, '2025-06-30 12:28:18', '2025-07-01 05:21:09'),
(12, 15, 'uploads/k0EyTh8AzVDglS7fAwLyDPN9SkEEhBhcAWQOfIly.pdf', 'approved', 'sssssssssssss', NULL, 'uploads/Qmh5mv76nqdN0opHCiW2LdlNvQiBzzUfSS1hb5EO.pdf', 'approved', 'saaaaaaaaaaaaaaa', NULL, 'uploads/ptb6qD10KKs6NnJJljAFtXwMYJJHeZq7Bp4DMW4i.pdf', 'rejected', 'saaaaaaaaaaaa', NULL, 'uploads/GmdzsWGJFgKdW5AlFxdQBjffYGtLQfTISwGWYzmI.pdf', 'approved', 'ssssssssssssss', NULL, 'uploads/KZKhMRKm6YOP4TTOmPJoBau6BcNwiRkMA4vhlfRk.pdf', 'approved', 'ssssssssssssss', NULL, 'uploads/KwW7EZeW6Mf4nVyOWCttLiMcrwznS3cAO9fzahlV.pdf', 'approved', 'sssssssssssssss', NULL, 'uploads/qWWH6CC1MvcZMxzOuXOwfhLHkf3bY0PGEureFQWp.pdf', 'rejected', 'sssssssssssss', NULL, 'uploads/maEhrMERMGM8sq8x763oDZTjCO1OryjqWNdXAF16.pdf', 'approved', 'sssssssssssss', NULL, '2025-07-01 06:22:00', '2025-07-01 06:39:34'),
(13, 16, 'uploads/xS0vQBMgvSyZVYOW850F1sTKWG13MHWNqurzRi3r.pdf', 'approved', 'qweeeeeeee', NULL, 'uploads/SGzQlkHaV9Futo55opu4yhcY8DogRH9MwFLy0mQ2.pdf', 'approved', 'qwwwwwwww', NULL, 'uploads/ZoCMGcaXrHCRGgDTxW522OvMjwuW4a1HRpRs54gb.pdf', 'rejected', 'WWWWWWWWW', NULL, 'uploads/aqf0bhZoITRILgxz5bG1qDLWB6L6DJXf225XdkQW.pdf', 'approved', 'HHHHHHHH', NULL, 'uploads/J1LNNT3NtSS6F00lA32NL2KdyilVsIcSgvH3Idn0.pdf', 'approved', 'JJJJJJJJ', NULL, 'uploads/0VQYesIeIvmGKCesQJqU1xPCv0uQqgzGqIZ5kgsw.pdf', 'approved', 'MMMMMMMMMM', NULL, 'uploads/eIiDZkoy4rqHoGgAnECfVUw7KHkvNwJ0r49VSLox.pdf', 'approved', 'GGGGGGGG', NULL, 'uploads/slYguQOadwTAvBVqLOjHlRGMitoP4uYq7ZnJyIx7.pdf', 'approved', 'NNNNNNN', NULL, '2025-07-01 08:52:32', '2025-07-01 09:06:29'),
(14, 17, 'uploads/4dPrGOAOEpaUgCJ6lKcfnmaafie1Av2gRgmrNd2X.pdf', 'approved', 'aaaaa', NULL, 'uploads/YmMzSoojFK9oJwLNdgR0ZejESEXzqYFy8zWpUUqZ.pdf', 'rejected', 'mmmmmmmmm', NULL, 'uploads/DajRJCDKO0KVcWBIaqx43QHDPheHEyZajOgoVaqN.pdf', 'approved', 'mmmmmmmlllllll', NULL, 'uploads/LQcmBPYw3Hi2JCkoWaD5TMs20uHWe67RyhfaYnqs.pdf', 'approved', 'nhyyyyy', NULL, 'uploads/4mp1Hf6rL2QHciva4AcLuOju8uFFqivi9lIcOMHP.pdf', 'approved', 'ggggggggggg', NULL, 'uploads/uLq7O5UwfhQjMcDXuNjTD8E6U2B02ZDMspxo6Sjx.pdf', 'rejected', 'bbbbbbbb', NULL, 'uploads/7StgPeEpGpfIZyWPBCNiiWXO1BNu60jeMNVXPvuF.pdf', 'approved', 'mmmmmmmmmmm', NULL, 'uploads/7tFkBjvJQUAEHuy2SpngAgytrS3fMywnl6UrABXL.pdf', 'approved', 'nnnnnnnnnnn', NULL, '2025-07-01 10:02:55', '2025-07-01 10:09:17'),
(15, 18, 'uploads/zob10EygdHuqDdOE5DHAz7NRnbsK5BkROGlPDinZ.pdf', 'approved', 'sssssssssssss', NULL, 'uploads/7MxPcwlEFqkKTspmvkW7JzYXueBYGfCSOFOfDs6z.pdf', 'approved', 'dddddddddd', NULL, 'uploads/tm1SdoKUivzYCfGY0ypSO9AOV9ymHXnpm5y0F4jw.pdf', 'approved', 'dddddddddddd', NULL, 'uploads/mAVc4iUo5bNvAOHoCwHm7iwY2kZnsSfxgeSx4fhD.pdf', 'approved', 'ffffffffffffffffffff', NULL, 'uploads/FrTxQtBffYXxX4Dlj6WXSg2daE7vFcCD4i0ztbXL.pdf', 'rejected', 'fffffffffffffffff', NULL, 'uploads/VUFP6S7pulLiM2JPxNah1CetTGg6QKPFjjoMLxt5.pdf', 'rejected', 'fffffffffffffffffffffffffffffffff', NULL, 'uploads/6gSMuNGsSoLN83FsQphFqXaQYfD2UXnC6cJKaAGU.pdf', 'approved', 'ffffffffffff', NULL, 'uploads/PLOd8Rl6saNxdi7b1C7UA4fIPsbYQhyphyjgqtak.pdf', 'approved', 'ffffffffffff', NULL, '2025-07-01 10:33:28', '2025-07-01 10:35:55'),
(16, 19, 'uploads/h2wqGTp0sHoZVC2hP1vWJOuUI5YpGtJVh5iXIWw8.pdf', 'pending', NULL, NULL, 'uploads/ypys7qfttqnICIGnW3JqUp8R7U0vGYsOAus2REZa.pdf', 'pending', NULL, NULL, 'uploads/976B0Ix2jwb60qKGff1SSx6g7mLyEAA5PnRwru4u.pdf', 'pending', NULL, NULL, 'uploads/B0XZwF1QhFuv6Umlf39V4DhkMZlrasXHq5SkG8MK.pdf', 'pending', NULL, NULL, 'uploads/LHF1TvJMem2mDwmY9sfzZNnjZYp6nq37xag658rd.pdf', 'pending', NULL, NULL, 'uploads/Ma4m8uvNTeQBICcZNUv6Q5UzCIv8g9XTF0NoiHIh.pdf', 'pending', NULL, NULL, 'uploads/vbeSoX1BivjyzO2wLOHJ5VMFT0AHBBp47w4jPZPM.pdf', 'pending', NULL, NULL, 'uploads/6jHrcBfh4dGA7DUIbtpVOfklgzZFTcVZ1IX3CC2w.pdf', 'pending', NULL, NULL, '2025-07-01 13:08:28', '2025-07-01 13:08:28'),
(17, 21, 'uploads/NlYeP42lSKel4i650otm2pwDCzqUnwu86wqimRaN.pdf', 'pending', NULL, NULL, 'uploads/qLHwWUBGh2o8uKFkbj5xbsyVX8nMKrAgw0s9fZpk.pdf', 'pending', NULL, NULL, 'uploads/2WyfIeTSx5PJvWmjEDbLEycAOHbvZHW1BJCuIr6M.pdf', 'pending', NULL, NULL, 'uploads/Gvqg7qA7cfJCBLSwR6FdA4KPYo59kdAJYhRvOmJb.pdf', 'pending', NULL, NULL, 'uploads/p8q03kxDs5E7WMmz6Ju6EvnBE0wZC2m579irE4LL.pdf', 'pending', NULL, NULL, 'uploads/pNq7mT6M9oIFJb9Hy0BIioihGEuysO9JPphYmdG4.pdf', 'pending', NULL, NULL, 'uploads/tUM3XZlaFKhxhK5zQrB0cOzAKsQUvgvZSeAtKgmJ.pdf', 'pending', NULL, NULL, 'uploads/NJopjayOtco9vdPZAamIXAXPoIxX7sjQLM6uqboF.pdf', 'pending', NULL, NULL, '2025-07-02 06:00:36', '2025-07-02 06:00:36'),
(18, 23, 'uploads/VTFEgsViiicX511UwXJqTjsBhdz7I3Bt1khI90r2.pdf', 'approved', 'aaaaaaaaaaaaa', NULL, 'uploads/7hOLf1hsofcl7zlyQVcyfa88wNosr1lHqUNfuGxC.pdf', 'approved', 'ccccccccccccccc', NULL, 'uploads/xU9ULAIm1oMerHliIrtsRg7MIWiGnXaZOrEe38kf.pdf', 'approved', 'xxxxxxxxxxxxx', NULL, 'uploads/n5Q8EOs6gJaQ7ABr9Mv0DPsRH3wAwNcBdP6zUYXa.pdf', 'approved', 'sssssssssssss', NULL, 'uploads/STG8SOJYHMjhg1HYoGKUPgFAUAyc5QUCqRKdiLqT.pdf', 'approved', 'aaaaaaaaaaa', NULL, 'uploads/zzMrL0ULbXBMwEBETLHnsaugDwqLOQDhqzv5N8Xp.pdf', 'rejected', 'DDDDDDDD', NULL, 'uploads/fP7wT0DgqvxueH9mY85vSXKo5uV2iRsXZb0w8Eek.pdf', 'rejected', 'zzzzzzzzzzzzzzz', NULL, 'uploads/i9b9bMdw3ttUyDI7VmOZ5MuolQjqo6101bnnjqhv.pdf', 'approved', 'nnnnnnnnnnnn', NULL, '2025-07-02 10:50:57', '2025-07-02 10:54:10'),
(19, 28, 'uploads/OgFzjDJCuMPnQMPspjnW34zQDVR1btXD5qgBfBcg.pdf', 'pending', NULL, NULL, 'uploads/kcmYZHUkE6PO9M5E7NrrnRq4LUI3ZS0V1v6gAwCw.pdf', 'pending', NULL, NULL, 'uploads/WpB9l1ioZhyXbi04bpNJPQ3pHkxXTXCw1m6kglmp.pdf', 'pending', NULL, NULL, 'uploads/70TtKZkfnF5S1zGjUSqBXWDfcQGZxLU5iv94ZlXL.pdf', 'pending', NULL, NULL, 'uploads/xHN4RE3hFn01Eryab08ysIX6MvhXBpfhLIkWXTVT.pdf', 'pending', NULL, NULL, 'uploads/xtRFSGJ0t9wnfIhggqFHmR3KAhUBJV9KZnvXDlGi.pdf', 'pending', NULL, NULL, 'uploads/NBkNoDZsfdYKUmZnEEQOIf2UNK6Kn5RqIoe2mVdW.pdf', 'pending', NULL, NULL, 'uploads/O1QaQOZSHCCvnfcWD134zcjcyAxvypj7mRWi3eQ5.pdf', 'pending', NULL, NULL, '2025-07-04 07:06:44', '2025-07-04 07:06:44');

-- --------------------------------------------------------

--
-- Table structure for table `society_sector_types`
--

DROP TABLE IF EXISTS `society_sector_types`;
CREATE TABLE IF NOT EXISTS `society_sector_types` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `cooperative_sector_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` enum('0','1') CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '1' COMMENT '0 => inactive, 1 => active',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `society_sector_types`
--

INSERT INTO `society_sector_types` (`id`, `cooperative_sector_name`, `is_active`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Primary Agricultural Credit Society (PACS)', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(2, 'Urban Cooperative Bank (UCB)', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(3, 'Dairy Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(4, 'Fishery Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(5, 'Sugar Mills Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(6, 'Handloom Textile & Weavers Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(7, 'Handicraft Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(8, 'Women Welfare Cooperative Society', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(9, 'Multipurpose Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(10, 'Credit & Thrift Society', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(11, 'Miscellaneous Non Credit', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(12, 'Agro Processing / Industrial Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(13, 'Housing Cooperative Society', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(14, 'Labour Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(15, 'Livestock & Poultry Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(16, 'Transport Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(17, 'Agriculture & Allied Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(18, 'Bee Farming Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(19, 'Consumer Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(20, 'Marketing Cooperative Society', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(21, 'Educational & Training Cooperatives', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(22, 'Sericulture Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(23, 'Social Welfare & Cultural Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(24, 'Tourism Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL),
(25, 'Tribal-SC/ST Cooperative', '1', '2025-06-13 06:58:01', '2025-06-13 06:58:01', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `society_type`
--

DROP TABLE IF EXISTS `society_type`;
CREATE TABLE IF NOT EXISTS `society_type` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `type` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `status` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `states`
--

DROP TABLE IF EXISTS `states`;
CREATE TABLE IF NOT EXISTS `states` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `states`
--

INSERT INTO `states` (`id`, `name`, `created_at`, `updated_at`) VALUES
(1, 'Uttarakhand', '2025-06-13 12:19:40', '2025-06-13 12:19:40');

-- --------------------------------------------------------

--
-- Table structure for table `sub_divisions`
--

DROP TABLE IF EXISTS `sub_divisions`;
CREATE TABLE IF NOT EXISTS `sub_divisions` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `tehsils`
--

DROP TABLE IF EXISTS `tehsils`;
CREATE TABLE IF NOT EXISTS `tehsils` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `district_id` bigint NOT NULL,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=112 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `tehsils`
--

INSERT INTO `tehsils` (`id`, `district_id`, `name`, `created_at`, `updated_at`) VALUES
(1, 12, 'Bageshwar', NULL, NULL),
(2, 12, 'Dug Nakuri', NULL, NULL),
(3, 12, 'Garur', NULL, NULL),
(4, 12, 'Kanda', NULL, NULL),
(5, 12, 'Kaphaligair', NULL, NULL),
(6, 12, 'Kapkot', NULL, NULL),
(7, 3, 'Adi Badri', NULL, NULL),
(8, 3, 'Chamoli', NULL, NULL),
(9, 3, 'Gairsain', NULL, NULL),
(10, 3, 'Ghat', NULL, NULL),
(11, 3, 'Jilasu', NULL, NULL),
(12, 3, 'Joshimath', NULL, NULL),
(13, 3, 'Karnaprayag', NULL, NULL),
(14, 3, 'Nandaprayag', NULL, NULL),
(15, 3, 'Narayanbagar', NULL, NULL),
(16, 3, 'Pokhari', NULL, NULL),
(17, 3, 'Tharali', NULL, NULL),
(18, 13, 'Barakot', NULL, NULL),
(19, 13, 'Champawat', NULL, NULL),
(20, 13, 'Lohaghat', NULL, NULL),
(21, 13, 'Pati', NULL, NULL),
(22, 13, 'Purnagiri', NULL, NULL),
(23, 1, 'Chakrata', NULL, NULL),
(24, 1, 'Dehradun', NULL, NULL),
(25, 1, 'Doiwala', NULL, NULL),
(26, 1, 'Kalsi', NULL, NULL),
(27, 1, 'Rishikesh', NULL, NULL),
(28, 1, 'Tyuni', NULL, NULL),
(29, 1, 'Vikasnagar', NULL, NULL),
(30, 2, 'Bhagwanpur', NULL, NULL),
(31, 2, 'Haridwar', NULL, NULL),
(32, 2, 'Laksar', NULL, NULL),
(33, 2, 'Roorkee', NULL, NULL),
(34, 9, 'Betalghat', NULL, NULL),
(35, 9, 'Dhari', NULL, NULL),
(36, 9, 'Haldwani', NULL, NULL),
(37, 9, 'Kaladhungi', NULL, NULL),
(38, 9, 'Lalkuan', NULL, NULL),
(39, 9, 'Nainital', NULL, NULL),
(40, 9, 'Ramnagar', NULL, NULL),
(41, 7, 'Bironkhal', NULL, NULL),
(42, 7, 'Chakisain', NULL, NULL),
(43, 7, 'Chaubattakhal', NULL, NULL),
(44, 7, 'Khansyun', NULL, NULL),
(45, 7, 'Koshyankutoli', NULL, NULL),
(46, 7, 'Kotdwar', NULL, NULL),
(47, 7, 'Lansdowne', NULL, NULL),
(48, 7, 'Pauri', NULL, NULL),
(49, 7, 'Rikhanikhal', NULL, NULL),
(50, 7, 'Satpuli', NULL, NULL),
(51, 7, 'Srinagar', NULL, NULL),
(52, 7, 'Thalisain', NULL, NULL),
(53, 7, 'Yamkeshwar', NULL, NULL),
(54, 10, 'Bangapani', NULL, NULL),
(55, 10, 'Berinag', NULL, NULL),
(56, 10, 'Devalthal', NULL, NULL),
(57, 10, 'Dharchula', NULL, NULL),
(58, 10, 'Didihat', NULL, NULL),
(59, 10, 'Ganai', NULL, NULL),
(60, 10, 'Gangolihat', NULL, NULL),
(61, 10, 'Kanalichhina', NULL, NULL),
(62, 10, 'Munsiari', NULL, NULL),
(63, 10, 'Pithoragarh', NULL, NULL),
(64, 10, 'Tejam', NULL, NULL),
(65, 10, 'Thal', NULL, NULL),
(66, 5, 'Basukedar', NULL, NULL),
(67, 5, 'Jakholi', NULL, NULL),
(68, 5, 'Rudraprayag', NULL, NULL),
(69, 5, 'Ukhimath', NULL, NULL),
(70, 4, 'Balganga', NULL, NULL),
(71, 4, 'Devprayag', NULL, NULL),
(72, 4, 'Dhanaulti', NULL, NULL),
(73, 4, 'Gaja', NULL, NULL),
(74, 4, 'Ghansali', NULL, NULL),
(75, 4, 'Jakhanidhar', NULL, NULL),
(76, 4, 'Kandisaur', NULL, NULL),
(77, 4, 'Kirtinagar', NULL, NULL),
(78, 4, 'Madannegi', NULL, NULL),
(79, 4, 'Nainbagh', NULL, NULL),
(80, 4, 'Narendranagar', NULL, NULL),
(81, 4, 'Paoki Devi', NULL, NULL),
(82, 4, 'Pratapnagar', NULL, NULL),
(83, 4, 'Tehri', NULL, NULL),
(84, 6, 'Barkot', NULL, NULL),
(85, 6, 'Bhatwari', NULL, NULL),
(86, 6, 'Chinyalisaur', NULL, NULL),
(87, 6, 'Dhauntari', NULL, NULL),
(88, 6, 'Dunda', NULL, NULL),
(89, 6, 'Joshiyara', NULL, NULL),
(90, 6, 'Mori', NULL, NULL),
(91, 6, 'Purola', NULL, NULL),
(92, 8, 'Almora', NULL, NULL),
(93, 8, 'Bhanoli', NULL, NULL),
(94, 8, 'Bhikiyasain', NULL, NULL),
(95, 8, 'Chaukhutia', NULL, NULL),
(96, 8, 'Dwarahat', NULL, NULL),
(97, 8, 'Jainti', NULL, NULL),
(98, 8, 'Lamgara', NULL, NULL),
(99, 8, 'Ranikhet', NULL, NULL),
(100, 8, 'Salt', NULL, NULL),
(101, 8, 'Someshwar', NULL, NULL),
(102, 8, 'Syalde', NULL, NULL),
(103, 11, 'Bajpur', NULL, NULL),
(104, 11, 'Gadarpur', NULL, NULL),
(105, 11, 'Jaspur', NULL, NULL),
(106, 11, 'Kashipur', NULL, NULL),
(107, 11, 'Khatima', NULL, NULL),
(108, 11, 'Kichha', NULL, NULL),
(109, 11, 'Nanakmatta', NULL, NULL),
(110, 11, 'Rudrapur', NULL, NULL),
(111, 11, 'Sitarganj', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint UNSIGNED NOT NULL AUTO_INCREMENT,
  `name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci NOT NULL,
  `remember_token` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `division_id` int DEFAULT NULL,
  `district_id` int DEFAULT NULL,
  `block_id` int DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `address` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mob_no` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `society_name` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `member_type` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int DEFAULT NULL,
  `role_id` bigint UNSIGNED DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `verified_by` bigint UNSIGNED DEFAULT NULL,
  `verified_at` timestamp NULL DEFAULT NULL,
  `token` varchar(191) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`)
) ENGINE=MyISAM AUTO_INCREMENT=13 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `email_verified_at`, `password`, `remember_token`, `division_id`, `district_id`, `block_id`, `created_at`, `updated_at`, `address`, `mob_no`, `society_name`, `member_type`, `age`, `role_id`, `is_active`, `verified_by`, `verified_at`, `token`, `deleted_at`) VALUES
(1, 'Arcs', 'arcs@gmail.com', NULL, '$2y$12$JXIT2AQbLT.dooQHyEybqe757Lvr.HvdXPBl.sLiKBrirTg15K47e', NULL, NULL, 13, 92, '2025-06-13 12:19:40', '2025-07-08 11:33:29', NULL, '8965896589', NULL, NULL, NULL, 3, 1, NULL, NULL, NULL, NULL),
(2, 'ado', 'ado@gmail.com', NULL, '$2y$12$spuJbzFZFyIxppKXuUjcR.vfSnCb2KFKgS.mRI7VZsOzZBabuzfq6', NULL, NULL, 13, 92, '2025-06-13 12:19:40', '2025-07-08 11:33:30', NULL, '8965896589', NULL, NULL, NULL, 4, 1, NULL, NULL, NULL, NULL),
(3, 'drcs', 'drcs@gmail.com', NULL, '$2y$12$rJMaV/.4iNq.YBdFKJweven5dLxOSh97mDbWEJ/VACSlsHXrZH05m', NULL, NULL, 13, 92, '2025-06-13 12:19:41', '2025-07-08 11:33:30', NULL, '8965896589', NULL, NULL, NULL, 5, 1, NULL, NULL, NULL, NULL),
(4, 'registrar', 'registrar@gmail.com', NULL, '$2y$12$PlnLAywd1/NruQIwdb2xF.WXQE.DW7UQDvEFo/AWnHhHEJ8Yx.vsq', NULL, NULL, 13, 92, '2025-06-13 12:19:41', '2025-07-08 11:33:30', NULL, '8965896589', NULL, NULL, NULL, 6, 1, NULL, NULL, NULL, NULL),
(5, 'Shri Anil Kumar Bharati', 'anil@gmail.com', NULL, '$2y$12$Y9Xn3J7an4AdTr.7CMF3Z.zjpWoNLe8.kuPKhiYe.NQYXpk7L1LSu', NULL, NULL, NULL, NULL, '2025-06-13 12:19:41', '2025-07-08 11:33:30', NULL, '8989898525', NULL, NULL, NULL, 8, 1, NULL, NULL, NULL, NULL),
(6, 'Shri Biswajit Mitra', 'biswa@gmail.com', NULL, '$2y$12$MeFmgCjgfRStQzPzMmfTZ.ZJPfROWTLft6Nino9YD2zHHnKiIPNfa', NULL, NULL, NULL, NULL, '2025-06-13 12:19:41', '2025-07-08 11:33:31', NULL, '8989898526', NULL, NULL, NULL, 8, 1, NULL, NULL, NULL, NULL),
(7, 'Super Admin', 'superadmin@gmail.com', NULL, '$2y$12$SoQAEIQst2Z9qTL24jfai.gkj3gGsMpLbJ7Bh./ticCLeGA0i87HS', NULL, NULL, NULL, NULL, '2025-06-13 12:19:42', '2025-06-13 12:19:42', NULL, '1234567890', NULL, NULL, NULL, 1, 1, NULL, NULL, NULL, NULL),
(8, 'madhusmita', 'madhusmita@gmail.com', NULL, '$2y$12$yw.q/7ejqCKu/.tBRNx8W.qcdNmNeDi6HYbXXeo71u41lDT9CahXq', NULL, NULL, 13, 92, '2025-06-13 06:54:10', '2025-06-13 06:54:10', NULL, '7846871663', NULL, NULL, NULL, 7, 1, NULL, NULL, NULL, NULL),
(9, 'JRCS', 'jrcs@gmail.com', NULL, '$2y$12$k2/VBhXK1gBHyQK8Y6LuyuzjLDpBR0I8g0OQ..EwU.Xx8HTtDpqaa', NULL, NULL, NULL, NULL, '2025-07-08 11:33:31', '2025-07-08 11:33:31', NULL, '8989898526', NULL, NULL, NULL, 12, 1, NULL, NULL, NULL, NULL),
(10, 'Additional RCS', 'additionalrcs@gmail.com', NULL, '$2y$12$C/SHkgXoWVgUgo3bWvfBmeEfSoB8CQDbPfimEJXxc46t0auYUDQba', NULL, NULL, NULL, NULL, '2025-07-08 11:33:31', '2025-07-08 11:33:31', NULL, '8989898526', NULL, NULL, NULL, 11, 1, NULL, NULL, NULL, NULL),
(11, 'ADCO', 'adco@gmail.com', NULL, '$2y$12$Yp8yZX7WPMd8RCoyyzF8POol0NSm09s.Sw7XnyiDspwgnX59SnGey', NULL, NULL, 13, 92, '2025-07-08 11:33:32', '2025-07-08 11:33:32', NULL, '8989898526', NULL, NULL, NULL, 13, 1, NULL, NULL, NULL, NULL),
(12, 'Supervisor', 'supervisor@gmail.com', NULL, '$2y$12$dMiYd5T9/pKxPrZaO32IteV20BG44kLBj/3cHOh9Uxx.gNtHitKP.', NULL, NULL, 13, 92, '2025-07-08 11:33:32', '2025-07-08 11:33:32', NULL, '8989898898', NULL, NULL, NULL, 14, 1, NULL, NULL, NULL, NULL);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
